#!/bin/bash

cd Team27/Code27
mkdir build
cd build
cmake -A x64 ..
cmake --build . --target autotester --config Release
python ../../Tests27/testing_script.py -e ./src/autotester/Release/autotester.exe -o ../tests/ -t ../../Tests27/
pwd
echo "failed tests: "
ls ../tests/failed/ | grep xml
cd ../../
