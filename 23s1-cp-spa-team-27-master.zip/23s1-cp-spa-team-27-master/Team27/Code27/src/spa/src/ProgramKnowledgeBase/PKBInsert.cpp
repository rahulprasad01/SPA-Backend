#include "PKBInsert.h"
#include "EntityStorage.h"
#include "PatternStorage.h"
#include "RelationStorage.h"

using namespace SPA;

namespace PKB {
bool PKBInsert::insertEntity(const Entity& entity) {
  EntityStorage& entities = pkbManager.getEntityStorageHandle();
  return entities.insertEntity(entity);
}

bool PKBInsert::insertParent(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertParent(lhs, rhs);
};

bool PKBInsert::insertFollows(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertFollows(lhs, rhs);
};

bool PKBInsert::insertUses(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertUses(lhs, rhs);
};

bool PKBInsert::insertModifies(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertModifies(lhs, rhs);
};

bool PKBInsert::insertCalls(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertCalls(lhs, rhs);
};

bool PKBInsert::insertNext(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertNext(lhs, rhs);
};

bool PKBInsert::insertProcStmt(const Entity& lhs, const Entity& rhs) {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.insertProcStmt(lhs, rhs);
};

bool PKBInsert::insertAssignPattern(const Entity& stmt, const Entity& var,
                                    const vector<RawToken>& rightExpr) {
  PatternStorage& patterns = pkbManager.getPatternStorageHandle();
  return patterns.insertAssignPattern(stmt, var, rightExpr);
};

bool PKBInsert::insertContainerPattern(const Entity& stmt, const Entity& var) {
  PatternStorage& patterns = pkbManager.getPatternStorageHandle();
  return patterns.insertContainerPattern(stmt, var);
}

}  // namespace PKB
