#pragma once
#include "PKBManager.h"

using namespace SPA;

namespace PKB {

class PKBInsert {
 public:
  PKBInsert(PKBManager& pkb) : pkbManager(pkb) {}

  bool insertEntity(const Entity& entity);

  bool insertParent(const Entity& lhs, const Entity& rhs);
  bool insertFollows(const Entity& lhs, const Entity& rhs);
  bool insertUses(const Entity& lhs, const Entity& rhs);
  bool insertModifies(const Entity& lhs, const Entity& rhs);
  bool insertCalls(const Entity& lhs, const Entity& rhs);
  bool insertNext(const Entity& lhs, const Entity& rhs);
  bool insertProcStmt(const Entity& lhs, const Entity& rhs);

  bool insertAssignPattern(const Entity& stmt, const Entity& var,
                           const vector<RawToken>& rightExpr);
  bool insertContainerPattern(const Entity& stmt, const Entity& var);

 private:
  PKBManager& pkbManager;
};

}  // namespace PKB
