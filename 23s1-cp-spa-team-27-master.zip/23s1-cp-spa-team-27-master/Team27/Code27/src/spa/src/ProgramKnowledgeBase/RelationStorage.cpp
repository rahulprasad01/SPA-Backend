#include "RelationStorage.h"
#include <stack>
#include <unordered_set>
#include "Common/Algorithms.h"
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"

using namespace SPA;

namespace PKB {
bool RelationStorage::insertParent(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, parentLHSInsertTypes);
  SPA::validateEntity(rhs, stmtInsertTypes);
  parentLHS[lhs.label].insert(rhs.label);
  parentRHS[rhs.label] = lhs.label;
  insertIntoTransitiveMaps(parentTLHS, parentTRHS, lhs.label, rhs.label);
  return true;
}

bool RelationStorage::insertFollows(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtInsertTypes);
  SPA::validateEntity(rhs, stmtInsertTypes);
  followsLHS[lhs.label] = rhs.label;
  followsRHS[rhs.label] = lhs.label;
  insertIntoTransitiveMaps(followsTLHS, followsTRHS, lhs.label, rhs.label);
  return true;
}

bool RelationStorage::insertUses(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, usesLHSInsertTypes);
  SPA::validateEntity(rhs, SPA::VAR);
  auto& LHSTable = (lhs.type == SPA::PROC) ? usesProc : usesStmt;
  LHSTable[lhs.label].insert(rhs.label);
  usesVar[rhs.label].insert(lhs.label);
  if (lhs.type == SPA::ASSIGN_STMT) {
    usesAssignStmt[lhs.label].insert(rhs.label);
    usesVarAssigns[rhs.label].insert(lhs.label);
  }
  return true;
}

bool RelationStorage::insertModifies(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, modifiesLHSInsertTypes);
  SPA::validateEntity(rhs, SPA::VAR);
  auto& LHSTable = (lhs.type == SPA::PROC) ? modifiesProc : modifiesStmt;
  LHSTable[lhs.label].insert(rhs.label);
  modifiesVar[rhs.label].insert(lhs.label);
  if (lhs.type == SPA::ASSIGN_STMT) {
    modifiesAssignStmt[lhs.label] = rhs.label;
    modifiesVarAssigns[rhs.label].insert(lhs.label);
  }
  if (affectsModifiableTypes.count(lhs.type)) {
    modifiesVarAffects[rhs.label].insert(lhs.label);
  }
  return true;
}

bool RelationStorage::insertCalls(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, SPA::PROC);
  SPA::validateEntity(rhs, SPA::PROC);
  callsLHS[lhs.label].insert(rhs.label);
  callsRHS[rhs.label].insert(lhs.label);
  insertIntoTransitiveMaps(callsTLHS, callsTRHS, lhs.label, rhs.label);
  return true;
}

bool RelationStorage::insertNext(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtInsertTypes);
  SPA::validateEntity(rhs, stmtInsertTypes);
  nextLHS[lhs.label].insert(rhs.label);
  nextRHS[rhs.label].insert(lhs.label);
  return true;
}

bool RelationStorage::insertProcStmt(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, SPA::PROC);
  SPA::validateEntity(rhs, stmtInsertTypes);
  procStmtLHS[lhs.label].insert(rhs.label);
  procStmtRHS[rhs.label] = lhs.label;
  return true;
}

bool RelationStorage::insertIntoTransitiveMaps(
    unordered_map<EntityRef, unordered_set<EntityRef>>& tlhs,
    unordered_map<EntityRef, unordered_set<EntityRef>>& trhs,
    EntityRef lhsLabel, EntityRef rhsLabel) {
  tlhs[lhsLabel].insert(rhsLabel);
  if (tlhs.count(rhsLabel)) {
    auto& rhsProceeders = tlhs[rhsLabel];
    tlhs[lhsLabel].insert(rhsProceeders.begin(), rhsProceeders.end());
  }
  if (trhs.count(lhsLabel)) {
    for (auto& lhsPrecederLabel : trhs[lhsLabel]) {
      tlhs[lhsPrecederLabel].insert(tlhs[lhsLabel].begin(),
                                    tlhs[lhsLabel].end());
    }
  }
  trhs[rhsLabel].insert(lhsLabel);
  if (trhs.count(lhsLabel)) {
    auto& lhsPreceders = trhs[lhsLabel];
    trhs[rhsLabel].insert(lhsPreceders.begin(), lhsPreceders.end());
  }
  if (tlhs.count(rhsLabel)) {
    for (auto& rhsProceederLabel : tlhs[rhsLabel]) {
      trhs[rhsProceederLabel].insert(trhs[rhsLabel].begin(),
                                     trhs[rhsLabel].end());
    }
  }
  return true;
}

bool RelationStorage::hasRelation(const Entity& lhs, const Entity& rhs,
                                  RelationType rel) {
  // If wildcard, use SPA::WILDCARD
  switch (rel) {
    case SPA::FOLLOWS:
      return hasFollowsRel(lhs, rhs);
    case SPA::FOLLOWS_T:
      return hasFollowsTRel(lhs, rhs);
    case SPA::PARENT:
      return hasParentRel(lhs, rhs);
    case SPA::PARENT_T:
      return hasParentTRel(lhs, rhs);
    case SPA::USES:
      return hasUsesRel(lhs, rhs);
    case SPA::MODIFIES:
      return hasModifiesRel(lhs, rhs);
    case SPA::CALLS:
      return hasCallsRel(lhs, rhs);
    case SPA::CALLS_T:
      return hasCallsTRel(lhs, rhs);
    case SPA::NEXT:
      return hasNextRel(lhs, rhs);
    case SPA::NEXT_T:
      return hasNextTRel(lhs, rhs);
    case SPA::AFFECTS:
      return hasAffectsRel(lhs, rhs);
      break;
  }
  return false;
}

bool RelationStorage::hasParentTRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !parentTLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return parentTRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return parentTLHS.count(lhs.label);
  }
  return parentTRHS.count(rhs.label) && parentTRHS[rhs.label].count(lhs.label);
}

bool RelationStorage::hasParentRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !parentLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return parentRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return parentLHS.count(lhs.label);
  }
  return parentRHS.count(rhs.label) && parentRHS[rhs.label] == lhs.label;
}

bool RelationStorage::hasFollowsTRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !followsTLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return followsTRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return followsTLHS.count(lhs.label);
  }
  return followsTRHS.count(rhs.label) &&
         followsTRHS[rhs.label].count(lhs.label);
}

bool RelationStorage::hasFollowsRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !followsLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return followsRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return followsLHS.count(lhs.label);
  }
  return followsRHS.count(rhs.label) && followsRHS[rhs.label] == lhs.label;
}

bool RelationStorage::hasUsesRel(const Entity& lhs, const Entity& rhs) {
  // LHS should not be wildcard
  SPA::validateEntity(lhs, usesLHSQueryTypes);
  SPA::validateEntity(rhs, usesRHSQueryTypes);

  if (rhs == SPA::WILDCARD) {
    auto& LHSTable = (lhs.type == SPA::PROC) ? usesProc : usesStmt;
    return LHSTable.count(lhs.label);
  }
  return usesVar.count(rhs.label) && usesVar[rhs.label].count(lhs.label);
}

bool RelationStorage::hasModifiesRel(const Entity& lhs, const Entity& rhs) {
  // LHS should not be wildcard
  SPA::validateEntity(lhs, modifiesLHSQueryTypes);
  SPA::validateEntity(rhs, modifiesRHSQueryTypes);

  if (rhs == SPA::WILDCARD) {
    auto& LHSTable = (lhs.type == SPA::PROC) ? modifiesProc : modifiesStmt;
    return LHSTable.count(lhs.label);
  }
  return modifiesVar.count(rhs.label) &&
         modifiesVar[rhs.label].count(lhs.label);
}

bool RelationStorage::hasCallsTRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, callsQueryTypes);
  SPA::validateEntity(rhs, callsQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !callsTLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return callsTRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return callsTLHS.count(lhs.label);
  }
  return callsTLHS.count(lhs.label) && callsTLHS[lhs.label].count(rhs.label);
}

bool RelationStorage::hasCallsRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, callsQueryTypes);
  SPA::validateEntity(rhs, callsQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !callsLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return callsRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return callsLHS.count(lhs.label);
  }
  return callsLHS.count(lhs.label) && callsLHS[lhs.label].count(rhs.label);
}

bool RelationStorage::hasNextTRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !nextLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return nextRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return nextLHS.count(lhs.label);
  }
  // Check if stmts are in same procedure
  if (!procStmtRHS.empty() &&
      (!procStmtRHS.count(lhs.label) || !procStmtRHS.count(rhs.label) ||
       procStmtRHS[lhs.label] != procStmtRHS[rhs.label])) {
    return false;
  }
  return hasPath(nextLHS, lhs.label, rhs.label);
}

bool RelationStorage::hasNextRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return !nextLHS.empty();
  }
  if (lhs == SPA::WILDCARD) {
    return nextRHS.count(rhs.label);
  }
  if (rhs == SPA::WILDCARD) {
    return nextLHS.count(lhs.label);
  }
  return nextLHS.count(lhs.label) && nextLHS[lhs.label].count(rhs.label);
}

bool RelationStorage::hasAffectsRel(const Entity& lhs, const Entity& rhs) {
  SPA::validateEntity(lhs, stmtQueryTypes);
  SPA::validateEntity(rhs, stmtQueryTypes);

  if (lhs == SPA::WILDCARD && rhs == SPA::WILDCARD) {
    return hasAffectsRelBothWildcard();
  }
  if (lhs == SPA::WILDCARD) {
    if (!hasEntityType(rhs.label, SPA::ASSIGN_STMT)) return false;
    return hasAffectsRelLeftWildcard(rhs);
  }
  if (rhs == SPA::WILDCARD) {
    if (!hasEntityType(lhs.label, SPA::ASSIGN_STMT)) return false;
    return hasAffectsRelRightWildcard(lhs);
  }
  if (!hasEntityType(lhs.label, SPA::ASSIGN_STMT)) return false;
  if (!hasEntityType(rhs.label, SPA::ASSIGN_STMT)) return false;
  if (!modifiesAssignStmt.count(lhs.label)) return false;
  const EntityRef& modifiedVar = modifiesAssignStmt[lhs.label];
  if (!usesVarAssigns.count(modifiedVar)) return false;
  if (!usesVarAssigns[modifiedVar].count(rhs.label)) return false;

  // Check if stmts are in same procedure
  if (!procStmtRHS.empty() &&
      (!procStmtRHS.count(lhs.label) || !procStmtRHS.count(rhs.label) ||
       procStmtRHS[lhs.label] != procStmtRHS[rhs.label])) {
    return false;
  }
  unordered_set<EntityRef>& modifiesVarStmts = modifiesVarAffects[modifiedVar];
  auto allPaths = bfsAllPaths(nextLHS, lhs.label, rhs.label, false);
  for (const auto& path : allPaths) {
    for (const auto& stmtRef : path) {
      if (stmtRef == rhs.label) return true;
      if (modifiesVarStmts.count(stmtRef)) break;
    }
  }
  return false;
}

bool RelationStorage::hasAffectsRelRightWildcard(const Entity& lhs) {
  if (!modifiesAssignStmt.count(lhs.label)) return false;
  const EntityRef& modifiedVar = modifiesAssignStmt[lhs.label];
  if (!usesVarAssigns.count(modifiedVar)) return false;
  unordered_set<EntityRef>& usesVarAssignStmts = usesVarAssigns[modifiedVar];
  unordered_set<EntityRef>& modifiesVarStmts = modifiesVarAffects[modifiedVar];
  auto allMaxPaths = bfsAllPaths(nextLHS, lhs.label, "", true);
  for (const auto& path : allMaxPaths) {
    for (const auto& stmtRef : path) {
      if (usesVarAssignStmts.count(stmtRef)) return true;
      if (modifiesVarStmts.count(stmtRef)) break;
    }
  }
  return false;
}

bool RelationStorage::hasAffectsRelLeftWildcard(const Entity& rhs) {
  if (!usesAssignStmt.count(rhs.label)) return false;
  const unordered_set<EntityRef>& usedVars = usesAssignStmt[rhs.label];
  auto allReversedMaxPaths = bfsAllPaths(nextRHS, rhs.label, "", true);
  for (const auto& usedVar : usedVars) {
    unordered_set<EntityRef>& modifiesVarAssignStmts =
        modifiesVarAssigns[usedVar];
    unordered_set<EntityRef>& modifiesVarStmts = modifiesVarAffects[usedVar];
    for (const auto& revPath : allReversedMaxPaths) {
      for (const auto& stmtRef : revPath) {
        if (modifiesVarAssignStmts.count(stmtRef)) return true;
        // Path unusable if var modified by read/call before assign
        if (modifiesVarStmts.count(stmtRef)) break;
      }
    }
  }
  return false;
}

bool RelationStorage::hasAffectsRelBothWildcard() {
  if (usesAssignStmt.empty()) return false;
  auto& assignStmts = entityStorage.getEntities(SPA::ASSIGN_STMT);
  return std::any_of(assignStmts.begin(), assignStmts.end(),
                     [&](Entity assignStmt) {
                       return hasAffectsRelRightWildcard(assignStmt);
                     });
}

vector<EntityRef> RelationStorage::bfs(
    const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
    EntityRef from, EntityRef to) {
  // If FROM == TO, must be from path with at least 1 step
  queue<std::pair<EntityRef, EntityRef>> q;
  unordered_map<EntityRef, EntityRef> parentOf;
  vector<EntityRef> pathToFrom;

  if (!map.count(from)) return pathToFrom;
  const unordered_set<EntityRef>& fromChildren = map.at(from);
  for (const auto& c : fromChildren) {
    q.push(std::make_pair(c, from));
  }
  while (!q.empty()) {
    auto [currRef, parentRef] = q.front();
    q.pop();
    parentOf[currRef] = parentRef;
    if (currRef == to) {
      // Do pathfind here
      while (parentOf[currRef] != from) {
        pathToFrom.push_back(currRef);
        currRef = parentOf[currRef];
      }
      pathToFrom.push_back(currRef);
      return pathToFrom;
    }
    if (!map.count(currRef)) continue;
    const unordered_set<EntityRef>& childRefs = map.at(currRef);
    for (const auto& c : childRefs) {
      if (parentOf.count(c)) continue;
      q.push(std::make_pair(c, currRef));
    }
  }
  return pathToFrom;
}

bool RelationStorage::hasPath(
    const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
    EntityRef from, EntityRef to) {
  auto path = bfs(map, from, to);
  return path.size() > 0;
}

vector<vector<EntityRef>> RelationStorage::bfsAllPaths(
    const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
    EntityRef from, EntityRef to, bool maxPath) {
  // If FROM == TO, must be from path with at least 1 step
  // Queue contains pair of (vector path, set of all nodes in path)
  queue<std::pair<vector<EntityRef>, unordered_set<EntityRef>>> q;
  vector<vector<EntityRef>> allPaths;

  if (!map.count(from)) return allPaths;
  const unordered_set<EntityRef>& fromChildren = map.at(from);
  for (const auto& c : fromChildren) {
    q.push(std::make_pair(vector<EntityRef>{c}, unordered_set<EntityRef>{c}));
  }
  while (!q.empty()) {
    auto [currPath, visited] = std::move(q.front());
    q.pop();
    if (currPath.back() == to && !maxPath) {
      // Found a path to TO
      allPaths.push_back(currPath);
      continue;
    }
    if (!map.count(currPath.back())) {
      // Dead end, max length path
      if (maxPath) allPaths.push_back(currPath);
      continue;
    }
    const unordered_set<EntityRef>& childRefs = map.at(currPath.back());
    for (const auto& c : childRefs) {
      if (visited.count(c)) {
        // Repeated node, max length path
        if (maxPath) allPaths.push_back(currPath);
        continue;
      }
      // Make copies
      vector<EntityRef> nextPath = currPath;
      unordered_set<EntityRef> newVisited = visited;
      nextPath.push_back(c);
      newVisited.insert(c);
      q.push(std::make_pair(nextPath, newVisited));
    }
  }
  return allPaths;
}

}  // namespace PKB
