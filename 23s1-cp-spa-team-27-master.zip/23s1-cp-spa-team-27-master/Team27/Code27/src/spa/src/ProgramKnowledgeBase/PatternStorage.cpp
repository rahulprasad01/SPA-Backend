#include "PatternStorage.h"
#include <Common/Algorithms.h>
#include <Common/Entity.h>
#include <Common/Format.h>
#include <Common/SPADefinitions.h>
#include <queue>
#include <stack>
#include <unordered_map>

using namespace SPA;
using namespace PKB;

const unordered_map<RawToken, int> op_priority = {
    {"+", 0}, {"-", 0}, {"*", 1}, {"/", 1}, {"%", 1},
};

bool PatternStorage::insertAssignPattern(const Entity& stmt, const Entity& var,
                                         const vector<RawToken>& rightExpr) {
  SPA::validateEntity(stmt, SPA::ASSIGN_STMT);
  SPA::validateEntity(var, SPA::VAR);
  assignStmts.insert({stmt.label, Pattern(var, rightExpr)});
  return true;
}

bool PatternStorage::hasAssignPattern(const Entity& stmt, const Entity& lhs,
                                      const vector<RawToken>& toMatch,
                                      bool isPartial) {
  // lhs = Entity(EntityType::NULL_ENTITY, "") if wildcard
  // toMatch is empty if wildcard
  SPA::validateEntity(stmt, assignStmtQueryTypes);
  SPA::validateEntity(lhs, assignVarQueryTypes);

  if (!assignStmts.count(stmt.label)) return false;
  const Pattern& pattern = assignStmts.at(stmt.label);
  if (lhs != SPA::WILDCARD && pattern.lhs != lhs.label) return false;
  if (toMatch.empty()) return true;
  auto postFixToMatch = concat(infixToPostfix(toMatch), " ");
  if (!isPartial && pattern.rhs != postFixToMatch) return false;
  if (isPartial && pattern.rhs.find(postFixToMatch) == std::string::npos)
    return false;
  return true;
}

bool PatternStorage::insertContainerPattern(const Entity& stmt,
                                            const Entity& var) {
  SPA::validateEntity(stmt, containerStmtInsertTypes);
  SPA::validateEntity(var, SPA::VAR);
  auto& stmtTable =
      (stmt.type == SPA::IF_STMT) ? containerIfStmts : containerWhileStmts;
  stmtTable[stmt.label].insert(var.label);
  containerVars[var.label].insert(stmt.label);
  return true;
}

bool PatternStorage::hasContainerPattern(const Entity& stmt,
                                         const Entity& var) {
  SPA::validateEntity(stmt, containerStmtQueryTypes);
  SPA::validateEntity(var, containerVarQueryTypes);

  if (stmt == SPA::WILDCARD && var == SPA::WILDCARD) {
    return !containerVars.empty();
  }
  if (stmt == SPA::WILDCARD) {
    return containerVars.count(var.label);
  }
  auto& stmtTable =
      (stmt.type == SPA::IF_STMT) ? containerIfStmts : containerWhileStmts;
  if (var == SPA::WILDCARD) {
    return stmtTable.count(stmt.label);
  }
  return stmtTable.count(stmt.label) && stmtTable[stmt.label].count(var.label);
}
