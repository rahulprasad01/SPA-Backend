#pragma once
#include <string>
#include <unordered_map>
#include <vector>
#include "Common/Algorithms.h"
#include "Common/Entity.h"
#include "Common/Format.h"
#include "Common/SPADefinitions.h"
#include "Common/SPAException.h"

using std::unordered_map;
using std::vector;
using namespace SPA;

namespace PKB {

class InvalidExprException : public SPAException {
 public:
  InvalidExprException(std::string error)
      : SPAException("Invalid expression: " + error) {}
};

struct Pattern {
  std::string lhs;
  std::string rhs;
  Pattern(const Entity& var, const vector<RawToken>& right_expr) {
    var.validate();
    if (var.type != SPA::VAR) {
      throw InvalidEntityException(
          var,
          SPA::format(
              "Left hand side of pattern must be of type Variable, {} found",
              EntityToString(var.type)));
    }
    if (right_expr.empty()) {
      throw InvalidExprException("Empty expression");
    }
    lhs = var.label;
    auto postfix = infixToPostfix(right_expr);
    rhs = concat(postfix, " ");
  }
};

class PatternStorage {
 public:
  PatternStorage() {}
  PatternStorage(const PatternStorage&) = delete;
  PatternStorage& operator=(const PatternStorage&) = delete;

  // Ingests the left assigned entity and the infix notation list of tokens on
  // the expr's rhs
  bool insertAssignPattern(const Entity& stmt, const Entity& var,
                           const vector<RawToken>& rightExpr);
  // toMatch is the list of tokens (in infix notation) to identify
  bool hasAssignPattern(const Entity& stmt, const Entity& lhs,
                        const vector<RawToken>& toMatch, bool isPartial);

  bool insertContainerPattern(const Entity& stmt, const Entity& var);
  bool hasContainerPattern(const Entity& stmt, const Entity& var);

 private:
  unordered_map<EntityRef, Pattern> assignStmts;
  unordered_map<EntityRef, unordered_set<EntityRef>> containerIfStmts;
  unordered_map<EntityRef, unordered_set<EntityRef>> containerWhileStmts;
  unordered_map<EntityRef, unordered_set<EntityRef>> containerVars;

  const unordered_set<EntityType> containerStmtInsertTypes = {
      SPA::IF_STMT,
      SPA::WHILE_STMT,
  };

  const unordered_set<EntityType> assignStmtQueryTypes = {
      SPA::ASSIGN_STMT,
      EntityType::NULL_ENTITY,
  };
  const unordered_set<EntityType> assignVarQueryTypes = {
      SPA::VAR,
      EntityType::NULL_ENTITY,
  };
  const unordered_set<EntityType> containerStmtQueryTypes = {
      SPA::IF_STMT,
      SPA::WHILE_STMT,
      EntityType::NULL_ENTITY,
  };
  const unordered_set<EntityType> containerVarQueryTypes = {
      SPA::VAR,
      EntityType::NULL_ENTITY,
  };
};

};  // namespace PKB
