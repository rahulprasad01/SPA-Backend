#pragma once
#include <algorithm>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"
#include "EntityStorage.h"

using std::queue;
using std::unordered_map;
using std::unordered_set;
using std::vector;
using namespace SPA;

namespace PKB {

class RelationStorage {
 public:
  bool insertParent(const Entity& lhs, const Entity& rhs);
  bool insertFollows(const Entity& lhs, const Entity& rhs);
  bool insertUses(const Entity& lhs, const Entity& rhs);
  bool insertModifies(const Entity& lhs, const Entity& rhs);
  bool insertCalls(const Entity& lhs, const Entity& rhs);
  bool insertNext(const Entity& lhs, const Entity& rhs);
  bool insertProcStmt(const Entity& lhs, const Entity& rhs);

  bool hasRelation(const Entity& lhs, const Entity& rhs, RelationType rel);

  RelationStorage(EntityStorage& es) : entityStorage(es) {}
  RelationStorage(const RelationStorage&) = delete;
  RelationStorage& operator=(const RelationStorage&) = delete;

 private:
  bool hasParentRel(const Entity& lhs, const Entity& rhs);
  bool hasParentTRel(const Entity& lhs, const Entity& rhs);
  bool hasFollowsRel(const Entity& lhs, const Entity& rhs);
  bool hasFollowsTRel(const Entity& lhs, const Entity& rhs);
  bool hasUsesRel(const Entity& lhs, const Entity& rhs);
  bool hasModifiesRel(const Entity& lhs, const Entity& rhs);
  bool hasCallsRel(const Entity& lhs, const Entity& rhs);
  bool hasCallsTRel(const Entity& lhs, const Entity& rhs);
  bool hasNextRel(const Entity& lhs, const Entity& rhs);
  bool hasNextTRel(const Entity& lhs, const Entity& rhs);
  bool hasAffectsRel(const Entity& lhs, const Entity& rhs);
  bool hasAffectsRelLeftWildcard(const Entity& rhs);
  bool hasAffectsRelRightWildcard(const Entity& lhs);
  bool hasAffectsRelBothWildcard();

  bool insertIntoTransitiveMaps(
      unordered_map<EntityRef, unordered_set<EntityRef>>& tlhs,
      unordered_map<EntityRef, unordered_set<EntityRef>>& trhs,
      EntityRef lhsLabel, EntityRef rhsLabel);

  vector<EntityRef> bfs(
      const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
      EntityRef from, EntityRef to);
  vector<vector<EntityRef>> bfsAllPaths(
      const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
      EntityRef from, EntityRef to, bool maxPath);

  bool hasPath(const unordered_map<EntityRef, unordered_set<EntityRef>>& map,
               EntityRef from, EntityRef to);
  inline bool hasEntityType(const EntityRef label, EntityType type) {
    auto& entityTypes = entityStorage.getEntityTypeOfLabel(label);
    return entityTypes.count(type);
  };
  inline bool hasEntityType(const EntityRef label,
                            unordered_set<EntityType> types) {
    auto& entityTypes = entityStorage.getEntityTypeOfLabel(label);
    return std::any_of(
        types.begin(), types.end(),
        [&entityTypes](EntityType type) { return entityTypes.count(type); });
  };

  EntityStorage& entityStorage;

  // All entities are stmts
  unordered_map<EntityRef, unordered_set<EntityRef>> parentLHS;
  unordered_map<EntityRef, EntityRef> parentRHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> parentTLHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> parentTRHS;
  unordered_map<EntityRef, EntityRef> followsLHS;
  unordered_map<EntityRef, EntityRef> followsRHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> followsTLHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> followsTRHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> nextLHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> nextRHS;

  // LHS is StmtRef or ProcRef, RHS is VarRef. Key is in name of map.
  unordered_map<EntityRef, unordered_set<EntityRef>> usesProc;
  unordered_map<EntityRef, unordered_set<EntityRef>> usesStmt;
  unordered_map<EntityRef, unordered_set<EntityRef>> usesAssignStmt;
  unordered_map<EntityRef, unordered_set<EntityRef>> usesVar;
  unordered_map<EntityRef, unordered_set<EntityRef>> usesVarAssigns;
  unordered_map<EntityRef, unordered_set<EntityRef>> modifiesProc;
  unordered_map<EntityRef, unordered_set<EntityRef>> modifiesStmt;
  unordered_map<EntityRef, EntityRef> modifiesAssignStmt;
  unordered_map<EntityRef, unordered_set<EntityRef>> modifiesVar;
  unordered_map<EntityRef, unordered_set<EntityRef>> modifiesVarAssigns;
  unordered_map<EntityRef, unordered_set<EntityRef>> modifiesVarAffects;

  // All entities are procs
  unordered_map<EntityRef, unordered_set<EntityRef>> callsLHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> callsRHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> callsTLHS;
  unordered_map<EntityRef, unordered_set<EntityRef>> callsTRHS;

  // LHS is ProcRef, RHS is StmtRef
  unordered_map<EntityRef, unordered_set<EntityRef>> procStmtLHS;
  unordered_map<EntityRef, EntityRef> procStmtRHS;

  const unordered_set<EntityType> stmtInsertTypes = {
      SPA::ASSIGN_STMT, SPA::IF_STMT,   SPA::WHILE_STMT, SPA::CALL_STMT,
      SPA::PRINT_STMT,  SPA::READ_STMT, SPA::STMT,
  };

  const unordered_set<EntityType> parentLHSInsertTypes = {
      SPA::IF_STMT, SPA::WHILE_STMT, SPA::STMT};

  const unordered_set<EntityType> usesLHSInsertTypes = {
      SPA::PROC,       SPA::ASSIGN_STMT, SPA::IF_STMT,
      SPA::WHILE_STMT, SPA::CALL_STMT,   SPA::PRINT_STMT,
  };

  const unordered_set<EntityType> modifiesLHSInsertTypes = {
      SPA::PROC,       SPA::ASSIGN_STMT, SPA::IF_STMT,
      SPA::WHILE_STMT, SPA::CALL_STMT,   SPA::READ_STMT,
  };

  const unordered_set<EntityType> stmtQueryTypes = {
      SPA::ASSIGN_STMT, SPA::IF_STMT,   SPA::WHILE_STMT, SPA::CALL_STMT,
      SPA::PRINT_STMT,  SPA::READ_STMT, SPA::STMT,       SPA::NULL_ENTITY,
  };

  const unordered_set<EntityType> usesLHSQueryTypes = {
      SPA::PROC,      SPA::ASSIGN_STMT, SPA::IF_STMT,   SPA::WHILE_STMT,
      SPA::CALL_STMT, SPA::PRINT_STMT,  SPA::READ_STMT, SPA::STMT,
  };
  const unordered_set<EntityType> usesRHSQueryTypes = {
      SPA::VAR,
      SPA::NULL_ENTITY,
  };

  const unordered_set<EntityType> modifiesLHSQueryTypes = {
      SPA::PROC,      SPA::ASSIGN_STMT, SPA::IF_STMT,   SPA::WHILE_STMT,
      SPA::CALL_STMT, SPA::PRINT_STMT,  SPA::READ_STMT, SPA::STMT,
  };
  const unordered_set<EntityType> modifiesRHSQueryTypes = {
      SPA::VAR,
      SPA::NULL_ENTITY,
  };

  const unordered_set<EntityType> callsQueryTypes = {
      SPA::PROC,
      SPA::NULL_ENTITY,
  };

  const unordered_set<EntityType> affectsModifiableTypes = {
      SPA::ASSIGN_STMT,
      SPA::READ_STMT,
      SPA::CALL_STMT,
  };
};

}  // namespace PKB
