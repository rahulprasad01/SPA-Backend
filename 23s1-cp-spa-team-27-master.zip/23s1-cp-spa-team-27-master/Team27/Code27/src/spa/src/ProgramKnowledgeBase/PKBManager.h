#pragma once
#include <memory>
#include "EntityStorage.h"
#include "PatternStorage.h"
#include "RelationStorage.h"

using namespace SPA;

namespace PKB {

class PKBManager {
 public:
  PKBManager() : entities(), relations(entities), patterns() {}
  EntityStorage& getEntityStorageHandle() { return entities; }
  RelationStorage& getRelationStorageHandle() { return relations; }
  PatternStorage& getPatternStorageHandle() { return patterns; }

  PKBManager(const PKBManager&) = delete;
  PKBManager& operator=(const PKBManager&) = delete;

 private:
  EntityStorage entities;
  RelationStorage relations;
  PatternStorage patterns;
};

}  // namespace PKB
