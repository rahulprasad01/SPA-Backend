#pragma once
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"

using std::unordered_map;
using std::unordered_set;
using std::vector;
using namespace SPA;

namespace PKB {
class EntityStorage {
 public:
  bool insertEntity(const Entity& entity);
  unordered_set<EntityType>& getEntityTypeOfLabel(EntityRef label);
  // unordered_set<EntityRef>& getEntitiesOfType(EntityType type);
  unordered_set<Entity, Entity::KeyHasher>& getEntities(EntityType type);

  EntityStorage()
      : entityTypeToRef(ENTITY_TYPE_COUNT),
        entityTypeToEntity(ENTITY_TYPE_COUNT) {}
  EntityStorage(const EntityStorage&) = delete;
  EntityStorage& operator=(const EntityStorage&) = delete;

 private:
  unordered_map<EntityRef, unordered_set<EntityType>> entityRefToType;
  // unordered_map<EntityType, unordered_set<EntityRef>> entityTypeToRef;
  vector<unordered_set<EntityRef>> entityTypeToRef;
  // unordered_map<EntityType, unordered_set<Entity, Entity::KeyHasher>>
  // entityTypeToEntity;
  vector<unordered_set<Entity, Entity::KeyHasher>> entityTypeToEntity;
};
}  // namespace PKB
