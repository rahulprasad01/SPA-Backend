#include "EntityStorage.h"
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"

using namespace PKB;

bool EntityStorage::insertEntity(const Entity& entity) {
  entity.validate();
  entityRefToType[entity.label].insert(entity.type);
  unordered_set<Entity, Entity::KeyHasher>& entities =
      entityTypeToEntity[entity.type];
  entities.insert(entity);

  if (entity.isStmt() && entity.type != SPA::STMT) {
    unordered_set<Entity, Entity::KeyHasher>& entityStmts =
        entityTypeToEntity[SPA::STMT];
    entityStmts.insert(entity);
  }
  return true;
}

unordered_set<EntityType>& EntityStorage::getEntityTypeOfLabel(
    EntityRef label) {
  return entityRefToType[label];
}

unordered_set<Entity, Entity::KeyHasher>& EntityStorage::getEntities(
    EntityType type) {
  return entityTypeToEntity[type];
}
