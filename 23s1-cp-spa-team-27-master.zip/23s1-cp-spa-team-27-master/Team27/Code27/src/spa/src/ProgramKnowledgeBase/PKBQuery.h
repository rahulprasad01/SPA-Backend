#pragma once
#include <unordered_set>
#include "Common/Entity.h"
#include "PKBManager.h"

using std::unordered_set;
using namespace SPA;

namespace PKB {

class PKBQuery {
 public:
  PKBQuery(PKBManager& pkb) : pkbManager(pkb) {}

  const unordered_set<EntityType>& getEntityTypeOfLabel(EntityRef label) const;
  const unordered_set<Entity, Entity::KeyHasher>& getEntities(
      EntityType type) const;

  bool hasRelation(const Entity& lhs, const Entity& rhs,
                   RelationType rel) const;

  bool hasAssignPattern(const Entity& stmt, const Entity& lhs,
                        const vector<RawToken>& toMatch, bool isPartial) const;
  bool hasContainerPattern(const Entity& stmt, const Entity& var) const;

 private:
  PKBManager& pkbManager;
};

}  // namespace PKB
