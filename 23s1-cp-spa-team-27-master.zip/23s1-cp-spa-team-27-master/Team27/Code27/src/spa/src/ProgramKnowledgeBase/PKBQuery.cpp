#include "PKBQuery.h"
#include "EntityStorage.h"
#include "PatternStorage.h"
#include "RelationStorage.h"

using namespace SPA;

namespace PKB {
const unordered_set<EntityType>& PKBQuery::getEntityTypeOfLabel(
    EntityRef label) const {
  EntityStorage& entities = pkbManager.getEntityStorageHandle();
  return entities.getEntityTypeOfLabel(label);
};
const unordered_set<Entity, Entity::KeyHasher>& PKBQuery::getEntities(
    EntityType type) const {
  EntityStorage& entities = pkbManager.getEntityStorageHandle();
  return entities.getEntities(type);
};

bool PKBQuery::hasRelation(const Entity& lhs, const Entity& rhs,
                           RelationType rel) const {
  RelationStorage& relations = pkbManager.getRelationStorageHandle();
  return relations.hasRelation(lhs, rhs, rel);
};

bool PKBQuery::hasAssignPattern(const Entity& stmt, const Entity& lhs,
                                const vector<RawToken>& toMatch,
                                bool isPartial) const {
  PatternStorage& patterns = pkbManager.getPatternStorageHandle();
  return patterns.hasAssignPattern(stmt, lhs, toMatch, isPartial);
};

bool PKBQuery::hasContainerPattern(const Entity& stmt,
                                   const Entity& var) const {
  PatternStorage& patterns = pkbManager.getPatternStorageHandle();
  return patterns.hasContainerPattern(stmt, var);
}

}  // namespace PKB
