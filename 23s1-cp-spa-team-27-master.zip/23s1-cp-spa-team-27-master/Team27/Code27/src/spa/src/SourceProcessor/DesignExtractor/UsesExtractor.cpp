#include "UsesExtractor.h"

namespace SP {

void UsesExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  calledToCallerProcs.resize(procs.size());
  procToVarsUsed.resize(procs.size());
  for (size_t i = 0; i < procs.size(); i++) {
    procToNum[procs[i]->procName] = i;
  }
  currProcNum = 0;
  for (const auto& proc : procs) {
    proc->accept(*this);
    currProcNum++;
  }
  firstPass = false;
  vector<size_t> sortedProcOrder = toposort(calledToCallerProcs);
  if (sortedProcOrder.empty()) {
    throw SemanticError(
        "Missing procedure call, or cycle detected in programs");
  }
  for (size_t index : sortedProcOrder) {
    currProcNum = index;
    procs[index]->accept(*this);
  }
}

void UsesExtractor::insert(PKB::PKBInsert& pkb) {
  for (const auto& [stmt, varList] : userToUsed) {
    for (const auto& varName : varList) {
      pkb.insertUses(stmt, Entity(VAR, varName));
    }
  }
  for (const auto& [procName, idx] : procToNum) {
    Entity procEntity(PROC, procName);
    const auto& varList = procToVarsUsed[idx];
    for (const auto& varName : varList) {
      pkb.insertUses(procEntity, Entity(VAR, varName));
    }
  }
}

void UsesExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}

void UsesExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void UsesExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (firstPass && stmt->stmtType == CALL_STMT) {
    calledToCallerProcs[procToNum[stmt->operand->value]].insert(currProcNum);
    return;
  } else if (!firstPass) {
    switch (stmt->stmtType) {
      case PRINT_STMT:
        addUses(stmt->stmtNum, stmt->operand->value, stmt->stmtType);
        break;
      case CALL_STMT:
        const auto& indirectModified =
            procToVarsUsed[procToNum[stmt->operand->value]];
        for (const auto& iv : indirectModified) {
          addUses(stmt->stmtNum, iv, stmt->stmtType);
        }
        break;
    }
  }
}

void UsesExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  if (!firstPass) {
    for (const auto& v : stmt->vars) {
      addUses(stmt->stmtNum, v->value, stmt->stmtType);
    }
  }
}

void UsesExtractor::visitIfStmt(const IfStmtAST* stmt) {
  userStack.push_back(Entity(stmt->stmtType, stmt->stmtNum));
  for (const auto& u : stmt->vars) {
    addUses(stmt->stmtNum, u->value, stmt->stmtType);
  }
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
  userStack.pop_back();
}

void UsesExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  userStack.push_back(Entity(stmt->stmtType, stmt->stmtNum));
  for (const auto& u : stmt->vars) {
    addUses(stmt->stmtNum, u->value, stmt->stmtType);
  }
  stmt->stmtList->accept(*this);
  userStack.pop_back();
}

unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
UsesExtractor::getStmtOrProcToVars() const {
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher> map =
      userToUsed;
  for (const auto& [procName, idx] : procToNum) {
    Entity procEntity(PROC, procName);
    const auto& varList = procToVarsUsed[idx];
    for (const auto& varName : varList) {
      map[procEntity].insert(varName);
    }
  }
  return map;
}

void UsesExtractor::addUses(std::string lhs, std::string varName,
                            EntityType type) {
  userToUsed[Entity(type, lhs)].insert(varName);
  procToVarsUsed[currProcNum].insert(varName);
  for (const auto& e : userStack) {
    userToUsed[e].insert(varName);
  }
}
}  // namespace SP