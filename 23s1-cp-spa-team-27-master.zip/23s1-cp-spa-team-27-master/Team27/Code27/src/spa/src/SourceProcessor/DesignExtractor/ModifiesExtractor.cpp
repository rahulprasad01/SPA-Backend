#include "ModifiesExtractor.h"

namespace SP {

void ModifiesExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  calledToCallerProcs.resize(procs.size());
  procToVarsModified.resize(procs.size());
  for (size_t i = 0; i < procs.size(); i++) {
    procToNum[procs[i]->procName] = i;
  }
  currProcNum = 0;
  for (const auto& proc : procs) {
    proc->accept(*this);
    currProcNum++;
  }
  firstPass = false;
  vector<size_t> sortedProcOrder = toposort(calledToCallerProcs);
  if (sortedProcOrder.empty()) {
    throw SemanticError(
        "Missing procedure call, or cycle detected in programs");
  }
  for (size_t index : sortedProcOrder) {
    currProcNum = index;
    procs[index]->accept(*this);
  }
}

void ModifiesExtractor::insert(PKB::PKBInsert& pkb) {
  for (const auto& [stmt, varList] : modifierToModified) {
    for (const auto& varName : varList) {
      pkb.insertModifies(stmt, Entity(VAR, varName));
    }
  }
  for (const auto& [procName, idx] : procToNum) {
    Entity procEntity(PROC, procName);
    const auto& varList = procToVarsModified[idx];
    for (const auto& varName : varList) {
      pkb.insertModifies(procEntity, Entity(VAR, varName));
    }
  }
}

void ModifiesExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}

void ModifiesExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void ModifiesExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (firstPass && stmt->stmtType == CALL_STMT) {
    calledToCallerProcs[procToNum[stmt->operand->value]].insert(currProcNum);
    return;
  } else if (!firstPass) {
    switch (stmt->stmtType) {
      case READ_STMT:
        addModifies(stmt->stmtNum, stmt->operand->value, stmt->stmtType);
        break;
      case CALL_STMT:
        const auto& indirectModified =
            procToVarsModified[procToNum[stmt->operand->value]];
        for (const auto& iv : indirectModified) {
          addModifies(stmt->stmtNum, iv, stmt->stmtType);
        }
        break;
    }
  }
}

void ModifiesExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  if (!firstPass) {
    addModifies(stmt->stmtNum, stmt->lhs->value, stmt->stmtType);
  }
}

void ModifiesExtractor::visitIfStmt(const IfStmtAST* stmt) {
  modifierStack.push_back(Entity(stmt->stmtType, stmt->stmtNum));
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
  modifierStack.pop_back();
}

void ModifiesExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  modifierStack.push_back(Entity(stmt->stmtType, stmt->stmtNum));
  stmt->stmtList->accept(*this);
  modifierStack.pop_back();
}

unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
ModifiesExtractor::getStmtOrProcToVars() const {
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher> map =
      modifierToModified;
  for (const auto& [procName, idx] : procToNum) {
    Entity procEntity(PROC, procName);
    const auto& varList = procToVarsModified[idx];
    for (const auto& varName : varList) {
      map[procEntity].insert(varName);
    }
  }
  return map;
}

void ModifiesExtractor::addModifies(std::string lhs, std::string varName,
                                    EntityType type) {
  modifierToModified[Entity(type, lhs)].insert(varName);
  procToVarsModified[currProcNum].insert(varName);
  for (const auto& e : modifierStack) {
    modifierToModified[e].insert(varName);
  }
}
}  // namespace SP
