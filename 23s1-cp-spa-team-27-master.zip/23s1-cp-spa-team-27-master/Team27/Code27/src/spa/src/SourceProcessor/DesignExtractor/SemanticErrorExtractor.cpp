#include "SemanticErrorExtractor.h"

namespace SP {

void SemanticErrorExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  size_t idx = 0;
  callsMap.reserve(procs.size());
  for (const auto& proc : procs) {
    if (procNames.count(proc->procName) > 0) {
      throw SemanticError(
          SPA::format("The process '{}' is already defined", proc->procName));
    }
    procNames.insert({proc->procName, idx++});
    callsMap.push_back({});
  }
  for (const auto& proc : procs) {
    currProcId = procNames[proc->procName];
    proc->accept(*this);
  }
  if (hasCycle(callsMap)) {
    throw SemanticError(SPA::format("Cycle detected in calls"));
  }
}

void SemanticErrorExtractor::insert(PKB::PKBInsert& pkb) {}

void SemanticErrorExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}

void SemanticErrorExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void SemanticErrorExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (stmt->stmtType == CALL_STMT) {
    if (procNames.count(stmt->operand->value) == 0) {
      throw SemanticError(SPA::format("The process '{}' has not been defined",
                                      stmt->operand->value));
    }
    callsMap[currProcId].insert(procNames[stmt->operand->value]);
  }
}

void SemanticErrorExtractor::visitAssignStmt(const AssignStmtAST* stmt) {}

void SemanticErrorExtractor::visitIfStmt(const IfStmtAST* stmt) {
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
}

void SemanticErrorExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  stmt->stmtList->accept(*this);
}

}  // namespace SP
