#pragma once
#include <iostream>
#include <stack>
#include <stdexcept>
#include <utility>
#include <vector>
#include "../AST.h"
#include "Common/Algorithms.h"
#include "DesignExtractor.h"
#include "SemanticErrorExtractor.h"

using std::vector;
using ModPair = std::pair<std::string, std::string>;
using namespace SPA;

namespace SP {
class ModifiesExtractor : public DesignExtractor {
 public:
  void run(const vector<shared_ptr<ProcAST>>& procs) override;
  void insert(PKB::PKBInsert& pkb) override;
  void visitProc(const ProcAST* proc) override;
  void visitStmtList(const StmtListAST* stmtList) override;
  void visitUnaryStmt(const UnaryStmtAST* stmt) override;
  void visitAssignStmt(const AssignStmtAST* stmt) override;
  void visitIfStmt(const IfStmtAST* stmt) override;
  void visitWhileStmt(const WhileStmtAST* stmt) override;
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
  getStmtOrProcToVars() const;

 private:
  bool firstPass = true;
  unordered_map<std::string, size_t> procToNum;
  vector<Entity> modifierStack;
  vector<unordered_set<size_t>> calledToCallerProcs;
  vector<unordered_set<std::string>> procToVarsModified;
  size_t currProcNum;
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
      modifierToModified;
  void addModifies(std::string lhs, std::string varName, EntityType type);
};

}  // namespace SP
