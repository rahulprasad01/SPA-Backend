#pragma once
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include "../AST.h"
#include "Common/Algorithms.h"
#include "Common/Format.h"
#include "Common/SPAException.h"
#include "DesignExtractor.h"
#include "ProgramKnowledgeBase/PKBInsert.h"

using std::unordered_map;
using std::unordered_set;
using ProcPair = std::pair<std::string, std::string>;

class SemanticError : public SPA::SPAException {
 public:
  SemanticError(std::string reason)
      : SPA::SPAException(SPA::format("Source Semantic error: {}", reason)) {}
};

namespace SP {
class SemanticErrorExtractor : public DesignExtractor {
 public:
  void run(const vector<shared_ptr<ProcAST>>& procs) override;
  void insert(PKB::PKBInsert& pkb) override;
  void visitProc(const ProcAST* proc) override;
  void visitStmtList(const StmtListAST* stmtList) override;
  void visitUnaryStmt(const UnaryStmtAST* stmt) override;
  void visitAssignStmt(const AssignStmtAST* stmt) override;
  void visitIfStmt(const IfStmtAST* stmt) override;
  void visitWhileStmt(const WhileStmtAST* stmt) override;

 private:
  unordered_map<std::string, size_t> procNames;
  size_t currProcId;
  vector<unordered_set<size_t>> callsMap;  // callsMap[caller] = set of callees.
};

}  // namespace SP
