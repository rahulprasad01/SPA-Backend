#pragma once
#include <utility>
#include <vector>
#include "Common/Entity.h"
#include "DesignExtractor.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "SourceProcessor/AST.h"

using std::vector;
using StmtLHSExpr = std::tuple<Entity, Entity, vector<RawToken>>;
using StmtExpr = std::pair<Entity, unordered_set<RawToken>>;

namespace SP {
class PatternExtractor : public DesignExtractor {
 public:
  void run(const vector<shared_ptr<ProcAST>>& procs) override;
  void insert(PKB::PKBInsert& pkb) override;
  void visitProc(const ProcAST* proc) override;
  void visitStmtList(const StmtListAST* stmtList) override;
  void visitUnaryStmt(const UnaryStmtAST* stmt) override;
  void visitAssignStmt(const AssignStmtAST* stmt) override;
  void visitIfStmt(const IfStmtAST* stmt) override;
  void visitWhileStmt(const WhileStmtAST* stmt) override;

  vector<StmtLHSExpr>& getAssign();
  vector<StmtExpr>& getContainers();

 private:
  vector<StmtLHSExpr> assign;
  vector<StmtExpr> containers;
};

}  // namespace SP
