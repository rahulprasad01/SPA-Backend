#pragma once

#include <fstream>
#include <memory>
#include <sstream>
#include <vector>
#include "Common/Timer.h"
#include "Common/Utility.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "SIMPLETokenizer.h"
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/CallsExtractor.h"
#include "SourceProcessor/DesignExtractor/EntityExtractor.h"
#include "SourceProcessor/DesignExtractor/FollowsExtractor.h"
#include "SourceProcessor/DesignExtractor/ModifiesExtractor.h"
#include "SourceProcessor/DesignExtractor/NextExtractor.h"
#include "SourceProcessor/DesignExtractor/ParentExtractor.h"
#include "SourceProcessor/DesignExtractor/PatternExtractor.h"
#include "SourceProcessor/DesignExtractor/ProcStmtExtractor.h"
#include "SourceProcessor/DesignExtractor/SemanticErrorExtractor.h"
#include "SourceProcessor/DesignExtractor/UsesExtractor.h"
#include "SourceProcessor/SIMPLEParser.h"

using std::shared_ptr;
using std::vector;

namespace SP {

class SourceProcessor {
 private:
  PKB::PKBInsert& pkbInsert;

 public:
  SourceProcessor(PKB::PKBInsert& pkbInsert) : pkbInsert(pkbInsert) {}
  void process(const std::string& filepath);
};

inline void SourceProcessor::process(const std::string& filepath) {
  std::ifstream readFile(filepath);
  std::stringstream text;
  std::string currLine;
  while (getline(readFile, currLine)) {
    text << currLine;
  }
  std::string output = text.str();

  shared_ptr<SourceParser> parser = make_shared<SIMPLEParser>();
  std::vector<std::shared_ptr<ProcAST>> procASTs = parser->parse(output);

  SemanticErrorExtractor semanticCheck;
  semanticCheck.run(procASTs);

  std::vector<std::shared_ptr<DesignExtractor>> designExtractors = {
      make_shared<EntityExtractor>(),   make_shared<ParentExtractor>(),
      make_shared<FollowsExtractor>(),  make_shared<UsesExtractor>(),
      make_shared<ModifiesExtractor>(), make_shared<PatternExtractor>(),
      make_shared<CallsExtractor>(),    make_shared<NextExtractor>(),
      make_shared<ProcStmtExtractor>(),
  };

  OMP_PARALLEL_FOR
  for (const auto& extractor : designExtractors) {
    extractor->run(procASTs);
    OMP_CRITICAL { extractor->insert(pkbInsert); }
  }
}

}  // namespace SP
