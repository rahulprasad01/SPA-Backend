#pragma once
#include <memory>
#include <vector>
#include "AST.h"
#include "Common/Format.h"
#include "Common/SPAException.h"
#include "SIMPLETokenizer.h"
#include "SourceParser.h"
using std::shared_ptr;
using std::vector;

namespace SP {

class SyntaxError : public SPA::SPAException {
 public:
  SyntaxError(SIMPLEToken token, std::string reason)
      : SPAException(SPA::format("Invalid token {}: {}", token.value, reason)) {
  }
  SyntaxError(std::string reason)
      : SPAException(SPA::format("Syntax error: {}", reason)) {}
};

class SIMPLEParser : public SourceParser {
 public:
  SIMPLEParser() : currStmtNum(0), pos(0) {}
  vector<shared_ptr<ProcAST>> parse(const std::string& text);
  vector<shared_ptr<ProcAST>> parseTokens(const vector<SIMPLEToken>& tokens);

 private:
  void reset();
  const SIMPLEToken& peek(size_t idx = 0);
  const SIMPLEToken& step();
  bool isKeyword(const std::string& keyword);
  void checkKeyword(const std::string& keyword);
  EntityType whichStmtType();
  shared_ptr<ProcAST> readProc();
  shared_ptr<StmtListAST> readStmtList();
  shared_ptr<UnaryStmtAST> readUnaryStmt(EntityType type,
                                         const std::string& keyword);
  shared_ptr<WhileStmtAST> readWhileStmt();
  shared_ptr<IfStmtAST> readIfStmt();
  shared_ptr<AssignStmtAST> readAssignStmt();
  shared_ptr<VarAST> readVar();
  shared_ptr<ConstAST> readConst();
  std::tuple<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>,
             vector<RawToken>>
  readExpr();
  std::pair<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>>
  readRelExpr();
  std::pair<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>>
  readCondExpr();
  SIMPLETokenizer tokenizer;

  vector<SIMPLEToken> tokens;
  size_t pos;
  size_t currStmtNum;
};

}  // namespace SP