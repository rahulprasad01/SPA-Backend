#include "SIMPLETokenizer.h"
#include <iostream>
#include <unordered_set>

using namespace SP;

const std::unordered_set<char> delimiters_heads = {'(', ')', '"',
                                                   ';', '{', '}'};
const std::unordered_set<char> arith_ops = {'+', '-', '*', '/', '%'};
const std::unordered_set<char> cond_ops_heads = {'|', '&', '!'};
const std::unordered_set<std::string> cond_ops = {"||", "&&", "!"};
const std::unordered_set<char> rel_ops_heads = {'<', '>', '!', '='};
const std::unordered_set<std::string> rel_ops = {
    "<", ">", "<=", ">=", "==", "!=", "="};

vector<SIMPLEToken> SIMPLETokenizer::tokenize(const std::string& fulltext,
                                              bool ignoreSpaces) {
  vector<SIMPLEToken> tokens;
  charPos = 0;
  this->text = fulltext;
  int len = text.length();
  while (charPos < len) {
    std::string tokenValue = "";
    SIMPLETokenType tokenType;
    char c = peek();
    if (c == EOF) {
      break;
    } else if (isspace(c)) {
      tokenType = SIMPLETokenType::WHITESPACE;
      tokenValue = readSpace();
    } else if (isdigit(c)) {
      tokenType = SIMPLETokenType::NUMBER;
      tokenValue = readNumber();
    } else if (isDelimiter(c)) {
      tokenType = SIMPLETokenType::DELIMITER;
      tokenValue = readDelimiter();
    } else if (isArithmeticOp(c)) {
      tokenType = SIMPLETokenType::ARITH_OP;
      tokenValue = readArithmeticOp();
    } else if (isCondOp(c, peek(1))) {
      tokenType = SIMPLETokenType::COND_OP;
      tokenValue = readCondOp();
    } else if (isRelOp(c)) {
      tokenType = SIMPLETokenType::REL_OP;
      tokenValue = readRelOp();
    } else if (isWord(c)) {
      tokenType = SIMPLETokenType::WORD;
      tokenValue = readWord();
    } else {
      throw InvalidLexicalTokenException(std::string(1, peek()), "OTHER",
                                         charPos);
    }
    if (tokenValue.length() == 0) {
      throw InvalidLexicalTokenException(tokenValue, "UNKNOWN", charPos);
    } else if (ignoreSpaces && tokenType == SIMPLETokenType::WHITESPACE) {
      continue;
    }
    tokens.push_back(SIMPLEToken{tokenType, tokenValue});
  }
  return tokens;
}

bool SIMPLETokenizer::isDelimiter(char c) { return delimiters_heads.count(c); }

std::string SIMPLETokenizer::readDelimiter() {
  char c = peek();
  if (!delimiters_heads.count(c)) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "DELIMITER",
                                       charPos);
  }
  return std::string(1, step());
}

bool SIMPLETokenizer::isArithmeticOp(char c) { return arith_ops.count(c) > 0; }

std::string SIMPLETokenizer::readArithmeticOp() {
  char c = peek();
  if (!arith_ops.count(c)) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "ARITH_OP",
                                       charPos);
  }
  return std::string(1, step());
}

bool SIMPLETokenizer::isCondOp(char c, char cnext) {
  return cond_ops_heads.count(c) && !rel_ops.count({c, cnext});
}

std::string SIMPLETokenizer::readCondOp() {
  char c = peek();
  if (!cond_ops_heads.count(c)) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "COND_OP",
                                       charPos);
  }
  std::string token = std::string(1, step());
  std::string token_next = token + peek();
  if (cond_ops.count(token_next)) {
    step();
    return token_next;
  } else if (cond_ops.count(token)) {
    return token;
  } else {
    throw InvalidLexicalTokenException(token_next, "COND_OP", charPos);
  }
}

bool SIMPLETokenizer::isRelOp(char c) { return rel_ops_heads.count(c); }

std::string SIMPLETokenizer::readRelOp() {
  char c = peek();
  if (rel_ops_heads.count(c)) {
    std::string token = std::string(1, step());
    std::string token_next = token + peek();
    if (rel_ops.count(token_next)) {
      step();
      return token_next;
    } else if (rel_ops.count(token)) {
      return token;
    } else {
      throw InvalidLexicalTokenException(token_next, "REL_OP", charPos);
    }
  }
  throw InvalidLexicalTokenException(std::string(1, peek()), "REL_OP", charPos);
}