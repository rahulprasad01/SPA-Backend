#include "PatternExtractor.h"

namespace SP {

void PatternExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}

void PatternExtractor::insert(PKB::PKBInsert& pkb) {
  for (const auto& [stmt, lhs, rhs] : assign) {
    pkb.insertAssignPattern(stmt, lhs, rhs);
  }
  for (const auto& [stmt, set] : containers) {
    for (const auto& v : set) {
      pkb.insertContainerPattern(stmt, Entity(SPA::VAR, v));
    }
  }
}

void PatternExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}

void PatternExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void PatternExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {}

void PatternExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  assign.push_back({Entity(SPA::ASSIGN_STMT, stmt->stmtNum),
                    Entity(SPA::VAR, stmt->lhs->value), stmt->expr});
}

void PatternExtractor::visitIfStmt(const IfStmtAST* stmt) {
  unordered_set<RawToken> expr;
  for (const auto& var : stmt->vars) {
    expr.insert(var->value);
  }
  containers.push_back({Entity(IF_STMT, stmt->stmtNum), expr});
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
}

void PatternExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  unordered_set<RawToken> expr;
  for (const auto& var : stmt->vars) {
    expr.insert(var->value);
  }
  containers.push_back({Entity(WHILE_STMT, stmt->stmtNum), expr});
  stmt->stmtList->accept(*this);
}

vector<StmtLHSExpr>& PatternExtractor::getAssign() { return assign; }

vector<StmtExpr>& PatternExtractor::getContainers() { return containers; }

}  // namespace SP
