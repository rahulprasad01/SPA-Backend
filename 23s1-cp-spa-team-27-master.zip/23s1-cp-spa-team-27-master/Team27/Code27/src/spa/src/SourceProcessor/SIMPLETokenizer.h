#pragma once
#include "Common/LexicalToken.h"
#include "Common/Tokenizer.h"
using namespace SPA;

namespace SP {

enum class SIMPLETokenType {
  WORD,
  NUMBER,
  ARITH_OP,
  COND_OP,
  REL_OP,
  DELIMITER,
  WHITESPACE,
};

using SIMPLEToken = LexicalToken<SIMPLETokenType>;

class SIMPLETokenizer : public Tokenizer<SIMPLEToken> {
 public:
  SIMPLETokenizer() {}
  vector<SIMPLEToken> tokenize(const std::string& text,
                               bool ignoreSpaces = true) override;

 private:
  bool isDelimiter(char c);
  std::string readDelimiter();
  bool isArithmeticOp(char c);
  std::string readArithmeticOp();
  bool isCondOp(char c, char cnext);
  std::string readCondOp();
  bool isRelOp(char c);
  std::string readRelOp();
};

}  // namespace SP