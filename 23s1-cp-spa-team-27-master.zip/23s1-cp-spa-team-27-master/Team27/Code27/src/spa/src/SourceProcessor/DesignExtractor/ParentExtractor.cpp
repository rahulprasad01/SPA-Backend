#include "ParentExtractor.h"

namespace SP {

void ParentExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}

void ParentExtractor::insert(PKB::PKBInsert& pkb) {
  for (const StmtPair& p : parentChilds) {
    pkb.insertParent(Entity(STMT, p.first), Entity(STMT, p.second));
  }
}

void ParentExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}

void ParentExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void ParentExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (hasParent()) {
    addStmtParent(currentStmtParent, stmt->stmtNum);
  }
}

void ParentExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  if (hasParent()) {
    addStmtParent(currentStmtParent, stmt->stmtNum);
  }
}

void ParentExtractor::visitIfStmt(const IfStmtAST* stmt) {
  if (hasParent()) {
    addStmtParent(currentStmtParent, stmt->stmtNum);
  }
  auto origStmtParent = currentStmtParent;
  currentStmtParent = stmt->stmtNum;
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
  currentStmtParent = origStmtParent;
}

void ParentExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  if (hasParent()) {
    addStmtParent(currentStmtParent, stmt->stmtNum);
  }
  auto origStmtParent = currentStmtParent;
  currentStmtParent = stmt->stmtNum;
  stmt->stmtList->accept(*this);
  currentStmtParent = origStmtParent;
}

vector<StmtPair>& ParentExtractor::getParentChild() { return parentChilds; }

bool ParentExtractor::hasParent() { return currentStmtParent != ""; }

void ParentExtractor::addStmtParent(std::string parent, std::string child) {
  parentChilds.push_back(std::make_pair(parent, child));
}

}  // namespace SP
