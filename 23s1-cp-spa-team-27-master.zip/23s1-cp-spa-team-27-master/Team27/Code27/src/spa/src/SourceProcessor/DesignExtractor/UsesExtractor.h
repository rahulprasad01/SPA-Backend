#pragma once
#include <utility>
#include <vector>
#include "../AST.h"
#include "DesignExtractor.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "SemanticErrorExtractor.h"

using std::vector;
using UsesPair = std::pair<std::string, std::string>;
using namespace SPA;

namespace SP {
class UsesExtractor : public DesignExtractor {
 public:
  void run(const vector<shared_ptr<ProcAST>>& procs) override;
  void insert(PKB::PKBInsert& pkb) override;
  void visitProc(const ProcAST* proc) override;
  void visitStmtList(const StmtListAST* stmtList) override;
  void visitUnaryStmt(const UnaryStmtAST* stmt) override;
  void visitAssignStmt(const AssignStmtAST* stmt) override;
  void visitIfStmt(const IfStmtAST* stmt) override;
  void visitWhileStmt(const WhileStmtAST* stmt) override;
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
  getStmtOrProcToVars() const;
  unordered_map<std::string, EntityType> getEntityTypesLHS() const;

 private:
  bool firstPass = true;
  unordered_map<std::string, size_t> procToNum;
  vector<Entity> userStack;
  vector<unordered_set<size_t>> calledToCallerProcs;
  vector<unordered_set<std::string>> procToVarsUsed;
  size_t currProcNum;
  unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>
      userToUsed;
  void addUses(std::string lhs, std::string varName, EntityType type);
};

}  // namespace SP
