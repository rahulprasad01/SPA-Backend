#pragma once
#include <memory>
#include <vector>
#include "ProgramKnowledgeBase/PKBInsert.h"
using std::shared_ptr;
using std::vector;

namespace SP {

struct VarAST;
struct ConstAST;
struct UnaryStmtAST;
struct AssignStmtAST;
struct IfStmtAST;
struct WhileStmtAST;
struct StmtListAST;
struct ProcAST;

class DesignExtractor {
 public:
  virtual void run(const vector<shared_ptr<ProcAST>>& procs) = 0;
  virtual void insert(PKB::PKBInsert& pkb) = 0;
  virtual void visitProc(const ProcAST* proc) = 0;
  virtual void visitStmtList(const StmtListAST* stmtList) = 0;
  virtual void visitVar(const VarAST* var){};
  virtual void visitConst(const ConstAST* constant){};
  virtual void visitUnaryStmt(const UnaryStmtAST* stmt) = 0;
  virtual void visitAssignStmt(const AssignStmtAST* stmt) = 0;
  virtual void visitIfStmt(const IfStmtAST* stmt) = 0;
  virtual void visitWhileStmt(const WhileStmtAST* stmt) = 0;
};

}  // namespace SP