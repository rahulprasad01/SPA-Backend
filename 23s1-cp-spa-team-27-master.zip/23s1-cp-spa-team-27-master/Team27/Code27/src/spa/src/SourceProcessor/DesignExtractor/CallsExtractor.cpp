#include "CallsExtractor.h"

namespace SP {

void CallsExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}

void CallsExtractor::insert(PKB::PKBInsert& pkb) {
  for (const auto& [lhs, rhs] : calls) {
    pkb.insertCalls(Entity(PROC, lhs), Entity(PROC, rhs));
  }
}

void CallsExtractor::visitProc(const ProcAST* proc) {
  currProc = proc->procName;
  proc->stmtList->accept(*this);
}

void CallsExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void CallsExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (stmt->stmtType == CALL_STMT) {
    addCalls(stmt->operand->value);
  }
}

void CallsExtractor::visitAssignStmt(const AssignStmtAST* stmt) {}

void CallsExtractor::visitIfStmt(const IfStmtAST* stmt) {
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
}

void CallsExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  stmt->stmtList->accept(*this);
}

vector<CallsPair>& CallsExtractor::getCalls() { return calls; }

void CallsExtractor::addCalls(std::string calledProc) {
  calls.push_back({currProc, calledProc});
}

}  // namespace SP
