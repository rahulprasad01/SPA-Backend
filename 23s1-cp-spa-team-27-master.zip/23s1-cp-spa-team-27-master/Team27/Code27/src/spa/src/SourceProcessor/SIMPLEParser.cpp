#include "SIMPLEParser.h"
#include "Common/Format.h"
#include "Common/SPADefinitions.h"
#include "SIMPLETokenizer.h"

using namespace SP;
using namespace SPA;

using Token = SIMPLEToken;
using std::make_shared;
using std::shared_ptr;

shared_ptr<VarAST> SIMPLEParser::readVar() {
  Token c = peek();
  if (c.type == SIMPLETokenType::WORD) {
    return make_shared<VarAST>(VarAST(step().value));
  }
  throw SyntaxError(c, "expected token type WORD");
}

shared_ptr<ConstAST> SIMPLEParser::readConst() {
  Token c = peek();
  if (c.type == SIMPLETokenType::NUMBER) {
    return make_shared<ConstAST>(ConstAST(step().value));
  }
  throw SyntaxError(c, "expected token type NUMBER");
}

shared_ptr<UnaryStmtAST> SIMPLEParser::readUnaryStmt(
    EntityType type, const std::string& keyword) {
  checkKeyword(keyword);
  auto var = readVar();
  auto stmt = make_shared<UnaryStmtAST>(UnaryStmtAST(currStmtNum++, type, var));
  checkKeyword(";");
  return stmt;
}

std::pair<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>>
SIMPLEParser::readCondExpr() {
  vector<shared_ptr<VarAST>> vars;
  vector<shared_ptr<ConstAST>> consts;
  checkKeyword("(");
  Token c = peek();
  if (c.value == "!") {
    step();
    auto [v, c] = readCondExpr();
    vars = std::move(v);
    consts = std::move(c);
  } else if (c.value == "(") {
    auto [subv, subc] = readCondExpr();
    Token condop = step();
    if (condop.value != "&&" && condop.value != "||") {
      throw SyntaxError(
          peek(), SPA::format("No conditional conjunction found on line {}",
                              currStmtNum));
    }
    auto [subvr, subcr] = readCondExpr();
    std::copy(subv.begin(), subv.end(), std::back_inserter(vars));
    std::copy(subvr.begin(), subvr.end(), std::back_inserter(vars));
    std::copy(subc.begin(), subc.end(), std::back_inserter(consts));
    std::copy(subcr.begin(), subcr.end(), std::back_inserter(consts));
  } else {
    auto [v, c] = readRelExpr();
    vars = std::move(v);
    consts = std::move(c);
  }
  checkKeyword(")");
  return {vars, consts};
}

std::pair<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>>
SIMPLEParser::readRelExpr() {
  auto [varsL, constsL, exprL] = readExpr();
  // WARNING: Explicit check for "=" required, as "=" is considered a relop by
  // the parser
  if (peek().type != SIMPLETokenType::REL_OP || peek().value == "=") {
    throw SyntaxError(
        peek(),
        SPA::format("No relation operator found on line {}", currStmtNum));
  }
  step();
  auto [varsR, constsR, exprR] = readExpr();
  std::copy(varsR.begin(), varsR.end(), std::back_inserter(varsL));
  std::copy(constsR.begin(), constsR.end(), std::back_inserter(constsL));
  return {varsL, constsL};
}

std::tuple<vector<shared_ptr<VarAST>>, vector<shared_ptr<ConstAST>>,
           vector<RawToken>>
SIMPLEParser::readExpr() {
  size_t openBrac = 0;
  vector<shared_ptr<VarAST>> vars;
  vector<shared_ptr<ConstAST>> consts;
  vector<RawToken> expr;
  while (true) {
    Token c = peek();
    if (c.value == ";" || c.type == SIMPLETokenType::REL_OP) {
      if (openBrac > 0) {
        throw SyntaxError(SPA::format(
            "no matching token found for '(' at line {}", currStmtNum));
      }
      break;
    } else if (c.value == "(") {
      step();
      openBrac++;
    } else if (c.value == ")") {
      if (openBrac == 0) {
        break;
      }
      step();
      openBrac--;
    } else if (c.type == SIMPLETokenType::WORD) {
      auto var = make_shared<VarAST>(step().value);
      vars.push_back(var);
    } else if (c.type == SIMPLETokenType::NUMBER) {
      auto c = make_shared<ConstAST>(step().value);
      consts.push_back(c);
    } else if (c.type == SIMPLETokenType::ARITH_OP) {
      step();
    } else {
      throw SyntaxError(
          c, SPA::format("Found in expression on line {}", currStmtNum));
    }
    expr.push_back(c.value);
  }
  return {vars, consts, expr};
}

shared_ptr<AssignStmtAST> SIMPLEParser::readAssignStmt() {
  auto lhs = readVar();
  checkKeyword("=");
  auto [vars, consts, expr] = readExpr();
  if (!checkExpr(expr)) {
    throw SyntaxError(
        SPA::format("Invalid expression on line {}", currStmtNum));
  }
  checkKeyword(";");
  return make_shared<AssignStmtAST>(
      AssignStmtAST(currStmtNum++, lhs, vars, consts, expr));
}

shared_ptr<WhileStmtAST> SIMPLEParser::readWhileStmt() {
  checkKeyword("while");
  auto stmtNum = currStmtNum++;
  const auto& [vars, consts] = readCondExpr();
  auto stmtlist = readStmtList();
  WhileStmtAST whiles = WhileStmtAST(stmtNum, vars, consts, stmtlist);
  return make_shared<WhileStmtAST>(whiles);
}

shared_ptr<IfStmtAST> SIMPLEParser::readIfStmt() {
  checkKeyword("if");
  auto stmtNum = currStmtNum++;
  const auto& [vars, consts] = readCondExpr();
  checkKeyword("then");
  auto ifClause = readStmtList();
  checkKeyword("else");
  auto elseClause = readStmtList();
  return make_shared<IfStmtAST>(
      IfStmtAST(stmtNum, vars, consts, ifClause, elseClause));
}

shared_ptr<StmtListAST> SIMPLEParser::readStmtList() {
  // while is procedure, readProc and add
  checkKeyword("{");
  vector<shared_ptr<StmtAST>> stmts;
  while (!isKeyword("}")) {
    EntityType stmtType = whichStmtType();
    switch (stmtType) {
      case SPA::READ_STMT:
        stmts.push_back(readUnaryStmt(READ_STMT, "read"));
        break;
      case SPA::PRINT_STMT:
        stmts.push_back(readUnaryStmt(PRINT_STMT, "print"));
        break;
      case SPA::CALL_STMT:
        stmts.push_back(readUnaryStmt(CALL_STMT, "call"));
        break;
      case SPA::WHILE_STMT:
        stmts.push_back(readWhileStmt());
        break;
      case SPA::IF_STMT:
        stmts.push_back(readIfStmt());
        break;
      case SPA::ASSIGN_STMT:
        stmts.push_back(readAssignStmt());
        break;
      default:
        throw SyntaxError(peek(), "Not a statement");
        break;
    }
  }
  checkKeyword("}");
  if (stmts.size() == 0) {
    throw SyntaxError("No statements found in StmtList");
  }
  return make_shared<StmtListAST>(stmts);
}

vector<shared_ptr<ProcAST>> SIMPLEParser::parse(const std::string& text) {
  SIMPLETokenizer tokenizer;
  return parseTokens(tokenizer.tokenize(text));
}

vector<shared_ptr<ProcAST>> SIMPLEParser::parseTokens(
    const vector<SIMPLEToken>& _tokens) {
  reset();
  tokens = _tokens;
  vector<shared_ptr<ProcAST>> procs;
  while (pos < tokens.size()) {
    procs.push_back(readProc());
  }
  return procs;
}

shared_ptr<ProcAST> SIMPLEParser::readProc() {
  checkKeyword("procedure");
  std::string name = readVar()->value;
  shared_ptr<StmtListAST> stmtlist = readStmtList();
  return make_shared<ProcAST>(ProcAST(name, stmtlist));
}

bool SIMPLEParser::isKeyword(const std::string& keyword) {
  return peek().value == keyword;
}

void SIMPLEParser::checkKeyword(const std::string& keyword) {
  if (!isKeyword(keyword)) {
    throw SyntaxError(SPA::format("{} found at pos {}; expected {}",
                                  peek().value, pos, keyword));
  }
  step();
}

const SIMPLEToken& SIMPLEParser::peek(size_t idx) {
  if (pos + idx >= tokens.size()) {
    throw SyntaxError("Last token reached");
  }
  return tokens[pos + idx];
}

void SIMPLEParser::reset() {
  pos = 0;
  currStmtNum = 1;
}

const SIMPLEToken& SIMPLEParser::step() { return tokens[pos++]; }

EntityType SIMPLEParser::whichStmtType() {
  Token c = peek();
  if (c.type != SIMPLETokenType::WORD) {
    throw SyntaxError(c, "Unable to detect statement type");
    // IMPT: This check has to come before the rest
    // to account for variables with the same names as keyword
  } else if (c.type == SIMPLETokenType::WORD && peek(1).value == "=") {
    return ASSIGN_STMT;
  } else if (c.value == "read") {
    return READ_STMT;
  } else if (c.value == "print") {
    return PRINT_STMT;
  } else if (c.value == "call") {
    return CALL_STMT;
  } else if (c.value == "while") {
    return WHILE_STMT;
  } else if (c.value == "if") {
    return IF_STMT;
  }
  return NULL_ENTITY;
}