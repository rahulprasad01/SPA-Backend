#include "FollowsExtractor.h"

namespace SP {
void FollowsExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}
void FollowsExtractor::insert(PKB::PKBInsert& pkb) {
  for (const FollowsPair& p : follow) {
    pkb.insertFollows(Entity(STMT, p.first), Entity(STMT, p.second));
  }
}
void FollowsExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
}
void FollowsExtractor::visitStmtList(const StmtListAST* stmtList) {
  currentStmtFollows = "";
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}
void FollowsExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  if (hasFollows()) {
    addStmtFollows(currentStmtFollows, stmt->stmtNum);
  }
  currentStmtFollows = stmt->stmtNum;
}
void FollowsExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  if (hasFollows()) {
    addStmtFollows(currentStmtFollows, stmt->stmtNum);
  }
  currentStmtFollows = stmt->stmtNum;
}
void FollowsExtractor::visitIfStmt(const IfStmtAST* stmt) {
  if (hasFollows()) {
    addStmtFollows(currentStmtFollows, stmt->stmtNum);
  }
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
  currentStmtFollows = stmt->stmtNum;
}
void FollowsExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  if (hasFollows()) {
    addStmtFollows(currentStmtFollows, stmt->stmtNum);
  }
  stmt->stmtList->accept(*this);
  currentStmtFollows = stmt->stmtNum;
}
vector<FollowsPair>& FollowsExtractor::getFollows() { return follow; }

bool FollowsExtractor::hasFollows() { return !currentStmtFollows.empty(); }
void FollowsExtractor::addStmtFollows(const std::string& before,
                                      const std::string& after) {
  follow.emplace_back(before, after);
}

}  // namespace SP