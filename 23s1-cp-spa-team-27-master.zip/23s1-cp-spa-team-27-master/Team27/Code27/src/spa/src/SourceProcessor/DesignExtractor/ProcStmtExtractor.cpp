#include "ProcStmtExtractor.h"

namespace SP {
void ProcStmtExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}
void ProcStmtExtractor::insert(PKB::PKBInsert& pkb) {
  for (const ProcStmtPair& p : procStmts) {
    pkb.insertProcStmt(Entity(PROC, p.first), Entity(STMT, p.second));
  }
}
void ProcStmtExtractor::visitProc(const ProcAST* proc) {
  currentProc = proc->procName;
  proc->stmtList->accept(*this);
}
void ProcStmtExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}
void ProcStmtExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  addProcStmt(currentProc, stmt->stmtNum);
}
void ProcStmtExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  addProcStmt(currentProc, stmt->stmtNum);
}
void ProcStmtExtractor::visitIfStmt(const IfStmtAST* stmt) {
  addProcStmt(currentProc, stmt->stmtNum);
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
}
void ProcStmtExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  addProcStmt(currentProc, stmt->stmtNum);
  stmt->stmtList->accept(*this);
}
vector<ProcStmtPair>& ProcStmtExtractor::getProcStmts() { return procStmts; }

void ProcStmtExtractor::addProcStmt(const std::string& proc,
                                    const std::string& stmt) {
  procStmts.emplace_back(proc, stmt);
}
}  // namespace SP