#include "NextExtractor.h"

namespace SP {
void NextExtractor::run(const std::vector<std::shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}

void NextExtractor::insert(PKB::PKBInsert& pkb) {
  for (const auto& [lhs, rhs] : nexts) {
    pkb.insertNext(Entity(STMT, lhs), Entity(STMT, rhs));
  }
}

void NextExtractor::visitProc(const ProcAST* proc) {
  proc->stmtList->accept(*this);
  leaves.clear();
}

void NextExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void NextExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  addNext(stmt->stmtNum);
}

void NextExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  addNext(stmt->stmtNum);
}

void NextExtractor::visitIfStmt(const IfStmtAST* stmt) {
  addNext(stmt->stmtNum);
  stmt->ifList->accept(*this);
  auto copyIfLeaves = leaves;
  leaves.clear();
  leaves.insert(stmt->stmtNum);
  stmt->elseList->accept(*this);
  for (const auto& leaf : copyIfLeaves) {
    leaves.insert(leaf);
  }
}

void NextExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  addNext(stmt->stmtNum);
  stmt->stmtList->accept(*this);
  addNext(stmt->stmtNum);
}

std::vector<std::pair<std::string, std::string>>& NextExtractor::getNexts() {
  return nexts;
}

void NextExtractor::addNext(const std::string& node) {
  for (const auto& leaf : leaves) {
    nexts.push_back({leaf, node});
  }
  leaves.clear();
  leaves.insert(node);
}
}  // namespace SP
