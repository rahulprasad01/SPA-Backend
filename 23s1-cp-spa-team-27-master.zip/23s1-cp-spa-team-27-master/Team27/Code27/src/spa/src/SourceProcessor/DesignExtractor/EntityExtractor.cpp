#include "EntityExtractor.h"

namespace SP {

void EntityExtractor::run(const vector<shared_ptr<ProcAST>>& procs) {
  for (const auto& proc : procs) {
    proc->accept(*this);
  }
}

void EntityExtractor::insert(PKB::PKBInsert& pkb) {
  for (const Entity& entity : entities) {
    pkb.insertEntity(entity);
  }
}

void EntityExtractor::visitProc(const ProcAST* proc) {
  auto procEntity = Entity(SPA::PROC, proc->procName);
  procEntity.addAttribute(PROCNAME, proc->procName);
  entities.push_back(procEntity);
  proc->stmtList->accept(*this);
}

void EntityExtractor::visitStmtList(const StmtListAST* stmtList) {
  for (const auto& s : stmtList->stmts) {
    s->accept(*this);
  }
}

void EntityExtractor::visitUnaryStmt(const UnaryStmtAST* stmt) {
  auto unaryEntity = Entity(stmt->stmtType, stmt->stmtNum);
  unaryEntity.addAttribute(STMTNO, stmt->stmtNum);
  if (stmt->stmtType == SPA::CALL_STMT) {
    unaryEntity.addAttribute(PROCNAME, stmt->operand->value);
    entities.push_back(unaryEntity);
  } else {
    unaryEntity.addAttribute(VARNAME, stmt->operand->value);
    entities.push_back(unaryEntity);
    auto unaryVar = Entity(SPA::VAR, stmt->operand->value);
    unaryVar.addAttribute(VARNAME, stmt->operand->value);
    entities.push_back(unaryVar);
  }
}

void EntityExtractor::visitAssignStmt(const AssignStmtAST* stmt) {
  auto assignEntity = Entity(SPA::ASSIGN_STMT, stmt->stmtNum);
  assignEntity.addAttribute(STMTNO, stmt->stmtNum);
  entities.push_back(assignEntity);
  auto lhsEntity = Entity(SPA::VAR, stmt->lhs->value);
  lhsEntity.addAttribute(VARNAME, stmt->lhs->value);
  entities.push_back(lhsEntity);
  for (const auto& var : stmt->vars) {
    auto tempVar = Entity(SPA::VAR, var->value);
    tempVar.addAttribute(VARNAME, var->value);
    entities.push_back(tempVar);
  }
  for (const auto& var : stmt->consts) {
    auto tempConst = Entity(SPA::CONST, var->value);
    tempConst.addAttribute(VALUE, var->value);
    entities.push_back(tempConst);
  }
}

void EntityExtractor::visitIfStmt(const IfStmtAST* stmt) {
  auto ifEntity = Entity(SPA::IF_STMT, stmt->stmtNum);
  ifEntity.addAttribute(STMTNO, stmt->stmtNum);
  entities.push_back(ifEntity);
  for (const auto& var : stmt->vars) {
    auto tempVar = Entity(SPA::VAR, var->value);
    tempVar.addAttribute(VARNAME, var->value);
    entities.push_back(tempVar);
  }
  for (const auto& var : stmt->consts) {
    auto tempConst = Entity(SPA::CONST, var->value);
    tempConst.addAttribute(VALUE, var->value);
    entities.push_back(tempConst);
  }
  stmt->ifList->accept(*this);
  stmt->elseList->accept(*this);
}

void EntityExtractor::visitWhileStmt(const WhileStmtAST* stmt) {
  auto whileEntity = Entity(SPA::WHILE_STMT, stmt->stmtNum);
  whileEntity.addAttribute(STMTNO, stmt->stmtNum);
  entities.push_back(whileEntity);
  for (const auto& var : stmt->vars) {
    auto tempVar = Entity(SPA::VAR, var->value);
    tempVar.addAttribute(VARNAME, var->value);
    entities.push_back(tempVar);
  }
  for (const auto& var : stmt->consts) {
    auto tempConst = Entity(SPA::CONST, var->value);
    tempConst.addAttribute(VALUE, var->value);
    entities.push_back(tempConst);
  }
  stmt->stmtList->accept(*this);
}

vector<Entity> EntityExtractor::getEntities() const { return entities; }

}  // namespace SP
