#pragma once

namespace SP {
class SourceParser {
 public:
  virtual vector<shared_ptr<ProcAST>> parse(const std::string& text) = 0;
  virtual vector<shared_ptr<ProcAST>> parseTokens(
      const vector<SIMPLEToken>& tokens) = 0;
};
}  // namespace SP