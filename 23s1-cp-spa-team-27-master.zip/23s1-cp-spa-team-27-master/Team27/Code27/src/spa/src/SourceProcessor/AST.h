#pragma once
#include <memory>
#include <vector>
#include "Common/SPADefinitions.h"
#include "DesignExtractor/DesignExtractor.h"

using std::make_shared;
using std::shared_ptr;
using std::vector;
using namespace SPA;

namespace SP {
struct AST {
 public:
  EntityType type;
  virtual void accept(DesignExtractor& de) const = 0;

 protected:
  AST(EntityType type) : type(type) {}
};

struct VarAST : public AST {
  VarAST(const std::string& value) : value(value), AST::AST(EntityType::VAR){};
  void accept(DesignExtractor& de) const { de.visitVar(this); }
  bool operator==(const VarAST& other) {
    return type == other.type && value == other.value;
  }
  bool operator!=(const VarAST& other) { return !(*this == other); }
  std::string value;
};

struct ConstAST : public AST {
  ConstAST(const std::string& value)
      : value(value), AST::AST(EntityType::CONST){};
  void accept(DesignExtractor& de) const { de.visitConst(this); }
  bool operator==(const ConstAST& other) {
    return type == other.type && value == other.value;
  }
  bool operator!=(const ConstAST& other) { return !(*this == other); }
  std::string value;
};

struct StmtAST : public AST {
 public:
  StmtAST(size_t stmtNum, EntityType stmtType)
      : stmtNum(std::to_string(stmtNum)),
        stmtType(stmtType),
        AST::AST(EntityType::STMT) {}
  virtual void accept(DesignExtractor& de) const = 0;
  virtual bool operator==(const StmtAST& other) {
    return stmtType == other.stmtType && stmtNum == other.stmtNum;
  }
  virtual bool operator!=(const StmtAST& other) { return !(*this == other); }
  EntityType stmtType;
  std::string stmtNum;
};

struct StmtListAST : public AST {
  StmtListAST(vector<shared_ptr<StmtAST>> stmts)
      : stmts(stmts), AST::AST(EntityType::STMT_LIST){};
  void accept(DesignExtractor& de) const { de.visitStmtList(this); }
  virtual bool operator==(const StmtListAST& other) {
    if (stmts.size() != other.stmts.size()) return false;
    for (int i = 0; i < other.stmts.size(); i++) {
      if (*stmts[i].get() != *other.stmts[i].get()) {
        return false;
      }
    }
    return true;
  }

  virtual bool operator!=(const StmtListAST& other) {
    return !(*this == other);
  }
  vector<shared_ptr<StmtAST>> stmts;
};

struct UnaryStmtAST : public StmtAST {
  UnaryStmtAST(size_t num, EntityType type, shared_ptr<VarAST> operand)
      : operand(operand), StmtAST::StmtAST(num, type) {}
  void accept(DesignExtractor& de) const { de.visitUnaryStmt(this); }
  virtual bool operator==(const StmtAST& otherStmt) {
    if (!StmtAST::operator==(otherStmt)) return false;
    const UnaryStmtAST* other = dynamic_cast<const UnaryStmtAST*>(&otherStmt);
    return *operand.get() == *other->operand.get();
  }
  shared_ptr<VarAST> operand;
};

struct AssignStmtAST : public StmtAST {
  AssignStmtAST(size_t num, shared_ptr<VarAST> lhs,
                const vector<shared_ptr<VarAST>>& vars,
                const vector<shared_ptr<ConstAST>>& consts,
                const vector<RawToken>& expr)
      : lhs(lhs),
        vars(vars),
        consts(consts),
        expr(expr),
        StmtAST::StmtAST(num, EntityType::ASSIGN_STMT) {}
  void accept(DesignExtractor& de) const { de.visitAssignStmt(this); }
  virtual bool operator==(const StmtAST& otherStmt) {
    if (!StmtAST::operator==(otherStmt)) return false;
    const AssignStmtAST* other = dynamic_cast<const AssignStmtAST*>(&otherStmt);
    if (*lhs.get() != *other->lhs.get()) return false;
    if (vars.size() != other->vars.size() ||
        expr.size() != other->expr.size() ||
        consts.size() != other->consts.size())
      return false;
    for (int i = 0; i < other->vars.size(); i++) {
      if (*vars[i] != *other->vars[i]) {
        return false;
      }
    }
    for (int i = 0; i < other->consts.size(); i++) {
      if (*consts[i] != *other->consts[i]) {
        return false;
      }
    }
    for (int i = 0; i < other->expr.size(); i++) {
      if (expr[i] != other->expr[i]) {
        return false;
      }
    }
    return true;
  }
  shared_ptr<VarAST> lhs;
  vector<shared_ptr<VarAST>> vars;
  vector<shared_ptr<ConstAST>> consts;
  vector<RawToken> expr;
};

struct IfStmtAST : public StmtAST {
  IfStmtAST(size_t num, const vector<shared_ptr<VarAST>>& vars,
            const vector<shared_ptr<ConstAST>>& consts,
            shared_ptr<StmtListAST> ifList, shared_ptr<StmtListAST> elseList)
      : vars(vars),
        consts(consts),
        ifList(ifList),
        elseList(elseList),
        StmtAST::StmtAST(num, EntityType::IF_STMT) {}
  void accept(DesignExtractor& de) const { de.visitIfStmt(this); }
  virtual bool operator==(const StmtAST& otherStmt) {
    if (!StmtAST::operator==(otherStmt)) return false;
    const IfStmtAST* other = dynamic_cast<const IfStmtAST*>(&otherStmt);
    if (vars.size() != other->vars.size()) return false;
    if (consts.size() != other->consts.size()) return false;
    for (int i = 0; i < other->vars.size(); i++) {
      if (*vars[i] != *other->vars[i]) {
        return false;
      }
    }
    for (int i = 0; i < other->consts.size(); i++) {
      if (*consts[i] != *other->consts[i]) {
        return false;
      }
    }
    return *ifList.get() == *other->ifList.get() &&
           *elseList.get() == *other->elseList.get();
  }
  shared_ptr<StmtListAST> ifList;
  shared_ptr<StmtListAST> elseList;
  vector<shared_ptr<VarAST>> vars;
  vector<shared_ptr<ConstAST>> consts;
};

struct WhileStmtAST : public StmtAST {
  WhileStmtAST(size_t num, vector<shared_ptr<VarAST>> vars,
               vector<shared_ptr<ConstAST>> consts,
               shared_ptr<StmtListAST> stmtList)
      : vars(vars),
        consts(consts),
        stmtList(stmtList),
        StmtAST::StmtAST(num, EntityType::WHILE_STMT) {}
  void accept(DesignExtractor& de) const { de.visitWhileStmt(this); }
  virtual bool operator==(const StmtAST& otherStmt) {
    if (!StmtAST::operator==(otherStmt)) return false;
    const WhileStmtAST* other = dynamic_cast<const WhileStmtAST*>(&otherStmt);
    if (vars.size() != other->vars.size()) return false;
    if (consts.size() != other->consts.size()) return false;
    for (int i = 0; i < other->vars.size(); i++) {
      if (*vars[i] != *other->vars[i]) {
        return false;
      }
    }
    for (int i = 0; i < other->consts.size(); i++) {
      if (*consts[i] != *other->consts[i]) {
        return false;
      }
    }
    return *stmtList.get() == *other->stmtList.get();
  }
  shared_ptr<StmtListAST> stmtList;
  vector<shared_ptr<VarAST>> vars;
  vector<shared_ptr<ConstAST>> consts;
};

struct ProcAST : public AST {
  ProcAST(const std::string& procName, shared_ptr<StmtListAST> stmtList)
      : procName(procName), stmtList(stmtList), AST::AST(EntityType::PROC){};
  void accept(DesignExtractor& de) const { de.visitProc(this); }
  bool operator==(const ProcAST& other) {
    return procName == other.procName &&
           *stmtList.get() == *other.stmtList.get();
  }
  bool operator!=(const ProcAST& other) { return !(*this == other); }
  std::string procName;
  shared_ptr<StmtListAST> stmtList;
};
inline shared_ptr<VarAST> makeVarNode(const std::string& name) {
  return make_shared<VarAST>(name);
}

inline shared_ptr<ConstAST> makeConstNode(const std::string& value) {
  return make_shared<ConstAST>(value);
}

inline shared_ptr<AssignStmtAST> makeAssignNode(
    size_t num, const std::string& lhs, const vector<std::string>& vars,
    const vector<std::string>& consts, const vector<RawToken>& fullExpr) {
  vector<shared_ptr<VarAST>> varsNodes;
  vector<shared_ptr<ConstAST>> constsNodes;
  for (const auto& name : vars) {
    varsNodes.push_back(makeVarNode(name));
  }
  for (const auto& name : consts) {
    constsNodes.push_back(makeConstNode(name));
  }
  return make_shared<AssignStmtAST>(num, makeVarNode(lhs), varsNodes,
                                    constsNodes, fullExpr);
}

inline shared_ptr<UnaryStmtAST> makeUnaryNode(size_t num, EntityType type,
                                              const std::string& varName) {
  return make_shared<UnaryStmtAST>(num, type, makeVarNode(varName));
}

inline shared_ptr<IfStmtAST> makeIfNode(
    size_t num, const vector<std::string>& vars,
    const vector<std::string>& consts,
    const vector<shared_ptr<StmtAST>>& ifStmts,
    const vector<shared_ptr<StmtAST>>& elseStmts) {
  vector<shared_ptr<VarAST>> varsNodes;
  vector<shared_ptr<ConstAST>> constsNodes;
  for (const auto& name : vars) {
    varsNodes.push_back(makeVarNode(name));
  }
  for (const auto& name : consts) {
    constsNodes.push_back(makeConstNode(name));
  }
  return make_shared<IfStmtAST>(num, varsNodes, constsNodes,
                                make_shared<StmtListAST>(ifStmts),
                                make_shared<StmtListAST>(elseStmts));
}

inline shared_ptr<WhileStmtAST> makeWhileNode(
    size_t num, const vector<std::string>& vars,
    const vector<std::string>& consts,
    const vector<shared_ptr<StmtAST>>& stmtVec) {
  vector<shared_ptr<VarAST>> varsNodes;
  vector<shared_ptr<ConstAST>> constsNodes;
  for (const auto& name : vars) {
    varsNodes.push_back(makeVarNode(name));
  }
  for (const auto& name : consts) {
    constsNodes.push_back(makeConstNode(name));
  }
  return make_shared<WhileStmtAST>(num, varsNodes, constsNodes,
                                   make_shared<StmtListAST>(stmtVec));
}

inline shared_ptr<ProcAST> makeProcNode(const std::string& name,
                                        vector<shared_ptr<StmtAST>> stmtVec) {
  return make_shared<ProcAST>(name, make_shared<StmtListAST>(stmtVec));
}

}  // namespace SP
