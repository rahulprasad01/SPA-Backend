#pragma once
#include <utility>
#include <vector>
#include "../AST.h"
#include "DesignExtractor.h"
#include "ProgramKnowledgeBase/PKBInsert.h"

using std::vector;
using ProcStmtPair = std::pair<std::string, std::string>;

namespace SP {
class ProcStmtExtractor : public DesignExtractor {
 public:
  void run(const vector<shared_ptr<ProcAST>>& procs) override;
  void insert(PKB::PKBInsert& pkb) override;
  void visitProc(const ProcAST* proc) override;
  void visitStmtList(const StmtListAST* stmtList) override;
  void visitUnaryStmt(const UnaryStmtAST* stmt) override;
  void visitAssignStmt(const AssignStmtAST* stmt) override;
  void visitIfStmt(const IfStmtAST* stmt) override;
  void visitWhileStmt(const WhileStmtAST* stmt) override;
  vector<ProcStmtPair>& getProcStmts();

 private:
  vector<ProcStmtPair> procStmts;
  std::string currentProc;
  void addProcStmt(const std::string& proc, const std::string& stmt);
};
}  // namespace SP
