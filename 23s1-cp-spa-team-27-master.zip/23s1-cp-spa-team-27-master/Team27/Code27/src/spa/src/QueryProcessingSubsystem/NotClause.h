#pragma once
#include "Clause.h"

namespace QPS {
class NotClause : public Clause {
 public:
  NotClause(std::shared_ptr<Clause>& clause) : clause(clause){};
  NotClause(std::shared_ptr<Clause>&& clause) : clause(clause){};
  bool test(const Candidate& candidate, PKB::PKBQuery& pkb);
  std::vector<QPS::Declaration> getDeclarations();
  bool equal_to(const Clause& other) const;
  std::string to_string() const;

 private:
  std::shared_ptr<Clause> clause;
};
inline bool NotClause::test(const Candidate& candidate, PKB::PKBQuery& pkb) {
  return !clause->test(candidate, pkb);
}
inline std::vector<QPS::Declaration> NotClause::getDeclarations() {
  return clause->getDeclarations();
}
inline bool NotClause::equal_to(const Clause& other) const {
  const NotClause* nc = dynamic_cast<const NotClause*>(&other);
  if (nc == nullptr) return false;
  return *clause == *(nc->clause);
}
// Not accurate to PQL query as the query requires knowledge of and prints the
// type of clause before printing 'not' keyword
inline std::string NotClause::to_string() const {
  return "not " + clause->to_string();
}
}  // namespace QPS