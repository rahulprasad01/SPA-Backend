#pragma once
#include "Common/LexicalToken.h"
#include "Common/Tokenizer.h"

using namespace SPA;

namespace QPS {

enum class QueryTokenType {
  WORD,
  NUMBER,
  OP,
  DELIMITER,
  WHITESPACE,
};

using QueryToken = LexicalToken<QueryTokenType>;

class QueryTokenizer : public Tokenizer<QueryToken> {
 public:
  QueryTokenizer() {}

  vector<QueryToken> tokenize(const std::string& text,
                              bool ignoreSpaces = true) override;

 private:
  bool isOperator(char c);
  std::string readOperator();
  bool isDelimiter(char c);
  std::string readDelimiter();
  std::string readWord() override;
  vector<QueryToken> tokens;
};

}  // namespace QPS