#pragma once
#include <unordered_map>
#include <vector>
#include "../Common/Entity.h"
#include "Declaration.h"

namespace QPS {
// Representation of a candidate set of entities. Different clauses will call
// `extractEntities` method to extract relevant entities from declarations.
class Candidate {
 public:
  // Extract candidate entities for testing from the query entities
  const SPA::Entity& extractEntity(const QPS::Declaration& decl) const {
    return declToEntity.at(decl.label);
  }
  void emplaceRef(const QPS::Declaration& decl, const SPA::Entity& entity) {
    declToEntity[decl.label] = entity;
  }

 private:
  std::unordered_map<std::string, SPA::Entity> declToEntity;
};
}  // namespace QPS