#pragma once
#include <vector>
#include "Candidate.h"
#include "Clause.h"
#include "Common/SPADefinitions.h"
#include "Declaration.h"
#include "ProgramKnowledgeBase/PKBManager.h"

using std::shared_ptr;
using std::unordered_map;
using std::vector;
using namespace PKB;
using namespace SPA;

namespace QPS {
class Query : private equal_comparable<Query>, private stringifiable<Query> {
  friend class QueryEvaluator;

 public:
  Query& addDeclaration(const Declaration&);
  Query& selectDecl(const std::string&);
  Query& selectDeclAttr(const std::string&, const SPA::EntityAttrType& attr);
  // Since Clause is an abstract class, we use shared_ptr to store a vector of
  // Clauses
  Query& addClause(const std::shared_ptr<Clause>&);
  bool hasDeclaration(const std::string&) const;
  const Declaration& getDeclarationByLabel(const std::string&) const;
  bool equal_to(const Query& other) const;
  std::string to_string() const;

 private:
  class Selection : private equal_comparable<Selection>,
                    private stringifiable<Selection> {
    friend class QueryEvaluator;

   public:
    Selection(const Declaration& decl)
        : decl(decl), attr(EntityAttrType::NULL_ATTR){};
    Selection(const Declaration& decl, const EntityAttrType& attr)
        : decl(decl), attr(attr){};
    bool equal_to(const Selection& other) const;
    std::string to_string() const;

   private:
    Declaration decl;
    EntityAttrType attr;
  };
  unordered_map<std::string, Declaration> declarations;
  vector<Selection> selections;
  vector<std::shared_ptr<Clause>> clauses;
};
}  // namespace QPS