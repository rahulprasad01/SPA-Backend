#pragma once
#include <memory>
#include <optional>
#include <variant>
#include "Declaration.h"
#include "NotClause.h"
#include "PatternClause.h"
#include "Query.h"
#include "QueryTokenizer.h"
#include "SuchThatClause.h"
#include "WithClause.h"

using std::make_shared;
using std::optional;
using std::pair;
using std::shared_ptr;
using std::string;
using std::tuple;

namespace QPS {
using EntityTypeList = vector<unordered_set<EntityType>>;
using EntityArg = tuple<optional<Entity>, optional<Declaration>>;
constexpr size_t WITH_ARG_COUNT = 2;
using WithArg = std::variant<string, pair<Declaration, EntityAttrType>>;

class SemanticError : public SPA::SPAException {
 public:
  SemanticError(std::string reason)
      : SPAException(SPA::format("Query Semantic error: {}", reason)) {}
};

class SyntaxError : public SPA::SPAException {
 public:
  SyntaxError(QueryToken token, std::string reason)
      : SPAException(
            SPA::format("Query Syntax Error: Invalid QueryToken {}, {}",
                        token.value, reason)) {}
  SyntaxError(std::string reason)
      : SPAException(SPA::format("Query Syntax error: {}", reason)) {}
};

class QueryParser {
 public:
  QueryParser() : pos(0) {}
  Query parse(const string& query);
  Query parseTokens(const vector<QueryToken>& tokens);

 private:
  bool hasDeclaration(EntityArg arg,
                      const unordered_set<EntityType>& allowedTypes);
  Declaration getDeclaration(EntityArg arg);
  bool isEntityLabel(WithArg warg);
  bool isDeclRef(WithArg warg);
  string getEntityLabel(WithArg warg);
  pair<Declaration, EntityAttrType> getDeclRef(WithArg warg);

  bool hasEntity(EntityArg arg);
  Entity getEntity(EntityArg arg);

  void reset();
  const QueryToken& peek(size_t idx = 0);
  const QueryToken& step();
  bool isEnd();
  bool isKeyword(std::string keyword);
  void checkKeyword(std::string keyword);
  void readDecl();
  void readSelect();
  void readResult();
  void readSuchThat();
  void readPattern();
  void readWith();
  string readSyn(bool isNew = false);
  pair<Declaration, EntityAttrType> readElement();
  EntityArg readEntityArg(const unordered_set<EntityType>& allowedType);
  vector<QueryToken> tokens;
  Query query;
  size_t pos;
  vector<SemanticError> semanticErrList;
};
}  // namespace QPS