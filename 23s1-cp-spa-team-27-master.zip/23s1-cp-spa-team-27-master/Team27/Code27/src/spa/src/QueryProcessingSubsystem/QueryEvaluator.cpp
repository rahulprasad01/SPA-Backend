#include "QueryEvaluator.h"
#include <set>

using namespace QPS;

std::vector<QueryEvaluator::RecordRef> QueryEvaluator::evaluateQuery(
    const Query& query, PKB::PKBQuery& pkb) {
  // Init declaration labels to ids mapping
  std::unordered_map<std::string, int> declId;
  std::vector<std::string> declLabels;
  for (auto& decl : query.declarations) declLabels.push_back(decl.first);
  for (int i = 0; i < declLabels.size(); ++i) declId[declLabels[i]] = i;
  std::unordered_set<std::string> selectedDeclLabels;
  for (auto& sel : query.selections) selectedDeclLabels.insert(sel.decl.label);
  // Evaluating clauses
  vector<int> noDeclClauses;
  vector<vector<int>> connectedClauses, disconnectedClauses;
  groupClauses(query, noDeclClauses, connectedClauses, disconnectedClauses);
  for (int i : noDeclClauses) {
    if (query.clauses[i]->test({}, pkb)) continue;
    if (query.selections.empty())  // Select BOOLEAN
      return {{"FALSE"}};
    else
      return {};
  }
  for (vector<int>& v : disconnectedClauses) {
    std::vector<Record> result;
    std::vector<int> indexes;
    for (int i : v) {
      auto decls = query.clauses[i]->getDeclarations();
      std::vector<int> newIndexes;
      for (auto& decl : decls) newIndexes.push_back(declId[decl.label]);
      QueryEvaluator::CandidateGenerator cg(decls, pkb);
      std::optional<Candidate> candidate = cg.generateNext();
      std::vector<Record> records;
      while (candidate.has_value()) {
        if (query.clauses[i]->test(*candidate, pkb))
          records.push_back(candidateToRecord(*candidate, decls));
        candidate = cg.generateNext();
      }
      auto joinResult = SPA::joinTables(result, indexes, records, newIndexes);
      result = std::move(joinResult.first);
      indexes = std::move(joinResult.second);
      // Early termination
      if (result.empty()) {
        if (query.selections.empty())
          return {{"FALSE"}};
        else
          return {};
      }
    }
  }
  std::vector<Record> result;
  std::vector<int> indexes;
  for (vector<int>& v : connectedClauses) {
    std::vector<Record> subresult;
    std::vector<int> subindexes;
    std::set<int> selectedSubIndexes;
    for (int i : v) {
      auto decls = query.clauses[i]->getDeclarations();
      std::vector<int> newIndexes;
      for (auto& decl : decls) {
        int id = declId[decl.label];
        newIndexes.push_back(id);
        if (selectedDeclLabels.count(decl.label)) selectedSubIndexes.insert(id);
      }
      QueryEvaluator::CandidateGenerator cg(decls, pkb);
      std::optional<Candidate> candidate = cg.generateNext();
      std::vector<Record> records;
      while (candidate.has_value()) {
        if (query.clauses[i]->test(*candidate, pkb))
          records.push_back(candidateToRecord(*candidate, decls));
        candidate = cg.generateNext();
      }
      // Project result with used selections
      auto joinResult =
          SPA::joinTables(subresult, subindexes, records, newIndexes);
      subresult = std::move(joinResult.first);
      subindexes = std::move(joinResult.second);
      // Early termination
      if (subresult.empty()) {
        if (query.selections.empty())
          return {{"FALSE"}};
        else
          return {};
      }
    }
    vector<int> joinIndex(selectedSubIndexes.begin(), selectedSubIndexes.end());
    std::vector<Record> temp =
        SPA::projectFromTable(subresult, subindexes, joinIndex);
    auto joinResult = SPA::joinTables(result, indexes, temp, joinIndex);
    result = std::move(joinResult.first);
    indexes = std::move(joinResult.second);
  }
  // Select BOOLEAN
  if (query.selections.empty()) return {{"TRUE"}};
  // Generate unused selections combinations
  for (int i : indexes) selectedDeclLabels.erase(declLabels[i]);
  std::vector<Declaration> unusedSelections;
  std::vector<int> unusedIndexes;
  for (auto& declLabel : selectedDeclLabels) {
    unusedIndexes.push_back(declId[declLabel]);
    unusedSelections.push_back(query.declarations.at(declLabel));
  }
  QueryEvaluator::CandidateGenerator cg(unusedSelections, pkb);
  std::optional<Candidate> candidate = cg.generateNext();
  std::vector<Record> records;
  while (candidate.has_value()) {
    records.push_back(candidateToRecord(*candidate, unusedSelections));
    candidate = cg.generateNext();
  }
  // Combine unused selections with projected result
  auto joinResult = SPA::joinTables(result, indexes, records, unusedIndexes);
  // Project combined results
  vector<int> selIndexes;
  for (auto& sel : query.selections)
    selIndexes.push_back(declId[sel.decl.label]);
  result =
      SPA::projectFromTable(joinResult.first, joinResult.second, selIndexes);
  std::set<RecordRef> resultRef;
  for (auto& record : result) {
    RecordRef recordRef;
    for (int i = 0; i < record.size(); ++i) {
      if (query.selections[i].attr != EntityAttrType::NULL_ATTR)
        recordRef.push_back(record[i].getAttribute(query.selections[i].attr));
      else
        recordRef.push_back(record[i].label);
    }
    resultRef.insert(std::move(recordRef));
  }
  return std::vector(resultRef.begin(), resultRef.end());
}

QueryEvaluator::Record QueryEvaluator::candidateToRecord(
    const Candidate& candidate, const std::vector<Declaration>& declarations) {
  Record ret;
  for (const auto& decl : declarations)
    ret.push_back(candidate.extractEntity(decl));
  return ret;
}

void QueryEvaluator::groupClauses(const Query& query,
                                  vector<int>& noDeclClauses,
                                  vector<vector<int>>& connectedClauses,
                                  vector<vector<int>>& disconnectedClauses) {
  int n = query.clauses.size();
  vector<vector<int>> adjList(n);
  unordered_map<std::string, vector<int>> labelToClauses;
  // noDeclClauses
  for (int i = 0; i < query.clauses.size(); ++i) {
    vector<Declaration> decls = query.clauses[i]->getDeclarations();
    if (decls.empty()) {
      noDeclClauses.push_back(i);
      continue;
    }
    unordered_set<int> neighbors;
    for (auto& decl : decls) {
      for (int j : labelToClauses[decl.label]) neighbors.insert(j);
      labelToClauses[decl.label].push_back(i);
    }
    for (int j : neighbors) {
      adjList[i].push_back(j);
      adjList[j].push_back(i);
    }
  }
  // connectedClauses
  unordered_set<int> clausesWithSelect;
  for (auto& sel : query.selections)
    for (int i : labelToClauses[sel.decl.label]) clausesWithSelect.insert(i);
  vector<bool> vis(adjList.size(), false);
  std::queue<int> bfs;
  for (int i : clausesWithSelect) {
    if (vis[i]) continue;
    vis[i] = true;
    connectedClauses.push_back({i});
    bfs.push(i);
    while (bfs.size()) {
      size_t sz = bfs.size();
      for (int i = 0; i < sz; ++i) {
        size_t v = bfs.front();
        bfs.pop();
        for (size_t u : adjList[v]) {
          if (vis[u]) continue;
          vis[u] = 1;
          connectedClauses.back().push_back(u);
          bfs.push(u);
        }
      }
    }
  }
  // disconnectedClauses
  for (int i = 0; i < adjList.size(); ++i) {
    if (vis[i]) continue;
    bfs.push(i);
    vis[i] = true;
    vector<size_t> ret;
    disconnectedClauses.push_back({i});
    while (bfs.size()) {
      size_t sz = bfs.size();
      for (int i = 0; i < sz; ++i) {
        size_t v = bfs.front();
        bfs.pop();
        for (size_t u : adjList[v]) {
          if (vis[u]) continue;
          vis[u] = 1;
          disconnectedClauses.back().push_back(u);
          bfs.push(u);
        }
      }
    }
  }
}

QueryEvaluator::CandidateGenerator::CandidateGenerator(
    const std::vector<Declaration>& declarations, PKB::PKBQuery& pkb)
    : decls(declarations.begin(), declarations.end()), gen(false) {
  for (const auto& decl : declarations) {
    const auto& entitySet = pkb.getEntities(decl.type);
    beginIters.push_back(entitySet.begin());
    iters.push_back(entitySet.begin());
    endIters.push_back(entitySet.end());
  }
}

std::optional<Candidate> QueryEvaluator::CandidateGenerator::generateNext() {
  if (gen) {
    int i = iters.size() - 1;
    while (i >= 0 && ++iters[i] == endIters[i]) {
      iters[i] = beginIters[i];
      --i;
    }
    if (i < 0) return std::nullopt;
  }
  gen = true;
  Candidate ret;
  for (int i = 0; i < iters.size(); ++i) {
    if (iters[i] == endIters[i])
      return std::nullopt;  // If entity of such that doesn't exist
    ret.emplaceRef(decls[i], *iters[i]);
  }
  return ret;
}