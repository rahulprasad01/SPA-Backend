#pragma once
#include <optional>
#include "Query.h"

namespace QPS {
class QueryEvaluator {
 public:
  typedef std::vector<SPA::Entity> Record;
  typedef std::vector<SPA::EntityRef> RecordRef;
  std::vector<RecordRef> evaluateQuery(const Query& query, PKB::PKBQuery& pkb);

 private:
  Record candidateToRecord(const Candidate& candidate,
                           const std::vector<Declaration>& declarations);
  // Group clauses into connected components and sorted in bfsOrder
  void groupClauses(const Query& query, vector<int>& noDeclClauses,
                    vector<vector<int>>& connectedClauses,
                    vector<vector<int>>& disconnectedClauses);
  class CandidateGenerator {
    typedef std::unordered_set<SPA::Entity, Entity::KeyHasher>::const_iterator
        entity_iter;

   public:
    CandidateGenerator(const std::vector<Declaration>& declarations,
                       PKB::PKBQuery& pkb);
    std::optional<Candidate> generateNext();

   private:
    bool gen;
    std::vector<Declaration> decls;
    std::vector<entity_iter> iters;
    std::vector<entity_iter> beginIters;
    std::vector<entity_iter> endIters;
  };
};
}  // namespace QPS