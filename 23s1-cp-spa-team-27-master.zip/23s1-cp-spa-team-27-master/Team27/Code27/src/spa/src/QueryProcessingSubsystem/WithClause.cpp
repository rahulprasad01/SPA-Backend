#include "WithClause.h"
#include "Common/Algorithms.h"
using namespace QPS;

void WithClause::setLeft(const AttrRef& ref) {
  leftDecl = ref.first;
  leftAttrType = ref.second;
}
void WithClause::setRight(const AttrRef& ref) {
  rightDecl = ref.first;
  rightAttrType = ref.second;
}
void WithClause::setLeft(const std::string& str) { leftStr = str; }
void WithClause::setRight(const std::string& str) { rightStr = str; }

bool WithClause::test(const Candidate& candidate, PKB::PKBQuery& pkb) {
  std::string l =
      leftStr.has_value()
          ? *leftStr
          : candidate.extractEntity(*leftDecl).getAttribute(*leftAttrType);
  std::string r =
      rightStr.has_value()
          ? *rightStr
          : candidate.extractEntity(*rightDecl).getAttribute(*rightAttrType);
  return l == r;
}

std::vector<QPS::Declaration> WithClause::getDeclarations() {
  std::vector<QPS::Declaration> decls;
  if (leftDecl.has_value()) decls.push_back(*leftDecl);
  if (rightDecl.has_value() && leftDecl != rightDecl)
    decls.push_back(*rightDecl);
  return decls;
}
bool WithClause::equal_to(const Clause& other) const {
  const WithClause* wc = dynamic_cast<const WithClause*>(&other);
  if (wc == nullptr) return false;
  return leftDecl == wc->leftDecl && rightDecl == wc->rightDecl &&
         leftAttrType == wc->leftAttrType &&
         rightAttrType == wc->rightAttrType && leftStr == wc->leftStr &&
         rightStr == wc->rightStr;
}

std::string WithClause::to_string() const {
  std::ostringstream out;
  out << "with ";
  if (leftDecl.has_value()) {
    out << leftDecl->label << "." << EntityAttrToString(*leftAttrType);
  } else if (SPA::isWholeNumber(*leftStr)) {
    out << *leftStr;
  } else {
    out << "\"" << *leftStr << "\"";
  }
  out << " = ";
  if (rightDecl.has_value()) {
    out << rightDecl->label << "." << EntityAttrToString(*rightAttrType);
  } else if (SPA::isWholeNumber(*rightStr)) {
    out << *rightStr;
  } else {
    out << "\"" << *rightStr << "\"";
  }
  return out.str();
}
