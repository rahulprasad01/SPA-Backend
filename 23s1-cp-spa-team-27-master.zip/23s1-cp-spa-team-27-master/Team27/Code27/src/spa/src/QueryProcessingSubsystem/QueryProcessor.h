#pragma once
#include <list>
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "QueryEvaluator.h"
#include "QueryParser.h"

namespace QPS {
class QueryProcessor {
 public:
  QueryProcessor(PKB::PKBQuery& pkbQuery) : pkbQuery(pkbQuery) {}
  void evaluate(const std::string& query, std::list<std::string>& results);

 private:
  PKB::PKBQuery& pkbQuery;
  std::string recordToString(QPS::QueryEvaluator::RecordRef& res) const;
};
}  // namespace QPS