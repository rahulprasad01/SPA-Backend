#include "SuchThatClause.h"

using namespace QPS;

bool SuchThatClause::test(const Candidate& candidate, PKB::PKBQuery& pkb) {
  const SPA::Entity& left = leftEntity.has_value()
                                ? leftEntity.value()
                                : candidate.extractEntity(leftDecl.value());
  const SPA::Entity& right = rightEntity.has_value()
                                 ? rightEntity.value()
                                 : candidate.extractEntity(rightDecl.value());
  return pkb.hasRelation(left, right, type);
}
std::vector<QPS::Declaration> SuchThatClause::getDeclarations() {
  std::vector<QPS::Declaration> ret;
  if (leftDecl.has_value()) ret.push_back(leftDecl.value());
  if (rightDecl.has_value() && leftDecl != rightDecl)
    ret.push_back(rightDecl.value());
  return ret;
}
void SuchThatClause::setLeft(const SPA::Entity& entity) { leftEntity = entity; }
void SuchThatClause::setLeft(const QPS::Declaration& entity) {
  leftDecl = entity;
}
void SuchThatClause::setRight(const SPA::Entity& entity) {
  rightEntity = entity;
}
void SuchThatClause::setRight(const QPS::Declaration& entity) {
  rightDecl = entity;
}