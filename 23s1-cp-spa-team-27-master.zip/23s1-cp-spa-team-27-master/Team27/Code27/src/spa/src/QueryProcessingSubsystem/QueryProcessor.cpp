#include "QueryProcessor.h"

namespace QPS {
void QueryProcessor::evaluate(const std::string& query,
                              std::list<std::string>& results) {
  QueryParser qp;
  QueryEvaluator qe;
  try {
    Query q = qp.parse(query);
    std::vector<QueryEvaluator::RecordRef> refs = qe.evaluateQuery(q, pkbQuery);
    for (auto& ref : refs) results.push_back(recordToString(ref));
  } catch (const SPA::InvalidLexicalTokenException& lexErr) {
    results.push_back("SyntaxError");
  } catch (const QPS::SyntaxError& syntaxErr) {
    string s = syntaxErr.what();
    results.push_back("SyntaxError");
  } catch (const QPS::SemanticError& semanticErr) {
    results.push_back("SemanticError");
  }
}

std::string QueryProcessor::recordToString(
    QPS::QueryEvaluator::RecordRef& res) const {
  std::string ret;
  for (int j = 0; j < res.size() - 1; ++j) ret.append(res[j] + " ");
  ret.append(res.back());
  return ret;
}
}  // namespace QPS