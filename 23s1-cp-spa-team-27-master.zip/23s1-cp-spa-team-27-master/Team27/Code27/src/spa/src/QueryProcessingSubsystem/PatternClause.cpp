#include "PatternClause.h"

using namespace QPS;

bool PatternClause::test(const Candidate& candidate, PKB::PKBQuery& pkb) {
  const SPA::Entity& stmt = candidate.extractEntity(this->stmt);
  const SPA::Entity& left = leftEntity.has_value()
                                ? leftEntity.value()
                                : candidate.extractEntity(leftDecl.value());
  switch (stmt.type) {
    case ASSIGN_STMT:
      return pkb.hasAssignPattern(stmt, left, pattern, isPartial);
    case WHILE_STMT:
    case IF_STMT:
      return pkb.hasContainerPattern(stmt, left);
    default:
      // should not reach here
      throw std::runtime_error("Pattern entity is not valid statement");
  }
}
std::vector<QPS::Declaration> PatternClause::getDeclarations() {
  std::vector<QPS::Declaration> ret{stmt};
  if (leftDecl.has_value()) ret.push_back(leftDecl.value());
  return ret;
}
void PatternClause::setLeft(const SPA::Entity& entity) { leftEntity = entity; }
void PatternClause::setLeft(const QPS::Declaration& entity) {
  leftDecl = entity;
}
std::string PatternClause::to_string() const {
  std::ostringstream out;
  out << "pattern " << stmt.label << " (";
  if (leftDecl.has_value()) {
    out << leftDecl.value().label << ", ";
  } else {
    out << "_, ";
  }
  if (pattern.empty()) {
    out << "_)";
    return out.str();
  }
  if (isPartial) out << "_";
  out << "\"";
  for (const auto& t : pattern) {
    out << t << ' ';
  }
  out << "\")";
  if (isPartial) out << "_";
  out << ")";
  return out.str();
}
bool PatternClause::equal_to(const Clause& other) const {
  const PatternClause* pc = dynamic_cast<const PatternClause*>(&other);
  if (pc == nullptr) return false;
  return stmt == pc->stmt && leftEntity == pc->leftEntity &&
         leftDecl == pc->leftDecl && pattern == pc->pattern &&
         isPartial == pc->isPartial;
}