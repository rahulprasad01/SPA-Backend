#pragma once
#include "Candidate.h"
#include "Common/Utility.h"
#include "ProgramKnowledgeBase/PKBQuery.h"

namespace QPS {
class Clause : private equal_comparable<Clause>, private stringifiable<Clause> {
 public:
  virtual bool test(const Candidate& candidate, PKB::PKBQuery& pkb) = 0;
  virtual std::vector<QPS::Declaration> getDeclarations() = 0;
  virtual bool equal_to(const Clause& other) const = 0;
  virtual std::string to_string() const = 0;
};
}  // namespace QPS