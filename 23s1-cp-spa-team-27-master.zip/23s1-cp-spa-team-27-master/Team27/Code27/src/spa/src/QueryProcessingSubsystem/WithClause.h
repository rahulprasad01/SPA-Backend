#pragma once
#include <optional>
#include "Clause.h"

namespace QPS {
// WithClause can be instantiated for some declaration `decl` using the
// constructor as follows: `WithClause(make_pair(decl,
// EntityAttrType::PROCNAME), string("proc1"))`.
// Both left and right arguments can either be a pair of Declaration and an
// EntityAttrType, or a string.
class WithClause : public Clause {
  typedef std::pair<QPS::Declaration, SPA::EntityAttrType> AttrRef;

 public:
  template <typename T, typename K,
            std::enable_if_t<(std::is_same<AttrRef, T>::value ||
                              std::is_same<std::string, T>::value) &&
                                 (std::is_same<AttrRef, K>::value ||
                                  std::is_same<std::string, K>::value),
                             bool> = true>
  WithClause(const T& left, const K& right) {
    setLeft(left);
    setRight(right);
  }
  bool test(const Candidate& candidate, PKB::PKBQuery& pkb);
  std::vector<QPS::Declaration> getDeclarations();
  bool equal_to(const Clause& other) const;
  std::string to_string() const;

 private:
  std::optional<QPS::Declaration> leftDecl;
  std::optional<QPS::Declaration> rightDecl;
  std::optional<SPA::EntityAttrType> leftAttrType;
  std::optional<SPA::EntityAttrType> rightAttrType;
  std::optional<std::string> leftStr;
  std::optional<std::string> rightStr;
  void setLeft(const AttrRef&);
  void setRight(const AttrRef&);
  void setLeft(const std::string&);
  void setRight(const std::string&);
};
}  // namespace QPS