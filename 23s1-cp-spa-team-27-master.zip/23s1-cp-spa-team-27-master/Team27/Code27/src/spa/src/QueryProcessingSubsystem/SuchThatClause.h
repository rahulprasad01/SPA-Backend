#pragma once
#include <optional>
#include "Clause.h"

namespace QPS {
// Each clause evaluates a relation between exactly two entities.
class SuchThatClause : public Clause {
 public:
  // Left and right can be either declaration or entity. If it is a declaration,
  // it will be resolved to different possible entities during evaluation.
  template <typename T, typename K,
            std::enable_if_t<(std::is_same<QPS::Declaration, T>::value ||
                              std::is_same<SPA::Entity, T>::value) &&
                                 (std::is_same<QPS::Declaration, K>::value ||
                                  std::is_same<SPA::Entity, K>::value),
                             bool> = true>
  SuchThatClause(const T& left, const K& right, SPA::RelationType type)
      : type(type) {
    setLeft(left);
    setRight(right);
  }
  bool test(const Candidate& candidate, PKB::PKBQuery& pkb);
  std::vector<QPS::Declaration> getDeclarations();
  std::string to_string() const;
  bool equal_to(const Clause& other) const {
    const SuchThatClause* stc = dynamic_cast<const SuchThatClause*>(&other);
    if (stc == nullptr) return false;
    return leftEntity == stc->leftEntity && leftDecl == stc->leftDecl &&
           rightEntity == stc->rightEntity && rightDecl == stc->rightDecl &&
           type == stc->type;
  }

 private:
  std::optional<SPA::Entity> leftEntity;
  std::optional<QPS::Declaration> leftDecl;
  std::optional<SPA::Entity> rightEntity;
  std::optional<QPS::Declaration> rightDecl;
  SPA::RelationType type;
  void setLeft(const SPA::Entity& entity);
  void setLeft(const QPS::Declaration& entity);
  void setRight(const SPA::Entity& entity);
  void setRight(const QPS::Declaration& entity);
};

inline std::string SuchThatClause::to_string() const {
  std::ostringstream out;
  out << "such that " << RelationToString(type) << "(";
  if (leftDecl.has_value()) {
    out << leftDecl.value().label;
  } else {
    out << leftEntity.value();
  }
  out << ", ";
  if (rightDecl.has_value()) {
    out << rightDecl.value().label;
  } else {
    out << rightEntity.value();
  }
  out << ")";
  return out.str();
}
}  // namespace QPS