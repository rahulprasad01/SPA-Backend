#pragma once
#include <sstream>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"

namespace QPS {

// Class for declarations used in queries
struct Declaration {
  SPA::EntityType type;
  std::string label;
  Declaration() : type(SPA::EntityType::NULL_ENTITY), label("") {}
  Declaration(SPA::EntityType type, const std::string& label)
      : type(type), label(label) {}
  bool operator==(const Declaration& other) const;
  bool operator!=(const Declaration& other) const;
  bool isStmt() const;
  friend std::ostream& operator<<(std::ostream& out, const Declaration& decl);
};
inline bool Declaration::isStmt() const { return SPA::stmtTypes.count(type); }
inline bool Declaration::operator==(const Declaration& other) const {
  return other.type == type && other.label == label;
}
inline bool Declaration::operator!=(const Declaration& other) const {
  return other.type != type || other.label != label;
}
inline std::ostream& operator<<(std::ostream& out, const Declaration& decl) {
  return out << EntityToString(decl.type) << ' ' << decl.label;
}
}  // namespace QPS