#include "QueryParser.h"
#include <unordered_map>
#include <unordered_set>
#include "Common/Format.h"
#include "Declaration.h"
#include "QueryTokenizer.h"
using std::make_shared;

using namespace QPS;

const unordered_map<string, RelationType> relationTypes = {
    {"Follows", FOLLOWS},  {"Follows*", FOLLOWS_T}, {"Parent", PARENT},
    {"Parent*", PARENT_T}, {"Uses", USES},          {"Modifies", MODIFIES},
    {"Calls", CALLS},      {"Calls*", CALLS_T},     {"Next", NEXT},
    {"Next*", NEXT_T},     {"Affects", AFFECTS}};

const unordered_map<string, EntityAttrType> entityAttrTypes = {
    {"procName", EntityAttrType::PROCNAME},
    {"varName", EntityAttrType::VARNAME},
    {"stmt#", EntityAttrType::STMTNO},
    {"value", EntityAttrType::VALUE}};

const unordered_map<EntityAttrType, QueryTokenType> entityAttrValueTypes = {
    {EntityAttrType::PROCNAME, QueryTokenType::WORD},
    {EntityAttrType::VARNAME, QueryTokenType::WORD},
    {EntityAttrType::STMTNO, QueryTokenType::NUMBER},
    {EntityAttrType::VALUE, QueryTokenType::NUMBER}};

const unordered_map<string, EntityTypeList> relationEntStmtTypes = {
    {"Follows", {{STMT}, {STMT}}},   {"Follows*", {{STMT}, {STMT}}},
    {"Parent", {{STMT}, {STMT}}},    {"Parent*", {{STMT}, {STMT}}},
    {"Uses", {{STMT, PROC}, {VAR}}}, {"Modifies", {{STMT, PROC}, {VAR}}},
    {"Calls", {{PROC}, {PROC}}},     {"Calls*", {{PROC}, {PROC}}},
    {"Next", {{STMT}, {STMT}}},      {"Next*", {{STMT}, {STMT}}},
    {"Affects", {{STMT}, {STMT}}}};

const unordered_set<EntityType> allStmtTypes = {
    ASSIGN_STMT, PRINT_STMT, IF_STMT, WHILE_STMT, CALL_STMT, READ_STMT, STMT};

const unordered_map<string, EntityTypeList> relationDeclTypes = {
    {"Follows", {allStmtTypes, allStmtTypes}},
    {"Follows*", {allStmtTypes, allStmtTypes}},
    {"Parent", {allStmtTypes, allStmtTypes}},
    {"Parent*", {allStmtTypes, allStmtTypes}},
    {"Uses",
     {{ASSIGN_STMT, PRINT_STMT, IF_STMT, WHILE_STMT, CALL_STMT, READ_STMT, STMT,
       PROC},
      {VAR}}},
    {"Modifies",
     {{ASSIGN_STMT, PRINT_STMT, IF_STMT, WHILE_STMT, CALL_STMT, READ_STMT, STMT,
       PROC},
      {VAR}}},
    {"Calls", {{PROC}, {PROC}}},
    {"Calls*", {{PROC}, {PROC}}},
    {"Next", {allStmtTypes, allStmtTypes}},
    {"Next*", {allStmtTypes, allStmtTypes}},
    {"Affects", {allStmtTypes, allStmtTypes}},
};

const unordered_map<string, EntityType> designEntities = {
    {"stmt", STMT},          {"read", READ_STMT},   {"print", PRINT_STMT},
    {"call", CALL_STMT},     {"while", WHILE_STMT}, {"if", IF_STMT},
    {"assign", ASSIGN_STMT}, {"variable", VAR},     {"constant", CONST},
    {"procedure", PROC}};

const unordered_map<EntityType, EntityTypeList> patternEntTypes = {
    {ASSIGN_STMT, {{VAR}}}, {IF_STMT, {{VAR}}}, {WHILE_STMT, {{VAR}}}};

const unordered_map<EntityType, EntityTypeList> patternDeclTypes = {
    {ASSIGN_STMT, {{VAR}}}, {IF_STMT, {{VAR}}}, {WHILE_STMT, {{VAR}}}};

const unordered_map<string, unordered_set<EntityType>> entityAttrLabelOf = {
    {"procName", {EntityType::PROC, EntityType::CALL_STMT}},
    {"varName",
     {EntityType::READ_STMT, EntityType::VAR, EntityType::PRINT_STMT}},
    {"stmt#",
     {EntityType::ASSIGN_STMT, EntityType::CALL_STMT, EntityType::IF_STMT,
      EntityType::PRINT_STMT, EntityType::READ_STMT, EntityType::WHILE_STMT,
      EntityType::STMT}},
    {"value", {EntityType::CONST}}};

const QueryToken& QueryParser::peek(size_t idx) {
  if (pos + idx >= tokens.size()) {
    throw SyntaxError("Last token reached");
  }
  return tokens[pos + idx];
}

const QueryToken& QueryParser::step() { return tokens[pos++]; }
bool QueryParser::isEnd() { return pos >= tokens.size(); }

bool QueryParser::isKeyword(std::string keyword) {
  return !isEnd() && peek().value == keyword;
}

void QueryParser::checkKeyword(std::string keyword) {
  if (isEnd()) {
    throw SyntaxError(SPA::format("last token reached; expected {}", keyword));
  } else if (!isKeyword(keyword)) {
    throw SyntaxError(SPA::format("{} found at pos {}; expected {}",
                                  peek().value, pos, keyword));
  }
  step();
}
bool QueryParser::hasDeclaration(
    EntityArg arg, const unordered_set<EntityType>& allowedTypes) {
  if (std::get<1>(arg).has_value()) {
    const auto& a = std::get<1>(arg).value();
    if (!allowedTypes.count(a.type)) {
      semanticErrList.push_back(
          SemanticError(SPA::format("Invalid declaration `{}` of type {}",
                                    a.label, EntityToString(a.type))));
    }
    return true;
  }
  return false;
}
Declaration QueryParser::getDeclaration(EntityArg arg) {
  return std::get<1>(arg).value();
}
bool QueryParser::isEntityLabel(WithArg warg) {
  return std::holds_alternative<string>(warg);
}
bool QueryParser::isDeclRef(WithArg warg) {
  return std::holds_alternative<pair<Declaration, EntityAttrType>>(warg);
}
string QueryParser::getEntityLabel(WithArg warg) {
  return std::get<string>(warg);
}
pair<Declaration, EntityAttrType> QueryParser::getDeclRef(WithArg warg) {
  return std::get<pair<Declaration, EntityAttrType>>(warg);
}

bool QueryParser::hasEntity(EntityArg arg) {
  return std::get<0>(arg).has_value();
}
Entity QueryParser::getEntity(EntityArg arg) {
  return std::get<0>(arg).value_or(Entity(EntityType::NULL_ENTITY, ""));
}

string QueryParser::readSyn(bool isNew) {
  QueryToken labelToken = step();
  if (labelToken.type != QueryTokenType::WORD) {
    throw SyntaxError(labelToken, "Invalid synonym label");
  }
  if (!isNew && !query.hasDeclaration(labelToken.value)) {
    semanticErrList.push_back(SemanticError(
        SPA::format("Synonym not declared {}", labelToken.value)));
  }
  return labelToken.value;
}

void QueryParser::readDecl() {
  QueryToken typeToken = step();
  if (!designEntities.count(typeToken.value)) {
    throw SyntaxError(typeToken, "Invalid entity type in declaration");
  }
  EntityType type = designEntities.at(typeToken.value);
  while (true) {
    string syn = readSyn(true);
    if (query.hasDeclaration(syn)) {
      semanticErrList.push_back(
          SemanticError(SPA::format("Redeclared {}", syn)));
    }
    query.addDeclaration({type, syn});
    if (isKeyword(",")) {
      step();
      continue;
    } else if (isKeyword(";")) {
      step();
      break;
    } else
      throw SyntaxError(SPA::format("Unexpected token {}", peek().value));
  }
}

EntityArg QueryParser::readEntityArg(
    const unordered_set<EntityType>& allowedTypes) {
  QueryToken token = peek();
  if (isKeyword("_")) {
    checkKeyword("_");
    if (allowedTypes.size() > 1 &&
        !allowedTypes.count(EntityType::NULL_ENTITY)) {
      semanticErrList.push_back(
          SemanticError("Argument cannot be wildcard, as type is ambiguous"));
    }
    return {{}, {}};
  } else if (token.type == QueryTokenType::NUMBER) {
    token = step();
    if (!allowedTypes.count(EntityType::STMT)) {
      throw SyntaxError(
          SPA::format("Stmt type of entity `{}` not allowed", token.value));
    }
    Entity entity(EntityType::STMT, token.value);
    return {{entity}, {}};
  } else if (token.type == QueryTokenType::DELIMITER) {
    checkKeyword("\"");
    token = step();
    if (token.type != QueryTokenType::WORD) {
      throw SyntaxError(SPA::format("Invalid variable name `{}`", token.value));
    }
    // WARNING: doesn't look through all allowedTypes.
    // stops at the first non stmt type, works because args
    // should be non-ambiguous in type here
    for (const auto& allowedType : allowedTypes) {
      Entity entity(allowedType, token.value);
      if (entity.isStmt() || entity.type == EntityType::NULL_ENTITY) continue;
      entity.validate();
      checkKeyword("\"");
      return {{entity}, {}};
    }
    throw SyntaxError(
        SPA::format("Allowed type not found for entity `{}`", token.value));
  } else if (token.type == QueryTokenType::WORD) {
    string syn = readSyn();
    Declaration decl;
    if (!query.hasDeclaration(token.value)) {
      semanticErrList.push_back(SemanticError(
          SPA::format("Declaration `{}` not found", token.value)));
    } else {
      decl = query.getDeclarationByLabel(token.value);
    }
    if (!allowedTypes.count(decl.type) &&
        !(allowedTypes.count(EntityType::STMT) && decl.isStmt())) {
      semanticErrList.push_back(SemanticError(SPA::format(
          "Allowed type not found for declaration `{}`", token.value)));
    }
    return {{}, {decl}};
  }
  throw SyntaxError(token, "Invalid ref");
}

void QueryParser::readSuchThat() {
  checkKeyword("such");
  checkKeyword("that");
  do {
    bool isNot = isKeyword("not");
    if (isNot) checkKeyword("not");
    if (isEnd()) throw SyntaxError("EOF reached, incomplete such that clause");
    QueryToken relLabel = step();
    if (!relationTypes.count(relLabel.value)) {
      throw SyntaxError(relLabel, "Unrecognised relation");
    }
    RelationType relType = relationTypes.at(relLabel.value);
    checkKeyword("(");
    EntityArg lhs = readEntityArg(relationEntStmtTypes.at(relLabel.value)[0]);
    checkKeyword(",");
    EntityArg rhs = readEntityArg(relationEntStmtTypes.at(relLabel.value)[1]);
    checkKeyword(")");
    shared_ptr<Clause> cl;
    const auto& lhsAllowed = relationDeclTypes.at(relLabel.value).at(0);
    const auto& rhsAllowed = relationDeclTypes.at(relLabel.value).at(1);
    if (hasDeclaration(lhs, lhsAllowed) && hasDeclaration(rhs, rhsAllowed)) {
      cl = make_shared<SuchThatClause>(getDeclaration(lhs), getDeclaration(rhs),
                                       relType);
    } else if (hasDeclaration(lhs, lhsAllowed)) {
      cl = make_shared<SuchThatClause>(getDeclaration(lhs), getEntity(rhs),
                                       relType);
    } else if (hasDeclaration(rhs, rhsAllowed)) {
      cl = make_shared<SuchThatClause>(getEntity(lhs), getDeclaration(rhs),
                                       relType);
    } else {
      cl = make_shared<SuchThatClause>(getEntity(lhs), getEntity(rhs), relType);
    }
    if (isNot) cl = make_shared<NotClause>(cl);
    query.addClause(cl);
    if (isEnd() || !isKeyword("and")) break;
    checkKeyword("and");
  } while (true);
}

void QueryParser::readPattern() {
  checkKeyword("pattern");
  do {
    bool isNot = isKeyword("not");
    if (isNot) checkKeyword("not");
    if (isEnd()) throw SyntaxError("EOF reached, incomplete pattern clause");
    bool isPartial = false;
    Declaration syn;
    syn.label = readSyn();
    if (!query.hasDeclaration(syn.label)) {
      semanticErrList.push_back(
          SemanticError(SPA::format("Missing declaration for {}", syn.label)));
    } else {
      syn = query.getDeclarationByLabel(syn.label);
      if (!patternDeclTypes.count(syn.type)) {
        semanticErrList.push_back(SemanticError(SPA::format(
            "Synonym {} not of valid type for pattern queries", syn.label)));
      }
    }
    checkKeyword("(");
    vector<RawToken> expr;
    bool isWildcard = false;
    // check var or none
    EntityArg left = readEntityArg({VAR, EntityType::NULL_ENTITY});
    checkKeyword(",");
    // IMPT: By default, declarations that are not of the accepted types
    // (assign/while/if) will follow any rule that the rest of the clause
    // matches. The error will be detected as a SemanticError instead.
    // Only if none of the rules match will a SyntaxError be thrown.
    if (isKeyword("_")) {
      checkKeyword("_");
      isWildcard = true;
      if (isKeyword(",")) {
        checkKeyword(",");
        checkKeyword("_");
        if (syn.type != IF_STMT) {
          semanticErrList.push_back(
              SPA::format("Declaration `{}` is not an if stmt", syn));
        }
      } else if (syn.type != WHILE_STMT && syn.type != ASSIGN_STMT) {
        semanticErrList.push_back(
            SPA::format("Declaration `{}` is not a while/assign stmt", syn));
      }
    } else {
      if (syn.type != ASSIGN_STMT) {
        semanticErrList.push_back(
            SPA::format("Declaration `{}` is not an assign stmt", syn));
      }
      isPartial = isKeyword("_\"");
      checkKeyword(isPartial ? "_\"" : "\"");
      while (!isKeyword(isPartial ? "\"_" : "\"") && !isEnd()) {
        QueryToken token = step();
        if (token.type == QueryTokenType::DELIMITER && token.value != "(" &&
            token.value != ")") {
          throw SyntaxError(token, "Invalid delimiter found");
        }
        expr.push_back(token.value);
      }
      checkKeyword(isPartial ? "\"_" : "\"");
    }
    checkKeyword(")");

    // validate pattern
    if (!SPA::checkExpr(expr) && !expr.empty()) {
      throw SyntaxError("Invalid expression in pattern query");
    } else if (!isWildcard && expr.empty()) {
      throw SyntaxError("Invalid empty expression in pattern query");
    }

    // handle construction
    shared_ptr<Clause> cl;
    if (syn.type == ASSIGN_STMT &&
        hasDeclaration(left, patternDeclTypes.at(ASSIGN_STMT).at(0))) {
      // assert(syn.type == EntityType::ASSIGN_STMT);
      cl = make_shared<PatternClause>(syn, getDeclaration(left), expr,
                                      isPartial);
    } else if ((syn.type == IF_STMT || syn.type == WHILE_STMT) &&
               hasDeclaration(left, patternDeclTypes.at(syn.type).at(0))) {
      // assert(syn.type == EntityType::IF_STMT || syn.type ==
      // EntityType::WHILE_STMT);
      cl = make_shared<PatternClause>(syn, getDeclaration(left));
    } else if (syn.type == ASSIGN_STMT) {
      cl = make_shared<PatternClause>(syn, getEntity(left), expr, isPartial);
    } else if (syn.type == IF_STMT || syn.type == WHILE_STMT) {
      cl = make_shared<PatternClause>(syn, getEntity(left));
    }
    if (isNot) cl = make_shared<NotClause>(cl);
    query.addClause(cl);
    if (isEnd() || !isKeyword("and")) break;
    checkKeyword("and");
  } while (true);
}

pair<Declaration, EntityAttrType> QueryParser::readElement() {
  Declaration decl(EntityType::NULL_ENTITY, "");
  EntityAttrType attr = EntityAttrType::NULL_ATTR;
  if (isKeyword("BOOLEAN") && !query.hasDeclaration("BOOLEAN")) {
    checkKeyword("BOOLEAN");
    return {decl, attr};
  }
  decl.label = readSyn();
  if (!query.hasDeclaration(decl.label)) {
    semanticErrList.push_back(
        SemanticError(SPA::format("Declaration `{}` not found", decl.label)));
  } else {
    decl = query.getDeclarationByLabel(decl.label);
  }
  if (isKeyword(".")) {
    checkKeyword(".");
    auto attrToken = step();
    if (attrToken.type != QueryTokenType::WORD) {
      semanticErrList.push_back(
          SemanticError("Invalid entity attribute for declaration"));
    } else if (!entityAttrTypes.count(attrToken.value)) {
      throw SyntaxError(
          SPA::format("Unknown declaration attribute `{}`", attrToken.value));
    } else if (!entityAttrLabelOf.at(attrToken.value).count(decl.type)) {
      semanticErrList.push_back(
          SemanticError("Invalid entity attribute for declaration"));
    }
    attr = entityAttrTypes.at(attrToken.value);
  }
  return {decl, attr};
}

void QueryParser::readWith() {
  WithArg args[WITH_ARG_COUNT];
  checkKeyword("with");
  do {
    bool isNot = isKeyword("not");
    if (isNot) checkKeyword("not");
    if (isEnd()) throw SyntaxError("EOF reached, incomplete with clause");
    QueryTokenType attrValueType;
    for (size_t i = 0; i < WITH_ARG_COUNT; i++) {
      QueryTokenType currAttrValueType;
      if (isKeyword("\"")) {
        checkKeyword("\"");
        if (peek().type != QueryTokenType::WORD) {
          throw SyntaxError(peek(), "Expected name label");
        }
        args[i] = step().value;
        if (i == 0) attrValueType = QueryTokenType::WORD;
        currAttrValueType = QueryTokenType::WORD;
        checkKeyword("\"");
      } else if (peek().type == QueryTokenType::NUMBER) {
        args[i] = step().value;
        if (i == 0) attrValueType = QueryTokenType::NUMBER;
        currAttrValueType = QueryTokenType::NUMBER;
      } else {
        auto [decl, attrType] = readElement();
        if (attrType == EntityAttrType::NULL_ATTR) {
          throw SyntaxError(SPA::format(
              "expected attribute of declaration {}, none found", decl.label));
        }
        args[i] = std::make_pair(decl, attrType);
        if (i == 0) attrValueType = {entityAttrValueTypes.at(attrType)};
        currAttrValueType = entityAttrValueTypes.at(attrType);
      }
      if (i < WITH_ARG_COUNT - 1) checkKeyword("=");
      if (attrValueType != currAttrValueType) {
        semanticErrList.push_back(
            SemanticError("Mismatched attribute value types of with clause"));
      }
    }

    // handle construction
    shared_ptr<Clause> cl;
    if (isEntityLabel(args[0]) && isEntityLabel(args[1])) {
      cl = make_shared<WithClause>(getEntityLabel(args[0]),
                                   getEntityLabel(args[1]));
    } else if (isEntityLabel(args[0]) && isDeclRef(args[1])) {
      cl =
          make_shared<WithClause>(getEntityLabel(args[0]), getDeclRef(args[1]));
    } else if (isDeclRef(args[0]) && isEntityLabel(args[1])) {
      cl =
          make_shared<WithClause>(getDeclRef(args[0]), getEntityLabel(args[1]));
    } else if (isDeclRef(args[0]) && isDeclRef(args[1])) {
      cl = make_shared<WithClause>(getDeclRef(args[0]), getDeclRef(args[1]));
    } else {
      throw SyntaxError(
          "LHS or RHS of with clause is not well formed or undefined");
    }
    if (isNot) cl = make_shared<NotClause>(cl);
    query.addClause(cl);

    if (isEnd() || !isKeyword("and")) break;
    checkKeyword("and");
  } while (true);
}

void QueryParser::readResult() {
  bool isTuple = isKeyword("<");
  if (isTuple) {
    checkKeyword("<");
  }
  while (true) {
    auto [decl, attrType] = readElement();
    if (decl.label.empty() && isTuple) {
      throw SyntaxError("Invalid tuple with BOOLEAN");
    } else if (decl.type != EntityType::NULL_ENTITY) {
      if (attrType != EntityAttrType::NULL_ATTR) {
        query.selectDeclAttr(decl.label, attrType);
      } else {
        query.selectDecl(decl.label);
      }
    }
    if (!isTuple) break;
    if (isKeyword(","))
      checkKeyword(",");
    else
      break;
  }
  if (isTuple) {
    checkKeyword(">");
  }
}

void QueryParser::readSelect() {
  checkKeyword("Select");
  readResult();
  while (!isEnd()) {
    QueryToken keyword = peek();
    if (keyword.value == "such") {
      readSuchThat();
    } else if (keyword.value == "pattern") {
      readPattern();
    } else if (keyword.value == "with") {
      readWith();
    } else {
      throw SyntaxError(keyword, "Unexpected token");
    }
  }
}

Query QueryParser::parse(const std::string& qstr) {
  QueryTokenizer tokenizer;
  return parseTokens(tokenizer.tokenize(qstr));
}

Query QueryParser::parseTokens(const vector<QueryToken>& _tokens) {
  reset();
  tokens = _tokens;
  while (!isEnd() && !isKeyword("Select")) {
    readDecl();
  }
  readSelect();
  if (!semanticErrList.empty()) throw semanticErrList.front();
  return query;
}

void QueryParser::reset() {
  pos = 0;
  tokens.clear();
  query = Query();
}
