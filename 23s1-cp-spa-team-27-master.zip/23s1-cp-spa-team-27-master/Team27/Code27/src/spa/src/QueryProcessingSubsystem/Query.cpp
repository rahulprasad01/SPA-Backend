#include "Query.h"
#include <algorithm>
#include <iostream>
#include <sstream>

using namespace QPS;

Query& Query::addDeclaration(const Declaration& decl) {
  this->declarations[decl.label] = decl;
  return *this;
}
Query& Query::selectDecl(const std::string& label) {
  return this->selectDeclAttr(label, SPA::EntityAttrType::NULL_ATTR);
}
Query& Query::selectDeclAttr(const std::string& label,
                             const SPA::EntityAttrType& attr) {
  if (!hasDeclaration(label))
    throw std::invalid_argument("No such declaration");
  this->selections.push_back(Selection(getDeclarationByLabel(label), attr));
  return *this;
}
Query& Query::addClause(const std::shared_ptr<Clause>& clause) {
  this->clauses.emplace_back(clause);
  return *this;
}
bool Query::hasDeclaration(const std::string& label) const {
  return declarations.count(label);
}
const Declaration& Query::getDeclarationByLabel(
    const std::string& label) const {
  return declarations.at(label);
}
bool Query::equal_to(const Query& other) const {
  if (clauses.size() != other.clauses.size()) return false;
  for (int i = 0; i < clauses.size(); ++i) {
    if (*clauses[i] != *other.clauses[i]) return false;
  }
  return declarations == other.declarations && selections == other.selections;
};
std::string Query::to_string() const {
  std::stringstream ss;
  for (const auto& [l, d] : declarations) {
    ss << d << "; ";
  }
  ss << "\nSelect ";
  if (selections.size() == 0) {
    ss << "BOOLEAN ";
  } else if (selections.size() == 1) {
    ss << selections[0] << " ";
  } else {
    ss << "<";
    for (const auto& s : selections) {
      ss << s << ",";
    }
    ss << "\b> ";
  }
  for (const auto& c : clauses) {
    ss << c->to_string() << " ";
  }
  return ss.str();
}
bool Query::Selection::equal_to(const Selection& other) const {
  return other.decl == decl && other.attr == attr;
}
std::string Query::Selection::to_string() const {
  if (attr == EntityAttrType::NULL_ATTR) return decl.label;
  return decl.label + "." + SPA::EntityAttrToString(attr);
}