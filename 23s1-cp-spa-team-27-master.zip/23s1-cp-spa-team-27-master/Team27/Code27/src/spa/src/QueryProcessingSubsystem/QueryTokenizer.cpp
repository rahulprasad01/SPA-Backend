#include "QueryTokenizer.h"
#include <unordered_map>

using namespace QPS;

const std::unordered_set<char> delimiters_heads = {'(', ')', ',', '"', ';',
                                                   '<', '>', '_', '.'};
const std::unordered_set<std::string> delimiters = {
    "(", ")", ",", "\"", ";", "<", ">", "_", "_\"", "\"_", "."};
const std::unordered_set<char> ops = {'+', '-', '*', '/', '%', '='};

const std::unordered_map<char, std::unordered_set<std::string>> appendTo = {
    {'*', {"Parent", "Follows", "Calls", "Next"}}, {'#', {"stmt"}}};

vector<QueryToken> QueryTokenizer::tokenize(const std::string& fulltext,
                                            bool ignoreSpaces) {
  tokens.clear();
  charPos = 0;
  this->text = fulltext;
  int len = text.length();
  while (charPos < len) {
    std::string tokenValue;
    QueryTokenType tokenType;
    char c = peek();
    if (c == EOF) {
      break;
    } else if (isspace(c)) {
      tokenType = QueryTokenType::WHITESPACE;
      tokenValue = readSpace();
    } else if (isdigit(c)) {
      tokenType = QueryTokenType::NUMBER;
      tokenValue = readNumber();
    } else if (isDelimiter(c)) {
      tokenType = QueryTokenType::DELIMITER;
      tokenValue = readDelimiter();
    } else if (isOperator(c)) {
      tokenType = QueryTokenType::OP;
      tokenValue = readOperator();
    } else if (isWord(c)) {
      tokenType = QueryTokenType::WORD;
      tokenValue = readWord();
    } else {
      throw InvalidLexicalTokenException(std::string(1, peek()), "OTHER",
                                         charPos);
    }
    if (tokenValue.length() == 0) {
      throw InvalidLexicalTokenException(tokenValue, "UNKNOWN", charPos);
    } else if (ignoreSpaces && tokenType == QueryTokenType::WHITESPACE) {
      continue;
    }
    tokens.push_back(QueryToken{tokenType, tokenValue});
  }
  return tokens;
}

bool QueryTokenizer::isOperator(char c) { return ops.count(c) > 0; }

std::string QueryTokenizer::readOperator() {
  char c = peek();
  if (ops.count(c) == 0) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "OPERATOR",
                                       charPos);
  }
  return std::string(1, step());
}

bool QueryTokenizer::isDelimiter(char c) {
  return delimiters_heads.count(c) > 0;
}

std::string QueryTokenizer::readDelimiter() {
  char c = peek();
  if (delimiters_heads.count(c) == 0) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "DELIMITER",
                                       charPos);
  } else if (c == '\"' && !tokens.empty() && tokens.back().value == "_") {
    tokens.pop_back();
    step();
    return "_\"";
  } else if (c == '_' && !tokens.empty() && tokens.back().value == "\"") {
    tokens.pop_back();
    step();
    return "\"_";
  }
  step();
  vector<char> cs = {c, peek()};
  std::string cstr = std::string(cs.begin(), cs.end());
  if (delimiters.count(cstr) > 0) {
    step();
    return cstr;
  }

  return std::string(1, c);
}
std::string QueryTokenizer::readWord() {
  vector<char> word;
  if (!isalpha(peek())) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "WORD", charPos);
  }
  while (isalnum(peek())) {
    word.push_back(step());
  }
  if (appendTo.count(peek()) &&
      appendTo.at(peek()).count(std::string(word.begin(), word.end()))) {
    word.push_back(step());
  }
  return std::string(word.begin(), word.end());
}