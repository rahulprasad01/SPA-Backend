#pragma once
#include <assert.h>
#include <optional>
#include <sstream>
#include "Clause.h"

namespace QPS {
class PatternClause : public Clause {
 public:
  // Left can be either declaration or entity. If it is a declaration, it will
  // be resolved to different possible entities during evaluation.
  template <typename T,
            std::enable_if_t<std::is_same<QPS::Declaration, T>::value ||
                                 std::is_same<SPA::Entity, T>::value,
                             bool> = true>
  PatternClause(const QPS::Declaration& assignStmt, const T& left,
                const std::vector<SPA::RawToken>& pattern, bool isPartial)
      : stmt(assignStmt), pattern(pattern), isPartial(isPartial) {
    assert(assignStmt.type == EntityType::ASSIGN_STMT);
    setLeft(left);
  }
  // Used for while and if pattern clauses
  template <typename T,
            std::enable_if_t<std::is_same<QPS::Declaration, T>::value ||
                                 std::is_same<SPA::Entity, T>::value,
                             bool> = true>
  PatternClause(const QPS::Declaration& contStmt, const T& left)
      : stmt(contStmt), isPartial(true) {
    assert(contStmt.type == EntityType::WHILE_STMT ||
           contStmt.type == EntityType::IF_STMT);
    setLeft(left);
  }
  bool test(const Candidate& candidate, PKB::PKBQuery& pkb);
  std::vector<QPS::Declaration> getDeclarations();
  std::string to_string() const;
  bool equal_to(const Clause& other) const;

 private:
  QPS::Declaration stmt;
  std::optional<SPA::Entity> leftEntity;
  std::optional<QPS::Declaration> leftDecl;
  std::vector<SPA::RawToken> pattern;
  bool isPartial;
  void setLeft(const SPA::Entity& entity);
  void setLeft(const QPS::Declaration& entity);
};
}  // namespace QPS