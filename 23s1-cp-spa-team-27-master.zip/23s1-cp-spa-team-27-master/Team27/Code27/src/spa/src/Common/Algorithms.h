#pragma once
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "Entity.h"
#include "SPADefinitions.h"

using std::unordered_map;
using std::unordered_set;
using std::vector;

namespace SPA {
vector<size_t> toposort(vector<unordered_set<size_t>> map);
bool hasCycle(vector<unordered_set<size_t>>& map);
vector<RawToken> infixToPostfix(const vector<RawToken>& tokens);
std::string concat(const vector<std::string>& s, const char* delim);
vector<std::string> split(const std::string& s);
bool checkExpr(const vector<RawToken>& expr);
void validateEntity(const Entity& entity, EntityType requiredType);
void validateEntity(const Entity& entity,
                    unordered_set<EntityType> allowedTypes);
bool isWholeNumber(const std::string& s);
// indexes are assumed to be sorted
template <typename T>
std::pair<vector<vector<T>>, vector<int>> joinTables(
    vector<vector<T>>& a, const vector<int>& a_index, vector<vector<T>>& b,
    const vector<int>& b_index);
// proj_index is assumed to be a multi-subset of a_index, duplicate results are
// removed
template <typename T>
vector<vector<T>> projectFromTable(vector<vector<T>>& a,
                                   const vector<int>& a_index,
                                   const vector<int>& proj_index);
}  // namespace SPA
