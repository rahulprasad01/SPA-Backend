#pragma once
#include <stdexcept>
#include "Common/Format.h"

namespace SPA {

class SPAException : public std::runtime_error {
 public:
  SPAException(std::string msg)
      : std::runtime_error(SPA::format("SPA : {}", msg)) {}
};
}  // namespace SPA
