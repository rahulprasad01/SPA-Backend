#pragma once
#include <algorithm>
#include <stdexcept>
#include <string>
#include <unordered_set>
using std::unordered_set;

namespace SPA {

enum EntityType {
  NULL_ENTITY,
  PROC,
  VAR,
  CONST,
  STMT,
  STMT_LIST,
  READ_STMT,
  PRINT_STMT,
  CALL_STMT,
  WHILE_STMT,
  IF_STMT,
  ASSIGN_STMT,
};

constexpr int ENTITY_TYPE_COUNT = 12;

enum EntityAttrType {
  PROCNAME,
  VARNAME,
  VALUE,
  STMTNO,
  NULL_ATTR,
};

enum RelationType {
  FOLLOWS,
  FOLLOWS_T,
  PARENT,
  PARENT_T,
  USES,
  MODIFIES,
  CALLS,
  CALLS_T,
  NEXT,
  NEXT_T,
  AFFECTS,
};

using RawToken = std::string;

const unordered_set<EntityType> stmtTypes({STMT, READ_STMT, PRINT_STMT,
                                           CALL_STMT, WHILE_STMT, IF_STMT,
                                           ASSIGN_STMT});

using EntityRef = std::string;
using PatternRef = std::string;

inline const char* EntityToString(EntityType type) {
  switch (type) {
    case SPA::PROC:
      return "procedure";
    case SPA::VAR:
      return "variable";
    case SPA::CONST:
      return "const";
    case SPA::STMT:
      return "stmt";
    case SPA::READ_STMT:
      return "read";
    case SPA::PRINT_STMT:
      return "print";
    case SPA::CALL_STMT:
      return "call";
    case SPA::WHILE_STMT:
      return "while";
    case SPA::IF_STMT:
      return "if";
    case SPA::ASSIGN_STMT:
      return "assign";
    default:
      return "NULL";
  }
}

inline const char* RelationToString(RelationType type) {
  switch (type) {
    case RelationType::FOLLOWS:
      return "Follows";
    case RelationType::FOLLOWS_T:
      return "Follows*";
    case RelationType::PARENT:
      return "Parent";
    case RelationType::PARENT_T:
      return "Parent*";
    case RelationType::MODIFIES:
      return "Modifies";
    case RelationType::USES:
      return "Uses";
    case RelationType::CALLS:
      return "Calls";
    case RelationType::CALLS_T:
      return "Calls*";
    case RelationType::NEXT:
      return "Next";
    case RelationType::NEXT_T:
      return "Next*";
    case RelationType::AFFECTS:
      return "Affects";
    default:
      return "NULL";
  }
}

inline const char* EntityAttrToString(EntityAttrType type) {
  switch (type) {
    case EntityAttrType::PROCNAME:
      return "procName";
    case EntityAttrType::VARNAME:
      return "varName";
    case EntityAttrType::STMTNO:
      return "stmt#";
    case EntityAttrType::VALUE:
      return "value";
    default:
      return "NULL";
  }
}

inline bool isIntegerLabel(const std::string& s) {
  if (s == "0") return true;
  auto it = std::find_if(std::begin(s), std::end(s),
                         [](unsigned char c) { return !std::isdigit(c); });
  return it == std::end(s) && s[0] != '0';
}

inline bool isNameLabel(const std::string& s) {
  auto it = std::find_if(std::begin(s), std::end(s),
                         [](unsigned char c) { return !std::isalnum(c); });
  return std::isalpha(s[0]) && it == std::end(s);
}

}  // namespace SPA
