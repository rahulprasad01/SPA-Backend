#include "Entity.h"
#include "Common/Format.h"
#include "SPADefinitions.h"

using namespace SPA;

void Entity::validate() const {
  if ((isStmt() || type == SPA::CONST) && !isIntegerLabel(label)) {
    // either STMT or CONST
    throw InvalidEntityException(
        *this, SPA::format("invalid {} label", EntityToString(type)));
  } else if ((type == SPA::VAR || type == SPA::PROC) && !isNameLabel(label)) {
    // either PROC or VAR
    throw InvalidEntityException(
        *this, SPA::format("invalid {} name", EntityToString(type)));
  }
}
