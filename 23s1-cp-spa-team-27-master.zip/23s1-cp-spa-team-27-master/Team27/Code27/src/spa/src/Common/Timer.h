#pragma once
#include <chrono>
#include <iostream>

namespace SPA {
class Timer {
 public:
  std::chrono::system_clock::time_point reset() {
    start = std::chrono::system_clock::now();
    return start;
  }
  std::chrono::duration<double> get_time() {
    const auto end = std::chrono::system_clock::now();
    return std::chrono::duration<double>{end - start};
  }
  std::chrono::duration<double, std::milli> get_time_ms() {
    const auto end = std::chrono::system_clock::now();
    return std::chrono::duration<double, std::milli>(end - start);
  }

  void print_time() {
    const auto t = get_time_ms();
    std::cerr << t.count() << "ms" << std::endl;
  }

 private:
  std::chrono::system_clock::time_point start;
};

// Always initialize the benchmarker, __timer should not be redeclared in the
// current context.
#define INIT_BENCHMARK() Timer __timer;

// Benchmark fn (in ms) without any label
#define BENCHMARK(fn) \
  __timer.reset();    \
  fn;                 \
  __timer.print_time();

// Benchmark fn (in ms) with any label
#define BENCHMARK_LABEL(label, fn) \
  std::cerr << label << ": ";      \
  BENCHMARK(fn);

}  // namespace SPA
