#pragma once
#include <omp.h>
#include <iostream>

// per OpenMP standard, _OPENMP defined when compiling with OpenMP
#ifdef _OPENMP
#ifdef _MSC_VER
// must use MSVC __pragma here instead of _Pragma otherwise you get an internal
// compiler error. still an issue in Visual Studio 2022
#define OMP_PARALLEL_FOR __pragma("\"omp parallel for\"")
#define OMP_CRITICAL __pragma("\"omp critical\"")
// any other standards-compliant C99/C++11 compiler
#else
#define OMP_PARALLEL_FOR _Pragma("\"omp parallel for\"")
#define OMP_CRITICAL _Pragma("\"omp critical\"")
#endif  // _MSC_VER
// no OpenMP support
#else
#define OMP_PARALLEL_FOR
#define OMP_CRITICAL
#endif  // _OPENMP

// Adapted from Barton-Nackman trick
template <typename T>
class equal_comparable {
  friend bool operator==(T const &a, T const &b) { return a.equal_to(b); }
  friend bool operator!=(T const &a, T const &b) { return !a.equal_to(b); }
};

template <typename T>
class stringifiable {
  friend std::ostream &operator<<(std::ostream &out, T const &s) {
    return out << s.to_string();
  }
};