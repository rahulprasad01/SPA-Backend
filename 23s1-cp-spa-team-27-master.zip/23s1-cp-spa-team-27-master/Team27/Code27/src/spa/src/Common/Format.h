#pragma once
#include <cstring>
#include <sstream>
#include <string>

namespace SPA {
inline std::string format(const char* fmt, std::ostringstream&& oss) {
  oss << fmt;
  return oss.str();
}

inline std::string format(const char* fmt) { return fmt; }

template <typename Arg1, typename... Args>
inline std::string format(const char* fmt, std::ostringstream&& oss,
                          Arg1&& arg1, Args&&... rest) {
  auto len = strlen(fmt);
  for (size_t i = 0; i < len; i++) {
    if (fmt[i] == '{' && i + 1 < len && fmt[i + 1] == '}') {
      oss << std::string_view(fmt, i)  //
          << arg1;
      return format(fmt + i + 2, std::move(oss), std::forward<Args>(rest)...);
    }
  }
  oss << fmt;
  return oss.str();
}

template <typename Arg1, typename... Args>
inline std::string format(const char* fmt, Arg1&& arg1, Args&&... rest) {
  return format(fmt, std::ostringstream(), arg1, std::forward<Args>(rest)...);
}

}  // namespace SPA