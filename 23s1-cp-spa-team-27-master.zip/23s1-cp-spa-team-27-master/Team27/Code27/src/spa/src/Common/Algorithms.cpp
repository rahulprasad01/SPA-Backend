#include "Algorithms.h"
#include <algorithm>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include "Common/Format.h"
#include "Common/SPADefinitions.h"
#include "Common/SPAException.h"
#include "Common/Utility.h"

using std::map;
using std::stack;
using std::unordered_map;
using std::unordered_set;
using std::vector;

using namespace SPA;

const unordered_map<RawToken, int> op_priority = {
    {"+", 0}, {"-", 0}, {"*", 1}, {"/", 1}, {"%", 1},
};

vector<size_t> SPA::toposort(vector<unordered_set<size_t>> map) {
  // Kahn's algorithm
  vector<size_t> incomingEdgeCount(map.size(), 0);
  for (const auto& set : map) {
    for (const auto& i : set) {
      if (i > map.size()) {
        throw std::runtime_error(SPA::format(
            "Vertex Index {} out of bounds (0 to {})", i, map.size()));
      }
      incomingEdgeCount[i]++;
    }
  }
  using EdgeCount = std::pair<size_t, size_t>;
  auto cmp = [](EdgeCount a, EdgeCount b) { return a.second > b.second; };
  std::priority_queue<EdgeCount, vector<EdgeCount>, decltype(cmp)>
      minIncomingEdges(cmp);
  for (size_t i = 0; i < incomingEdgeCount.size(); i++) {
    minIncomingEdges.push({i, incomingEdgeCount[i]});
  }
  size_t left = map.size();
  vector<bool> visited(map.size(), false);
  vector<size_t> sorted;
  while (!minIncomingEdges.empty() && left > 0) {
    EdgeCount curr = minIncomingEdges.top();
    minIncomingEdges.pop();
    if (visited[curr.first]) continue;
    if (curr.second != 0) {
      return {};
    }
    sorted.push_back(curr.first);
    left--;
    visited[curr.first] = true;
    for (const auto& next : map[curr.first]) {
      minIncomingEdges.push({next, --incomingEdgeCount[next]});
    }
  }
  return sorted;
}

bool SPA::hasCycle(vector<unordered_set<size_t>>& map) {
  auto sorted = SPA::toposort(map);
  // if not all the vertices are in the toposort,
  // a cycle was detected and the toposort terminated
  return sorted.size() != map.size();
}

vector<RawToken> SPA::infixToPostfix(const vector<RawToken>& tokens) {
  stack<std::pair<RawToken, int>> opstack;
  vector<RawToken> outputq;
  for (const RawToken& t : tokens) {
    if (op_priority.count(t) > 0) {
      int priority = op_priority.at(t);
      while (!opstack.empty() && opstack.top().second >= priority) {
        outputq.push_back(opstack.top().first);
        opstack.pop();
      }
      opstack.emplace(t, priority);
    } else if (t == "(") {
      opstack.emplace(t, -1);
    } else if (t == ")") {
      while (!opstack.empty() && opstack.top().first != "(") {
        outputq.push_back(opstack.top().first);
        opstack.pop();
      }
      if (opstack.empty()) {
        throw SPA::SPAException("Mismatched parentheses in the expression " +
                                concat(tokens, " "));
      }
      // top should be "("
      opstack.pop();
    } else {
      outputq.push_back(t);
    }
  }
  while (!opstack.empty()) {
    if (opstack.top().first == "(") {
      throw SPA::SPAException("Mismatched parentheses in the expression " +
                              concat(tokens, " "));
    }
    outputq.push_back(opstack.top().first);
    opstack.pop();
  }
  return outputq;  // now in reverse polish notation
}

std::string SPA::concat(const vector<std::string>& s, const char* delim) {
  if (s.empty()) return "";

  std::ostringstream imploded;
  imploded << " ";
  std::copy(s.begin(), s.end(),
            std::ostream_iterator<std::string>(imploded, delim));
  return imploded.str();
}

vector<std::string> SPA::split(const std::string& s) {
  // Splits with spaces as delimiter
  if (s == "") return vector<std::string>();

  std::stringstream ss(s);
  vector<std::string> stringVector;
  for (std::string t; ss >> t;) {
    stringVector.push_back(t);
  }
  return stringVector;
}

class ExprValidator {
 public:
  ExprValidator(const vector<RawToken>& _tokens) : pos(0) {
    // tokens.push_back("(");
    std::copy(_tokens.begin(), _tokens.end(), std::back_inserter(tokens));
    // tokens.push_back(")");
  }
  bool validate() {
    pos = tokens.size() - 1;
    return expr() && pos < 0;
  }

 private:
  int pos;
  vector<RawToken> tokens;
  const RawToken& peek(int offset = 0) {
    if (pos - offset < 0) return "";
    return tokens[pos - offset];
  }
  RawToken step() {
    if (pos < 0) return "";
    return tokens[pos--];
  }
  bool check(const RawToken& val, int offset = 0) {
    if (pos - offset < 0) return false;
    return tokens[pos - offset] == val;
  }
  bool expr() {
    if (!term()) return false;
    if (check("+") || check("-")) {
      step();  // middle op
      return expr();
    }
    return true;
  }
  bool term() {
    if (!factor()) return false;
    if (check("*") || check("/") || check("%")) {
      step();  // middle op
      return term();
    }
    return true;
  }
  bool factor() {
    if (check(")")) {
      step();
      if (!expr()) return false;
      return step() == "(";
    }
    const RawToken& s = step();
    bool isfactor = !s.empty() && (isNameLabel(s) || isIntegerLabel(s));
    return isfactor;
  }
};

bool SPA::checkExpr(const vector<RawToken>& expr) {
  ExprValidator validator(expr);
  return validator.validate();
}

void SPA::validateEntity(const Entity& entity, EntityType requiredType) {
  if (entity.type != requiredType) {
    throw SPA::InvalidEntityException(
        entity, SPA::format("type {} is not of type {}",
                            SPA::EntityToString(entity.type),
                            SPA::EntityToString(requiredType)));
  }
  entity.validate();
}

void SPA::validateEntity(const Entity& entity,
                         std::unordered_set<EntityType> allowedTypes) {
  if (!allowedTypes.count(entity.type)) {
    throw SPA::InvalidEntityException(
        entity, SPA::format("type {} is not allowed",
                            SPA::EntityToString(entity.type)));
  }
  entity.validate();
}

bool SPA::isWholeNumber(const std::string& s) {
  if (s == "0") return true;
  if (s.empty() || s[0] == '0') return false;
  return std::all_of(s.begin(), s.end(),
                     [](const char& c) { return '0' <= c && c <= '9'; });
}

template <typename T>
std::pair<vector<vector<T>>, vector<int>> SPA::joinTables(
    vector<vector<T>>& a, const vector<int>& a_index, vector<vector<T>>& b,
    const vector<int>& b_index) {
  unordered_map<int, int> key_index, c_index;  // join index
  for (int i : a_index) {
    int j = c_index.size();
    c_index[i] = j;
  }
  for (int i : b_index) {
    int j = c_index.size();
    int k = key_index.size();
    if (c_index.count(i))
      key_index[i] = k;
    else
      c_index[i] = j;
  }
  vector<int> c_index_vec(c_index.size());
  for (auto& kv : c_index) c_index_vec[kv.second] = kv.first;
  if (a_index.empty()) return {b, std::move(c_index_vec)};
  if (b_index.empty()) return {a, std::move(c_index_vec)};
  if (a.empty() || b.empty()) return {{}, std::move(c_index_vec)};
  map<vector<T>, vector<int>> a_map;
  OMP_PARALLEL_FOR
  for (int i = 0; i < a.size(); ++i) {
    auto& row = a[i];
    vector<T> key(key_index.size());
    for (int j = 0; j < a_index.size(); ++j)
      if (key_index.count(a_index[j])) key[key_index[a_index[j]]] = row[j];
    OMP_CRITICAL { a_map[key].push_back(i); }
  }
  vector<vector<T>> c;
  OMP_PARALLEL_FOR
  for (int i = 0; i < b.size(); ++i) {
    auto& b_row = b[i];
    vector<T> key(key_index.size());
    for (int j = 0; j < b_index.size(); ++j)
      if (key_index.count(b_index[j])) key[key_index[b_index[j]]] = b_row[j];
    for (int j : a_map[key]) {
      auto& a_row = a[j];
      vector<T> e(c_index.size());
      for (int k = 0; k < a_index.size(); ++k)
        e[c_index[a_index[k]]] = a_row[k];
      for (int k = 0; k < b_index.size(); ++k)
        e[c_index[b_index[k]]] = b_row[k];
      OMP_CRITICAL { c.push_back(std::move(e)); }
    }
  }
  return {std::move(c), std::move(c_index_vec)};
}

template std::pair<vector<vector<int>>, vector<int>> SPA::joinTables(
    vector<vector<int>>& a, const vector<int>& a_index, vector<vector<int>>& b,
    const vector<int>& b_index);  // for testing
template std::pair<vector<vector<SPA::EntityRef>>, vector<int>> SPA::joinTables(
    vector<vector<SPA::EntityRef>>& a, const vector<int>& a_index,
    vector<vector<SPA::EntityRef>>& b,
    const vector<int>& b_index);  // for implementation
template std::pair<vector<vector<SPA::Entity>>, vector<int>> SPA::joinTables(
    vector<vector<SPA::Entity>>& a, const vector<int>& a_index,
    vector<vector<SPA::Entity>>& b,
    const vector<int>& b_index);  // for implementation

template <typename T>
vector<vector<T>> SPA::projectFromTable(vector<vector<T>>& a,
                                        const vector<int>& a_index,
                                        const vector<int>& proj_index) {
  int width = proj_index.size();
  vector<vector<T>> c;
  unordered_map<int, int> inv_a_index;
  for (int i = 0; i < a_index.size(); ++i) inv_a_index[a_index[i]] = i;
  OMP_PARALLEL_FOR
  for (auto& row : a) {
    vector<T> e;
    for (auto& i : proj_index) e.push_back(row[inv_a_index[i]]);
    OMP_CRITICAL { c.push_back(std::move(e)); }
  }
  // Remove duplicates
  std::sort(c.begin(), c.end());
  c.erase(std::unique(c.begin(), c.end()), c.end());
  return c;
}

template vector<vector<int>> SPA::projectFromTable(
    vector<vector<int>>& a, const vector<int>& a_index,
    const vector<int>& proj_index);  // for testing
template vector<vector<SPA::EntityRef>> SPA::projectFromTable(
    vector<vector<SPA::EntityRef>>& a, const vector<int>& a_index,
    const vector<int>& proj_index);  // for implementation
template vector<vector<SPA::Entity>> SPA::projectFromTable(
    vector<vector<SPA::Entity>>& a, const vector<int>& a_index,
    const vector<int>& proj_index);  // for implementation