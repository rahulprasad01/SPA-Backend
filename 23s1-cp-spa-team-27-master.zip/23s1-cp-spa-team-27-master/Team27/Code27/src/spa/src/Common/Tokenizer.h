#pragma once
#include <string>
#include <unordered_set>
#include <vector>
#include "LexicalToken.h"
#include "SPAException.h"
using std::vector;

namespace SPA {

class InvalidLexicalTokenException : public SPAException {
 public:
  InvalidLexicalTokenException(std::string token, std::string type,
                               size_t lineNum)
      : SPAException(SPA::format("[InvalidLexicalTokenException] Invalid "
                                 "token {} for type {} at input line {}",
                                 token, type, lineNum)) {}
};

template <typename T>
class Tokenizer {
 public:
  Tokenizer() : text(""), charPos(0), inputLineNum(1) {}
  virtual vector<T> tokenize(const std::string& text, bool ignoreSpaces) = 0;

 protected:
  std::string text;
  size_t charPos;
  size_t inputLineNum;
  char peek(size_t idx = 0);
  char step();
  virtual bool isWord(char c);
  virtual std::string readSpace();
  virtual std::string readNumber();
  virtual std::string readWord();
};

template <typename T>
char Tokenizer<T>::peek(size_t idx) {
  if (charPos + idx >= text.length()) {
    return EOF;
  } else {
    return text[charPos + idx];
  }
}

template <typename T>
char Tokenizer<T>::step() {
  char c = peek();
  charPos++;
  return c;
}

template <typename T>
bool Tokenizer<T>::isWord(char c) {
  return isalnum(c);
}

template <typename T>
std::string Tokenizer<T>::readSpace() {
  if (!isspace(peek())) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "SPACE",
                                       charPos);
  }
  if (peek() == '\n') {
    inputLineNum++;
  }
  while (isspace(peek())) {
    step();
  }
  return " ";
}

template <typename T>
std::string Tokenizer<T>::readNumber() {
  vector<char> digits;
  if (peek() == '0') {
    step();
    if (isalnum(peek())) {
      throw InvalidLexicalTokenException("0" + std::string(1, peek()), "NUMBER",
                                         inputLineNum);
    }
    return "0";
  }
  while (isdigit(peek())) {
    digits.push_back(step());
  }
  return std::string(digits.begin(), digits.end());
}

template <typename T>
std::string Tokenizer<T>::readWord() {
  vector<char> word;
  if (!isWord(peek())) {
    throw InvalidLexicalTokenException(std::string(1, peek()), "WORD",
                                       inputLineNum);
  }
  while (isalnum(peek())) {
    word.push_back(step());
  }
  return std::string(word.begin(), word.end());
}
}  // namespace SPA
