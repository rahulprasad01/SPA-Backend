#pragma once
#include <functional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include "Common/Format.h"
#include "SPADefinitions.h"
#include "SPAException.h"
using std::unordered_map;
using std::unordered_set;

namespace SPA {

struct Entity {
  EntityType type;
  EntityRef label;
  unordered_map<EntityAttrType, std::string> attributes;

  struct KeyHasher {
    std::size_t operator()(const Entity& e) const {
      std::size_t hash1 = std::hash<EntityType>()(e.type);
      std::size_t hash2 = std::hash<EntityRef>()(e.label);
      return hash1 ^ (hash2 << 1);
    }
  };

  Entity() : type(NULL_ENTITY), label("") {}
  Entity(EntityType type, EntityRef label) : type(type), label(label) {}
  Entity(EntityType type, EntityRef label,
         unordered_map<EntityAttrType, std::string> attributes)
      : type(type), label(label), attributes(attributes) {}

  bool isStmt() const { return stmtTypes.count(type); }
  void addAttribute(const EntityAttrType& attrType, const std::string& val) {
    attributes[attrType] = val;
  }
  bool hasAttribute(const EntityAttrType& attrType) const {
    return attributes.count(attrType);
  }
  std::string getAttribute(const EntityAttrType& attrType) const {
    return attributes.at(attrType);
  }
  bool operator==(const Entity& other) const {
    return other.label == label && other.type == type;
  }
  bool operator!=(const Entity& other) const {
    return other.label != label || other.type != type;
  }
  bool operator<(const Entity& other) const { return label < other.label; }
  void validate() const;
  friend std::ostream& operator<<(std::ostream& out, const Entity& cl);
};

const Entity WILDCARD = Entity(EntityType::NULL_ENTITY, "");

class InvalidEntityException : public SPAException {
 public:
  InvalidEntityException(const Entity& entity, std::string error)
      : SPAException(SPA::format("[InvalidEntityException] {} of type {}: {}",
                                 entity.label, EntityToString(entity.type),
                                 error)) {}
};
inline std::ostream& operator<<(std::ostream& out, const Entity& cl) {
  if (cl.isStmt()) return out << cl.label;
  if (cl.type == NULL_ENTITY) return out << "_";
  return out << "\"" << cl.label << "\"";
}
}  // namespace SPA
