#pragma once
#include <string>

namespace SPA {

template <class T>
struct LexicalToken {
  T type;
  std::string value;

  LexicalToken(T type, std::string value) : type(type), value(value) {}

  bool operator==(const LexicalToken<T>& other) const {
    return type == other.type && value == other.value;
  }

  bool operator!=(const LexicalToken<T>& other) const {
    return type != other.type || value != other.value;
  }
};
}  // namespace SPA
