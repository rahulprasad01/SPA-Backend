#include <algorithm>
#include <filesystem>
#include <iostream>
#include <list>
#include <numeric>
#include "Common/SPADefinitions.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "QueryProcessingSubsystem/QueryProcessor.h"
#include "TestUtils.h"
#include "catch.hpp"

using namespace QPS;
using namespace SPA;
using namespace TEST;

TEST_CASE ("QueryProcessor: Empty PKB") {
  PKBManager pkbManager;
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> expected = {};
  qps.evaluate("assign a; Select a", results);
  REQUIRE(results == expected);
  SECTION ("pattern parsing: brackets and nested brackets") {
    qps.evaluate(
        "assign a, a1, a2; variable x, y; Select x such that Follows (a, a1) "
        "pattern a2 (y, _\"(y) \"_)",
        results);
    REQUIRE(results == expected);
    qps.evaluate(
        "assign a, a1, a2; variable x, y; Select x such that Follows (a, a1) "
        "pattern a2 (y, _\"(((y))) \"_)",
        results);
    REQUIRE(results == expected);
  }
  SECTION ("pattern parsing: long term") {
    qps.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"1 * x / 2 % 3\"_)",
        results);
    REQUIRE(results == expected);
  }
  SECTION ("pattern parsing: long expr") {
    qps.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"1 + x - 2 + 3\"_)",
        results);
    REQUIRE(results == expected);
  }
  SECTION ("pattern parsing: expr term") {
    qps.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"1 + x / 2\"_)",
        results);
    REQUIRE(results == expected);
  }
}

TEST_CASE ("QueryProcessor: Invalid Syntax") {
  PKBManager pkbManager;
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> syntaxErr = {"SyntaxError"};
  std::list<string> semanticErr = {"SemanticError"};
  SECTION ("Invalid entity type (incomplete clause)") {
    std::list<string> results;
    qps.evaluate("variable a; Select a such that pattern a(_, _)", results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid entity type (such that)") {
    std::list<string> results;
    qps.evaluate("variable a, a1; Select a such that Follows(a, a1)", results);
    REQUIRE(results == semanticErr);
  }
  SECTION ("Missing declaration") {
    std::list<string> results;
    qps.evaluate("assign a1; Select a", results);
    REQUIRE(results == semanticErr);
  }
  SECTION ("Bad expression") {
    std::list<string> results;
    qps.evaluate("assign a; Select a pattern a(_, \"2+\")", results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid synonym declaration") {
    std::list<string> results;
    qps.evaluate("assign a_1; variable v; Select v", results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid multiple synonyms declaration") {
    std::list<string> results;
    qps.evaluate("assign a a1; variable v; Select v", results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("No semicolon after declaration") {
    std::list<string> results;
    qps.evaluate("assign a_1; variable v Select v", results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid integers (leading zero)") {
    std::list<string> results;
    qps.evaluate("stmt s, s1; variable v; Select v such that Follows (01,02)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid right argument (no expression inside)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (Contains negative integer)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"-1 + x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (Leading zeroes in integer)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"001 + x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (Far left operator)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"- 1 + x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (Unclosed left brac)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"( 1 + x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (Unclosed right brac)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\" 1 + x) \"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (No multiplication symbol on left)") {
    std::list<string> results;
    qps.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"8 / 2(2+2)\"_)",
        results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (No multiplication symbol on right)") {
    std::list<string> results;
    qps.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"8 / (2+2)2\"_)",
        results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (numvar)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"2x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (num var)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"2 x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (num num)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"2 2\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (var var)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"x 2\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (var num)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"y x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (=)") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"y = x\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression (')") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"'y'\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Invalid expression ('')") {
    std::list<string> results;
    qps.evaluate("assign a; variable v; Select v pattern a (v, _\"''y''\"_)",
                 results);
    REQUIRE(results == syntaxErr);
  }
  SECTION ("Non-stmt type found in Follows") {
    std::list<string> results;
    qps.evaluate(
        "stmt s; read r; print pn; call c; while w; if i; assign a; variable "
        "v; constant k; procedure p; Select v such that Follows (a, k)",
        results);
    REQUIRE(results == semanticErr);
  }
  SECTION ("Non-stmt type found in Parent") {
    std::list<string> results;
    qps.evaluate(
        "stmt s; read r; print pn; call c; while w; if i; assign a; variable "
        "v; constant k; procedure p; Select v such that Parent*(k, a)",
        results);
    REQUIRE(results == semanticErr);
  }
  SECTION ("read type on lhs in Uses") {
    std::list<string> results;
    qps.evaluate(
        "stmt s; read r; print pn; call c; while w; if i; assign a; variable "
        "v; constant k; procedure p; Select v such that Uses (r, v)",
        results);
    REQUIRE(results.empty());
  }
  SECTION ("print type on lhs in Modifies") {
    std::list<string> results;
    qps.evaluate(
        "stmt s; read r; print pn; call c; while w; if i; assign a; variable "
        "v; constant k; procedure p; Select v such that Modifies (pn, v)",
        results);
    REQUIRE(results.empty());
  }
  SECTION ("Invalid design-entity, select 2 design-entity") {
    std::list<string> results;
    qps.evaluate("stmt s1, s2; Select <s1, a1>", results);
    REQUIRE(results == semanticErr);
  }
}

TEST_CASE ("Query Processor Simple Test") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  QueryProcessor qps(pkbQuery);
  pkbInsert.insertEntity(Entity(EntityType::ASSIGN_STMT, "1"));
  pkbInsert.insertEntity(Entity(EntityType::ASSIGN_STMT, "2"));
  pkbInsert.insertEntity(Entity(EntityType::ASSIGN_STMT, "3"));
  std::list<string> results;
  std::list<string> expected = {"1", "2", "3"};
  qps.evaluate("assign a; Select a", results);
  REQUIRE(results == expected);
}

TEST_CASE ("QueryProcessor: Check Simple Follows") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertFollows(stmt1, stmt2);
  pkbInsert.insertFollows(stmt2, stmt3);
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::FOLLOWS));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS_T));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::FOLLOWS_T));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt3, RelationType::FOLLOWS_T));
  Query query1, query2;
  Declaration declaration1{EntityType::ASSIGN_STMT, "s"};
  SuchThatClause clause1(declaration1, stmt2, RelationType::FOLLOWS);
  SuchThatClause clause2(declaration1, stmt3, RelationType::FOLLOWS_T);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration1).selectDecl(declaration1.label);
  query2.addClause(std::make_shared<SuchThatClause>(clause2));
  query2.addDeclaration(declaration1).selectDecl(declaration1.label);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1 = {"1"};
  std::list<string> expected2 = {"1", "2"};
  qps.evaluate("assign s; Select s such that Follows(s, 2)", results1);
  qps.evaluate("assign s; Select s such that Follows*(s, 3)", results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Simple Uses") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::PRINT_STMT, "3"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  pkbInsert.insertEntity(var);
  pkbInsert.insertEntity(proc);
  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
    pkbInsert.insertUses(stmt, var);
    REQUIRE(pkbQuery.hasRelation(stmt, var, RelationType::USES));
  }
  pkbInsert.insertUses(proc, var);
  REQUIRE(pkbQuery.hasRelation(proc, var, RelationType::USES));

  QueryProcessor qps(pkbQuery);
  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1;
  for (const auto& stmt : stmts) {
    expected1.push_back({stmt.label});
  }
  qps.evaluate("stmt s; variable v; Select s such that Uses(s, v)", results1);
  REQUIRE(results1 == expected1);

  std::list<string> expected2 = {"p"};
  qps.evaluate("procedure p; variable v; Select p such that Uses(p, v)",
               results2);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Simple Modifies") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);

  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::READ_STMT, "2"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  pkbInsert.insertEntity(var);
  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
    pkbInsert.insertModifies(stmt, var);
    REQUIRE(pkbQuery.hasRelation(stmt, var, RelationType::MODIFIES));
  }
  pkbInsert.insertEntity(proc);
  pkbInsert.insertModifies(proc, var);
  REQUIRE(pkbQuery.hasRelation(proc, var, RelationType::MODIFIES));

  QueryProcessor qps(pkbQuery);
  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1;
  for (const auto& stmt : stmts) {
    expected1.push_back({stmt.label});
  }
  std::list<string> expected2 = {"p"};
  qps.evaluate("stmt s; variable v; Select s such that Modifies(s, v)",
               results1);
  qps.evaluate("procedure p; variable v; Select p such that Modifies(p, v)",
               results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Simple Parent and Parent*") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);

  vector<Entity> stmts = {
      Entity(SPA::READ_STMT, "1"),   Entity(SPA::IF_STMT, "2"),
      Entity(SPA::CALL_STMT, "3"),   Entity(SPA::WHILE_STMT, "4"),
      Entity(SPA::ASSIGN_STMT, "5"), Entity(SPA::PRINT_STMT, "6"),
  };

  vector<std::pair<int, int>> pairs = {
      {1, 2},
      {1, 3},
      {1, 5},
      {3, 4},
  };

  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
  }

  for (const auto& p : pairs) {
    pkbInsert.insertParent(stmts[p.first], stmts[p.second]);
    REQUIRE(pkbQuery.hasRelation(stmts[p.first], stmts[p.second],
                                 RelationType::PARENT));
  }

  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[2], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[3], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[3], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[3], stmts[4], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[4], RelationType::PARENT_T));
  REQUIRE(pkbQuery.hasRelation(stmts[3], stmts[4], RelationType::PARENT_T));
  REQUIRE_FALSE(pkbQuery.hasRelation(stmts[3], stmts[5], RelationType::PARENT));
  REQUIRE_FALSE(
      pkbQuery.hasRelation(stmts[1], stmts[0], RelationType::PARENT_T));

  QueryProcessor qps(pkbQuery);
  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1 = {{stmts[1].label}};
  std::list<string> expected2 = {
      {stmts[2].label}, {stmts[3].label}, {stmts[4].label}, {stmts[5].label}};
  qps.evaluate("stmt s; Select s such that Parent(s, 4)", results1);
  qps.evaluate("stmt s; Select s such that Parent*(2, s)", results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Simple Calls") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity proc1(EntityType::PROC, "p1");
  Entity proc2(EntityType::PROC, "p2");
  Entity proc3(EntityType::PROC, "p3");
  pkbInsert.insertEntity(proc1);
  pkbInsert.insertEntity(proc2);
  pkbInsert.insertEntity(proc3);
  pkbInsert.insertCalls(proc1, proc2);
  pkbInsert.insertCalls(proc2, proc3);
  REQUIRE(pkbQuery.hasRelation(proc1, proc2, RelationType::CALLS));
  REQUIRE(pkbQuery.hasRelation(proc2, proc3, RelationType::CALLS));
  REQUIRE(pkbQuery.hasRelation(proc1, proc2, RelationType::CALLS_T));
  REQUIRE(pkbQuery.hasRelation(proc2, proc3, RelationType::CALLS_T));
  REQUIRE(pkbQuery.hasRelation(proc1, proc3, RelationType::CALLS_T));

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> results3;
  std::list<string> results4;
  std::list<string> expected1 = {"p1", "p2"};
  std::list<string> expected2 = {"p1"};
  std::list<string> expected3 = {"p1", "p2"};
  std::list<string> expected4 = {"p2", "p3"};
  qps.evaluate("procedure p; Select p such that Calls(p, _)", results1);
  qps.evaluate("procedure p; Select p such that Calls(p, \"p2\")", results2);
  qps.evaluate("procedure p; Select p such that Calls*(p, \"p3\")", results3);
  qps.evaluate("procedure p, q; Select q such that Calls(p, q)", results4);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
  REQUIRE(results3 == expected3);
  REQUIRE(results4 == expected4);
}

TEST_CASE ("QueryProcessor: Check Simple Next") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertNext(stmt1, stmt2);
  pkbInsert.insertNext(stmt2, stmt3);
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::NEXT));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::NEXT));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::NEXT_T));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::NEXT_T));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt3, RelationType::NEXT_T));

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1 = {"1"};
  std::list<string> expected2 = {"1", "2"};
  qps.evaluate("assign s; Select s such that Next(s, 2)", results1);
  qps.evaluate("assign s; Select s such that Next*(s, 3)", results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Wildcard") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> expected;
  for (int i = 1; i < 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    expected.push_back({eprev.label});
    pkbInsert.insertFollows(eprev, e);
  }
  qps.evaluate("assign a; Select a such that Follows(a, _)", results);
  REQUIRE(results == expected);
}

TEST_CASE ("QueryProcessor: Check Assign Pattern") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> expected;
  Entity e(EntityType::ASSIGN_STMT, "1");
  pkbInsert.insertEntity(e);
  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    pkbInsert.insertEntity({EntityType::VAR, std::string(1, x)});
  }
  Entity b(EntityType::VAR, "b");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbManager.getPatternStorageHandle().insertAssignPattern(e, b, expr);
  SECTION ("stmt a") {
    expected.push_back({"1"});
    qps.evaluate("assign a; Select a pattern a (\"b\", \"b + c / e\")",
                 results);
    REQUIRE(results == expected);
  }
  SECTION ("lhs var v") {
    expected.push_back({"b"});
    qps.evaluate("assign a; variable v; Select v pattern a (v, \"b + c / e\")",
                 results);
    REQUIRE(results == expected);
  }
  SECTION ("rhs var v") {
    expected.push_back({"b"});
    expected.push_back({"c"});
    expected.push_back({"e"});
    qps.evaluate(
        "assign a; variable v; Select v pattern a (_, \"b + c / e\") such that "
        "Uses(a, v)",
        results);
    REQUIRE(results == expected);
  }
}

TEST_CASE ("QueryProcessor: Simple With Clause") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  QueryProcessor qps(pkbQuery);
  Entity a1 = Entity(EntityType::ASSIGN_STMT, "1");
  a1.addAttribute(STMTNO, "1");
  pkbInsert.insertEntity(a1);
  Entity a2 = Entity(EntityType::ASSIGN_STMT, "2");
  a2.addAttribute(STMTNO, "2");
  pkbInsert.insertEntity(a2);
  Entity a3 = Entity(EntityType::ASSIGN_STMT, "3");
  a3.addAttribute(STMTNO, "3");
  pkbInsert.insertEntity(a3);
  Entity v1 = Entity(EntityType::VAR, "v1");
  v1.addAttribute(VARNAME, "v1");
  pkbInsert.insertEntity(v1);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected = {"1"};
  std::list<string> expected2 = {"TRUE"};
  qps.evaluate("assign a; Select a with a.stmt# = 1", results);
  qps.evaluate("variable v; Select BOOLEAN with v.varName = \"v1\"", results2);
  REQUIRE(results == expected);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Simple Not Clause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertFollows(stmt1, stmt2);
  pkbInsert.insertFollows(stmt2, stmt3);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1 = {"2", "3"};
  std::list<string> expected2 = {"3"};
  qps.evaluate("assign s; Select s such that not Follows(s, 2)", results1);
  qps.evaluate("assign s; Select s such that not Follows*(s, 3)", results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Multiple Selections") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertFollows(stmt1, stmt2);
  pkbInsert.insertFollows(stmt2, stmt3);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> expected1 = {"1 2", "2 3"};
  std::list<string> expected2 = {"1 2", "1 3", "2 3"};
  qps.evaluate("assign s1, s2; Select <s1, s2> such that Follows(s1, s2)",
               results1);
  qps.evaluate("assign s1, s2; Select <s1, s2> such that Follows*(s1, s2)",
               results2);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
}

TEST_CASE ("QueryProcessor: Check Container Pattern") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> expected;
  Entity e(EntityType::ASSIGN_STMT, "1");
  pkbInsert.insertEntity(e);
  Entity i(EntityType::IF_STMT, "2");
  pkbInsert.insertEntity(i);
  Entity w(EntityType::WHILE_STMT, "3");
  pkbInsert.insertEntity(w);
  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    pkbInsert.insertEntity({EntityType::VAR, std::string(1, x)});
  }
  Entity b(EntityType::VAR, "b");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbInsert.insertAssignPattern(e, b, expr);

  Entity pIf(SPA::VAR, "predIf");
  Entity pW(SPA::VAR, "predW");
  pkbInsert.insertContainerPattern(i, pIf);
  pkbInsert.insertContainerPattern(w, pW);

  SECTION ("if stmt") {
    expected.push_back({"2"});
    qps.evaluate("if a; Select a pattern a (\"predIf\", _, _)", results);
    REQUIRE(results == expected);
  }
  SECTION ("while stmt") {
    expected.push_back({"3"});
    qps.evaluate("while a; Select a pattern a (\"predW\", _)", results);
    REQUIRE(results == expected);
  }
}

TEST_CASE ("QueryProcessor: Check Affects") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  Entity stmt4(EntityType::ASSIGN_STMT, "4");
  Entity var1(EntityType::VAR, "v1");
  Entity var2(EntityType::VAR, "v2");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertEntity(stmt4);
  pkbInsert.insertEntity(var1);
  pkbInsert.insertEntity(var2);
  pkbInsert.insertNext(stmt1, stmt2);
  pkbInsert.insertNext(stmt2, stmt3);
  pkbInsert.insertNext(stmt3, stmt4);
  pkbInsert.insertModifies(stmt1, var1);
  pkbInsert.insertUses(stmt2, var1);
  pkbInsert.insertModifies(stmt2, var2);
  pkbInsert.insertModifies(stmt3, var2);
  pkbInsert.insertUses(stmt4, var1);
  pkbInsert.insertUses(stmt4, var2);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> results3;
  std::list<string> expected1 = {"1"};
  std::list<string> expected2 = {"1", "3"};
  std::list<string> expected3 = {"2", "4"};
  qps.evaluate("assign s; Select s such that Affects(s, 2)", results1);
  qps.evaluate("assign s; Select s such that Affects(s, 4)", results2);
  qps.evaluate("assign s; Select s such that Affects(1, s)", results3);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
  REQUIRE(results3 == expected3);
}

TEST_CASE ("QueryEvaluator: Many Such That Clause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected;
  // std::vector<QueryEvaluator::RecordRef> expected;
  for (int i = 1; i < 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    pkbInsert.insertFollows(eprev, e);
    if (i == 9) break;
    expected.push_back({eprev.label});
  }
  qps.evaluate(
      "assign a, b, c; Select a such that Follows(a, b) such that Follows(b, "
      "c)",
      results);
  REQUIRE(results == expected);
  qps.evaluate(
      "assign a, b, c; Select a such that Follows(a, b) and Follows(b, "
      "c)",
      results2);
  REQUIRE(results2 == expected);
}

TEST_CASE ("Query Processor: Many With Clause") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  QueryProcessor qps(pkbQuery);
  Entity a1 = Entity(EntityType::READ_STMT, "1");
  a1.addAttribute(STMTNO, "1");
  a1.addAttribute(VARNAME, "v1");
  pkbInsert.insertEntity(a1);
  Entity v1 = Entity(EntityType::VAR, "v1");
  v1.addAttribute(VARNAME, "v1");
  pkbInsert.insertEntity(v1);
  Entity a2 = Entity(EntityType::READ_STMT, "2");
  a2.addAttribute(STMTNO, "2");
  a2.addAttribute(VARNAME, "v2");
  pkbInsert.insertEntity(a2);
  Entity v2 = Entity(EntityType::VAR, "v2");
  v2.addAttribute(VARNAME, "v2");
  pkbInsert.insertEntity(v2);
  Entity a3 = Entity(EntityType::READ_STMT, "3");
  a3.addAttribute(STMTNO, "3");
  a3.addAttribute(VARNAME, "v3");
  pkbInsert.insertEntity(a3);
  Entity v3 = Entity(EntityType::VAR, "v3");
  v3.addAttribute(VARNAME, "v3");
  pkbInsert.insertEntity(v3);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> results3;
  std::list<string> results4;
  std::list<string> expected = {"1"};
  std::list<string> expected2 = {"TRUE"};
  std::list<string> expected3 = {"2"};
  std::list<string> expected4 = {};
  qps.evaluate("read a; Select a with a.stmt# = 1 with a.varName = \"v1\"",
               results);
  qps.evaluate("variable v; Select BOOLEAN with v.varName = \"v1\"", results2);
  qps.evaluate("read a; Select a with a.stmt# = 2 and a.varName = \"v2\"",
               results3);
  qps.evaluate("read a; Select a with a.stmt# = 1 with a.varName = \"v2\"",
               results4);
  REQUIRE(results == expected);
  REQUIRE(results2 == expected2);
  REQUIRE(results3 == expected3);
  REQUIRE(results4 == expected4);
}

TEST_CASE ("QueryProcessor: Many Not Clause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertFollows(stmt1, stmt2);
  pkbInsert.insertFollows(stmt2, stmt3);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> results2a;
  std::list<string> results3;
  std::list<string> expected1 = {"2", "3"};
  std::list<string> expected2 = {"1", "3"};
  std::list<string> expected3 = {"2"};
  qps.evaluate("assign s; Select s such that not Follows(s, 2)", results1);
  qps.evaluate(
      "assign s, s2; Select s such that not Follows*(s2, 3) such that not "
      "Follows(s, s2)",
      results2);
  qps.evaluate(
      "assign s, s2; Select s such that not Follows*(s2, 3) and not "
      "Follows(s, s2)",
      results2a);
  qps.evaluate(
      "assign s, s2; Select s such that not Follows*(s2, 3) and "
      "Follows(s, s2)",
      results3);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
  REQUIRE(results2a == expected2);
  REQUIRE(results3 == expected3);
}

TEST_CASE ("QueryProcessor: Many Pattern Clause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected;

  Entity e(EntityType::ASSIGN_STMT, "1");
  pkbInsert.insertEntity(e);
  Entity e2(EntityType::ASSIGN_STMT, "2");
  pkbInsert.insertEntity(e2);
  Entity e3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(e3);

  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    pkbInsert.insertEntity({EntityType::VAR, std::string(1, x)});
  }

  Entity b(EntityType::VAR, "b");
  Entity c(EntityType::VAR, "c");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  vector<RawToken> expr2 = {"c", "/", "e"};
  vector<RawToken> expr3 = {"b", "+", "c"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbInsert.insertModifies(e2, c);
  pkbInsert.insertUses(e2, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e2, {EntityType::VAR, "e"});
  pkbInsert.insertModifies(e3, b);
  pkbInsert.insertUses(e3, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e3, {EntityType::VAR, "c"});
  pkbInsert.insertFollows(e, e2);
  pkbInsert.insertFollows(e2, e3);
  pkbInsert.insertAssignPattern(e, b, expr);
  pkbInsert.insertAssignPattern(e2, c, expr2);
  pkbInsert.insertAssignPattern(e3, b, expr3);

  SECTION ("Sanity Check") {
    expected.push_back({"1"});
    expected.push_back({"2"});
    expected.push_back({"3"});
    qps.evaluate("assign a; Select a pattern a (_, _)", results);
    REQUIRE(results == expected);
  }
  SECTION ("assign b") {
    expected.push_back({"1"});
    expected.push_back({"3"});
    qps.evaluate("assign a; Select a pattern a (\"b\", _)", results);
    REQUIRE(results == expected);
  }
  SECTION ("partial") {
    expected.push_back({"1"});
    expected.push_back({"2"});
    qps.evaluate("assign a; Select a pattern a (_, _\"c / e\"_)", results);
    REQUIRE(results == expected);
  }
  SECTION ("lhs and rhs") {
    expected.push_back({"1"});
    qps.evaluate(
        "assign a; Select a pattern a (_, _\"c / e\"_) pattern a (\"b\", _)",
        results);
    REQUIRE(results == expected);
    qps.evaluate(
        "assign a; Select a pattern a (\"b\", _) and a (_, _\"c / e\"_) ",
        results2);
    REQUIRE(results2 == expected);
  }
  SECTION ("Negation Tests") {
    expected.push_back({"1"});
    qps.evaluate(
        "assign a; Select a pattern not a (_, \"b + c\") pattern not a (\"c\", "
        "_)",
        results);
    REQUIRE(results == expected);
    qps.evaluate(
        "assign a; Select a pattern not a (\"c\", _) and not a (_, \"b + c\") ",
        results2);
    REQUIRE(results2 == expected);
  }
}

TEST_CASE ("QueryProcessor: Multiclause - Such That/Pattern") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected;

  Entity e(EntityType::ASSIGN_STMT, "1");
  pkbInsert.insertEntity(e);
  Entity e2(EntityType::READ_STMT, "2");
  pkbInsert.insertEntity(e2);
  Entity e3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(e3);

  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    pkbInsert.insertEntity({EntityType::VAR, std::string(1, x)});
  }

  Entity b(EntityType::VAR, "b");
  Entity c(EntityType::VAR, "c");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  vector<RawToken> expr2 = {"b", "+", "c"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbInsert.insertModifies(e3, b);
  pkbInsert.insertUses(e3, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e3, {EntityType::VAR, "c"});
  pkbInsert.insertFollows(e, e2);
  pkbInsert.insertFollows(e2, e3);
  pkbInsert.insertAssignPattern(e, b, expr);
  pkbInsert.insertAssignPattern(e3, c, expr2);

  SECTION ("Sanity Check") {
    expected.push_back({"1"});
    expected.push_back({"3"});
    qps.evaluate("assign a; Select a pattern a (_, _)", results);
    REQUIRE(results == expected);
  }
  SECTION ("Follows(a, r)") {
    expected.push_back({"1"});
    qps.evaluate(
        "assign a; read r; Select a pattern a (_, _) such that Follows(a, r)",
        results);
    qps.evaluate(
        "assign a; stmt r; Select a such that Follows(a, r) pattern a (_, _)",
        results2);
    REQUIRE(results == expected);
    REQUIRE(results2 == expected);
  }
  SECTION ("Negation Tests") {
    expected.push_back({"3"});
    qps.evaluate(
        "assign a; read r; Select a pattern a (_, _) such that not Follows(a, "
        "r)",
        results);
    qps.evaluate(
        "assign a; read r; Select a such that not Follows(a, r) pattern a (_, "
        "_)",
        results2);
    REQUIRE(results == expected);
    REQUIRE(results2 == expected);
  }
  SECTION ("Multi Select Tests") {
    expected.push_back({"1 b"});
    qps.evaluate(
        "assign a; read r; variable v; Select <a, v> pattern a (v, _) such "
        "that Follows(a, r)",
        results);
    REQUIRE(results == expected);
  }
}

TEST_CASE ("QueryProcessor: Multiclause - With/Pattern") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected;
  std::list<string> expected2;

  Entity e(EntityType::ASSIGN_STMT, "1");
  e.addAttribute(STMTNO, "1");
  pkbInsert.insertEntity(e);
  Entity e2(EntityType::READ_STMT, "2");
  e2.addAttribute(STMTNO, "2");
  e2.addAttribute(VARNAME, "c");
  pkbInsert.insertEntity(e2);
  Entity e3(EntityType::ASSIGN_STMT, "3");
  e3.addAttribute(STMTNO, "3");
  pkbInsert.insertEntity(e3);

  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    Entity vTemp(EntityType::VAR, std::string(1, x));
    vTemp.addAttribute(VARNAME, std::string(1, x));
    pkbInsert.insertEntity(vTemp);
  }

  for (int i = 1; i <= 2; i++) {
    Entity cTemp(EntityType::CONST, std::to_string(i));
    cTemp.addAttribute(VALUE, std::to_string(i));
    pkbInsert.insertEntity(cTemp);
  }

  Entity b(EntityType::VAR, "b");
  Entity c(EntityType::VAR, "c");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  vector<RawToken> expr2 = {"b", "+", "1"};
  // Theoretically, these shouldn't matter, since we are not testing any
  // relationships in the following tests
  // pkbInsert.insertModifies(e, b);
  // pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  // pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  // pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  // pkbInsert.insertModifies(e2, c);
  // pkbInsert.insertModifies(e3, b);
  // pkbInsert.insertUses(e3, {EntityType::VAR, "b"});
  // pkbInsert.insertFollows(e, e2);
  // pkbInsert.insertFollows(e2, e3);
  pkbInsert.insertAssignPattern(e, b, expr);
  pkbInsert.insertAssignPattern(e3, c, expr2);

  SECTION ("stmt# against value") {
    expected.push_back({"1"});
    qps.evaluate(
        "assign a; constant c; Select a pattern a (_, _) with a.stmt# = "
        "c.value",
        results);
    REQUIRE(results == expected);
  }
  SECTION ("stmt# against value Negation") {
    expected.push_back({"3"});
    qps.evaluate(
        "assign a; constant c; Select a with not a.stmt# = 1 pattern a (_, _) ",
        results);
    REQUIRE(results == expected);

    expected2.push_back({"1"});
    expected2.push_back({"3"});
    qps.evaluate(
        "assign a; constant c; Select a with not a.stmt# = c.value pattern a "
        "(_, _) ",
        results2);
    REQUIRE(results2 == expected2);
  }
  SECTION ("pattern against varName") {
    expected.push_back({"3"});
    qps.evaluate(
        "assign a; read r; variable v; Select a pattern a (v, _) with "
        "v.varName = r.varName",
        results);
    REQUIRE(results == expected);
    expected2.push_back({"1"});
    qps.evaluate(
        "assign a; read r; variable v; Select a pattern a (v, _) with "
        "not v.varName = r.varName",
        results2);
    REQUIRE(results2 == expected2);
  }
  SECTION ("Multiple Select Tests") {
    expected.push_back({"1 1"});
    expected.push_back({"1 2"});
    qps.evaluate(
        "assign a; constant c, c1; Select <a, c1> pattern a (_, _) with "
        "a.stmt# = c.value",
        results);
    REQUIRE(results == expected);
    expected2.push_back({"1 c"});
    qps.evaluate(
        "assign a; read r; variable v, v1; Select <a, v1> pattern a (v, _) "
        "with not v.varName = r.varName and v1.varName = r.varName",
        results2);
    REQUIRE(results2 == expected2);
  }
}

TEST_CASE ("QueryProcessor: Multiclause - Such That/With") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  Entity a1 = Entity(EntityType::ASSIGN_STMT, "1");
  a1.addAttribute(STMTNO, "1");
  pkbInsert.insertEntity(a1);
  Entity a2 = Entity(EntityType::ASSIGN_STMT, "2");
  a2.addAttribute(STMTNO, "2");
  pkbInsert.insertEntity(a2);
  Entity a3 = Entity(EntityType::ASSIGN_STMT, "3");
  a3.addAttribute(STMTNO, "3");
  pkbInsert.insertEntity(a3);
  pkbInsert.insertFollows(a1, a2);
  pkbInsert.insertFollows(a2, a3);

  Entity b(EntityType::VAR, "b");
  Entity d(EntityType::VAR, "d");
  pkbInsert.insertEntity(b);
  pkbInsert.insertEntity(d);
  pkbInsert.insertModifies(a1, b);
  pkbInsert.insertModifies(a2, d);
  pkbInsert.insertModifies(a3, b);

  std::list<string> results1;
  std::list<string> results2;
  std::list<string> results3;
  std::list<string> results4;
  std::list<string> results5;
  std::list<string> expected1 = {"1"};
  std::list<string> expected2 = {"1", "2"};
  std::list<string> expected3 = {"3"};
  std::list<string> expected4 = {"2", "3"};
  std::list<string> expected5 = {"1 b", "2 d"};
  qps.evaluate(
      "assign s, s1; Select s such that Follows(s, s1) with s1.stmt# = 2",
      results1);
  qps.evaluate(
      "assign s, s1; Select s such that Follows*(s, s1) with s1.stmt# = 3",
      results2);
  qps.evaluate(
      "assign s, s1; Select s1 with s.stmt# = 2 such that Follows*(s, s1)",
      results3);
  qps.evaluate(
      "assign s, s1; Select s1 with not s.stmt# = 3 such that Follows(s, s1)",
      results4);
  qps.evaluate(
      "assign s, s1; variable v; Select <s, v> such that Follows*(s, s1) and "
      "Modifies(s, v) with s1.stmt# = 3",
      results5);
  REQUIRE(results1 == expected1);
  REQUIRE(results2 == expected2);
  REQUIRE(results3 == expected3);
  REQUIRE(results4 == expected4);
  REQUIRE(results5 == expected5);
}

TEST_CASE ("QueryProcessor: Multiclause - All") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  QueryProcessor qps(pkbQuery);
  std::list<string> results;
  std::list<string> results2;
  std::list<string> expected;
  std::list<string> expected2;

  Entity e(EntityType::ASSIGN_STMT, "1");
  e.addAttribute(STMTNO, "1");
  pkbInsert.insertEntity(e);
  Entity e2(EntityType::READ_STMT, "2");
  e2.addAttribute(STMTNO, "2");
  e2.addAttribute(VARNAME, "c");
  pkbInsert.insertEntity(e2);
  Entity e3(EntityType::ASSIGN_STMT, "3");
  e3.addAttribute(STMTNO, "3");
  pkbInsert.insertEntity(e3);

  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    Entity vTemp(EntityType::VAR, std::string(1, x));
    vTemp.addAttribute(VARNAME, std::string(1, x));
    pkbInsert.insertEntity(vTemp);
  }

  for (int i = 1; i <= 2; i++) {
    Entity cTemp(EntityType::CONST, std::to_string(i));
    cTemp.addAttribute(VALUE, std::to_string(i));
    pkbInsert.insertEntity(cTemp);
  }

  Entity b(EntityType::VAR, "b");
  Entity c(EntityType::VAR, "c");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  vector<RawToken> expr2 = {"b", "+", "1", "-", "d"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbInsert.insertModifies(e2, c);
  pkbInsert.insertModifies(e3, c);
  pkbInsert.insertUses(e3, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e3, {EntityType::VAR, "d"});
  pkbInsert.insertFollows(e, e2);
  pkbInsert.insertFollows(e2, e3);
  pkbInsert.insertAssignPattern(e, b, expr);
  pkbInsert.insertAssignPattern(e3, c, expr2);

  SECTION ("stmt# against value") {
    expected.push_back({"2"});
    qps.evaluate(
        "stmt s; assign a; constant c; Select s such that Follows(a, s) "
        "pattern a (_, _) with a.stmt# = "
        "c.value",
        results);
    REQUIRE(results == expected);

    expected.push_back({"3"});
    qps.evaluate(
        "stmt s; assign a; constant c; Select s with not a.stmt# = c.value "
        "pattern a "
        "(_, _) such that Follows*(a, s)",
        results2);
    REQUIRE(results2 == expected);
  }

  SECTION ("pattern against varName") {
    expected.push_back({"b"});
    expected.push_back({"d"});
    qps.evaluate(
        "assign a; read r; variable v, v1; Select v1 pattern a (v, _) such "
        "that Uses(a, v1) with "
        "v.varName = r.varName",
        results);
    REQUIRE(results == expected);
    expected2.push_back({"1 b"});
    expected2.push_back({"3 c"});
    qps.evaluate(
        "stmt s; assign a; read r; variable v, v1; Select <s, v1> such that "
        "not Follows(a, s) and Modifies(s, v1)  pattern a (v, _) with "
        "not v.varName = r.varName",
        results2);
    REQUIRE(results2 == expected2);
  }
}
