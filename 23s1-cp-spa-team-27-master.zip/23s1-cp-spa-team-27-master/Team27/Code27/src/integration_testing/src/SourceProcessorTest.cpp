#include <algorithm>
#include <filesystem>
#include <iostream>
#include <numeric>
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "SourceProcessor/SourceProcessor.h"
#include "TestUtils.h"
#include "catch.hpp"
using namespace SP;
using namespace TEST;

void matchEntityAttribute(
    const unordered_map<EntityAttrType, std::string>& expected,
    const Entity& entity) {
  REQUIRE(entity.attributes.size() == expected.size());
  for (const auto& [type, val] : expected) {
    REQUIRE(entity.hasAttribute(type));
    REQUIRE(entity.getAttribute(type) == val);
  }
}

TEST_CASE ("Source Processor: Sample_source.txt") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);
  sp.process(getTest("Sample_source.txt"));
  std::vector<std::string> stmtstr(24);
  for (int i = 0; i < stmtstr.size(); i++) {
    stmtstr[i] = std::to_string(i + 1);
  }
}

TEST_CASE ("Integration Testing With Complete SP and PKB") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);

  sp.process(getTest("SP-PKB_source.txt"));

  auto eStmt1 = pkbQuery.getEntityTypeOfLabel("1");
  auto eVarA = pkbQuery.getEntityTypeOfLabel("varA");
  auto eStmtConst = pkbQuery.getEntityTypeOfLabel("7");
  auto eBozo = pkbQuery.getEntityTypeOfLabel("Bozo");

  SECTION ("Entity Tests") {
    REQUIRE(eStmt1 == unordered_set<EntityType>({IF_STMT}));
    REQUIRE(eVarA == unordered_set<EntityType>({VAR}));
    REQUIRE(eStmtConst == unordered_set<EntityType>({PRINT_STMT, CONST}));
    REQUIRE(eBozo == unordered_set<EntityType>({}));

    // Attribute Tests
    auto readEntities = pkbQuery.getEntities(SPA::READ_STMT);
    for (Entity en : readEntities) {
      matchEntityAttribute({{STMTNO, "3"}, {VARNAME, "varB"}}, en);
    }

    auto assignEntities = pkbQuery.getEntities(SPA::ASSIGN_STMT);
    for (Entity en : assignEntities) {
      matchEntityAttribute({{STMTNO, "6"}}, en);
    }
  }

  SECTION ("Relationship Tests") {
    REQUIRE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                 Entity(READ_STMT, "3"), FOLLOWS));
    REQUIRE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                 Entity(CALL_STMT, "4"), FOLLOWS_T));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(READ_STMT, "3"),
                                 PARENT));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(ASSIGN_STMT, "6"),
                                 PARENT_T));
    REQUIRE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"), Entity(VAR, "varA"),
                                 USES));
    REQUIRE(pkbQuery.hasRelation(Entity(READ_STMT, "3"), Entity(VAR, "varB"),
                                 MODIFIES));
    REQUIRE(
        pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(VAR, "varD"), USES));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(VAR, "varC"),
                                 MODIFIES));
    REQUIRE(
        pkbQuery.hasRelation(Entity(PROC, "test"), Entity(VAR, "varA"), USES));
    REQUIRE(pkbQuery.hasRelation(Entity(PROC, "test"), Entity(VAR, "varB"),
                                 MODIFIES));
    REQUIRE(
        pkbQuery.hasRelation(Entity(PROC, "test"), Entity(VAR, "varE"), USES));

    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                       Entity(CALL_STMT, "4"), FOLLOWS));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(IF_STMT, "1"),
                                       Entity(ASSIGN_STMT, "6"), PARENT));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PROC, "test"),
                                       Entity(VAR, "varA"), MODIFIES));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(Entity(PROC, "test"), Entity(VAR, "varB"), USES));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(READ_STMT, "3"),
                                       Entity(PRINT_STMT, "2"), FOLLOWS));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                       Entity(IF_STMT, "1"), PARENT));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(Entity(PROC, "proc2"), Entity(VAR, "varA"), USES));

    REQUIRE(pkbQuery.hasRelation(Entity(PROC, "test"), Entity(PROC, "proc2"),
                                 CALLS));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PROC, "proc2"),
                                       Entity(PROC, "test"), CALLS));
    REQUIRE(pkbQuery.hasRelation(Entity(PROC, "test"), Entity(PROC, "proc2"),
                                 CALLS_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PROC, "proc2"),
                                       Entity(PROC, "test"), CALLS_T));
    REQUIRE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                 Entity(READ_STMT, "3"), NEXT));
    REQUIRE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                 Entity(CALL_STMT, "4"), NEXT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                       Entity(CALL_STMT, "4"), NEXT));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(PRINT_STMT, "2"),
                                 NEXT));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(READ_STMT, "3"),
                                 NEXT_T));
    REQUIRE(pkbQuery.hasRelation(Entity(IF_STMT, "1"), Entity(WHILE_STMT, "5"),
                                 NEXT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(PRINT_STMT, "2"),
                                       Entity(WHILE_STMT, "5"), NEXT_T));
    REQUIRE(pkbQuery.hasRelation(Entity(WHILE_STMT, "5"),
                                 Entity(WHILE_STMT, "5"), NEXT_T));
  }

  SECTION ("Pattern Tests") {
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(Entity(CALL_STMT, "4"),
                                             Entity(WILDCARD), {}, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "0"),
                                            Entity(WILDCARD), {}, true));
    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(WILDCARD), {}, true));
    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(VAR, "varC"), {}, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                            Entity(VAR, "varD"), {}, true));

    auto tokens1 = SPA::split("varD + 10 - 7");
    auto tokens2 = SPA::split("10 - 7");
    auto tokens3 = SPA::split("7 - 10");
    auto tokens4 = SPA::split("varD + 10");

    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(WILDCARD), tokens1, false));
    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(WILDCARD), tokens1, true));
    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(WILDCARD), tokens4, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                            Entity(WILDCARD), tokens2, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                            Entity(WILDCARD), tokens3, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                            Entity(WILDCARD), tokens2, false));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                            Entity(WILDCARD), tokens4, false));
    REQUIRE(pkbQuery.hasAssignPattern(Entity(ASSIGN_STMT, "6"),
                                      Entity(VAR, "varC"), tokens1, false));

    REQUIRE(pkbQuery.hasContainerPattern(Entity(IF_STMT, "1"),
                                         Entity(VAR, "varIf")));
    REQUIRE(pkbQuery.hasContainerPattern(Entity(WHILE_STMT, "5"),
                                         Entity(VAR, "varW")));
  }
}