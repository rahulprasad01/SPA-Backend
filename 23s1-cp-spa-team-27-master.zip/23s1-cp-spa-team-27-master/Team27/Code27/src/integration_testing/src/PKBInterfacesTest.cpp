#include <vector>
#include "Common/Algorithms.h"
#include "Common/Format.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "catch.hpp"

using std::pair;
using std::vector;
using namespace SPA;
using namespace PKB;

TEST_CASE ("Integration Testing between PKBInsert and PKBQuery") {
  PKBManager pkb;
  PKBInsert pkbInsert(pkb);
  PKBQuery pkbQuery(pkb);

  Entity proc = Entity(SPA::PROC, "proc");
  // Const inserted first for easier indexing of statements in following tests
  // Stmt 1 is stmts[1]
  vector<Entity> stmts = {
      Entity(SPA::CONST, "5"),       Entity(SPA::READ_STMT, "1"),
      Entity(SPA::ASSIGN_STMT, "2"), Entity(SPA::WHILE_STMT, "3"),
      Entity(SPA::IF_STMT, "4"),     Entity(SPA::CALL_STMT, "5"),
      Entity(SPA::ASSIGN_STMT, "6"), Entity(SPA::PRINT_STMT, "7"),
      Entity(SPA::ASSIGN_STMT, "8"), Entity(SPA::PRINT_STMT, "9"),
  };
  vector<pair<int, int>> parentPairs = {
      {3, 4}, {3, 8}, {4, 5}, {4, 6}, {4, 7},
  };
  vector<pair<int, int>> followsPairs = {
      {1, 2}, {2, 3}, {3, 9}, {4, 8}, {6, 7},
  };
  vector<pair<int, int>> nextPairs = {
      {1, 2}, {2, 3}, {3, 4}, {3, 9}, {4, 5},
      {4, 6}, {5, 8}, {6, 7}, {7, 8}, {8, 3},
  };
  vector<Entity> callsProcs = {
      Entity(SPA::PROC, "Zero"), Entity(SPA::PROC, "A"), Entity(SPA::PROC, "B"),
      Entity(SPA::PROC, "C"),    Entity(SPA::PROC, "D"), Entity(SPA::PROC, "E"),
  };
  vector<pair<int, int>> callsPairs = {
      {0, 3}, {0, 4}, {0, 5}, {1, 3}, {2, 1}, {2, 4}, {3, 5},
  };
  vector<pair<Entity, Entity>> usesVars = {
      {Entity(SPA::ASSIGN_STMT, "2"), Entity(SPA::VAR, "uses2")},
      {Entity(SPA::ASSIGN_STMT, "6"), Entity(SPA::VAR, "uses68")},
      {Entity(SPA::ASSIGN_STMT, "8"), Entity(SPA::VAR, "uses68")},
  };
  vector<pair<Entity, Entity>> modifiesVars = {
      {Entity(SPA::ASSIGN_STMT, "2"), Entity(SPA::VAR, "modifies28")},
      {Entity(SPA::ASSIGN_STMT, "8"), Entity(SPA::VAR, "modifies28")},
      {Entity(SPA::ASSIGN_STMT, "6"), Entity(SPA::VAR, "modifies6")},
  };
  Entity tokenLHS = Entity(SPA::VAR, "v");
  vector<RawToken> tokens2 = SPA::split("v + x * y + z * t ");
  vector<RawToken> tokens6 = SPA::split("x * y + z * t ");
  vector<Entity> tokenVars = {
      Entity(SPA::VAR, "v"), Entity(SPA::VAR, "x"), Entity(SPA::VAR, "y"),
      Entity(SPA::VAR, "z"), Entity(SPA::VAR, "t"),
  };
  vector<Entity> ifVars = {
      Entity(SPA::VAR, "if1"), Entity(SPA::VAR, "if2"),
      Entity(SPA::VAR, "if3"), Entity(SPA::VAR, "ifwhile0"),
      Entity(SPA::VAR, "if1"),
  };
  vector<Entity> whileVars = {
      Entity(SPA::VAR, "ifwhile0"),
      Entity(SPA::VAR, "while4"),
      Entity(SPA::VAR, "while5"),
  };
  unordered_set<EntityRef> varRefs = {
      "uses2", "uses68", "modifies28", "modifies6", "if1",
      "if2",   "if3",    "ifwhile0",   "while4",    "while5",
      "v",     "x",      "y",          "z",         "t",
  };

  // SECTION: PKBInsert
  REQUIRE(pkbInsert.insertEntity(proc));
  for (const auto& p : callsProcs) {
    REQUIRE(pkbInsert.insertEntity(p));
  }
  for (const auto& s : stmts) {
    REQUIRE(pkbInsert.insertEntity(s));
  }
  for (const auto& v : varRefs) {
    REQUIRE(pkbInsert.insertEntity(Entity(SPA::VAR, v)));
  }
  for (const auto& p : parentPairs) {
    REQUIRE(pkbInsert.insertParent(stmts[p.first], stmts[p.second]));
  }
  for (const auto& f : followsPairs) {
    REQUIRE(pkbInsert.insertFollows(stmts[f.first], stmts[f.second]));
  }
  for (const auto& n : nextPairs) {
    REQUIRE(pkbInsert.insertNext(stmts[n.first], stmts[n.second]));
  }
  for (const auto& c : callsPairs) {
    REQUIRE(pkbInsert.insertCalls(callsProcs[c.first], callsProcs[c.second]));
  }
  for (const auto& u : usesVars) {
    REQUIRE(pkbInsert.insertUses(u.first, u.second));
    REQUIRE(pkbInsert.insertUses(proc, u.second));
  }
  for (const auto& m : modifiesVars) {
    REQUIRE(pkbInsert.insertModifies(m.first, m.second));
    REQUIRE(pkbInsert.insertModifies(proc, m.second));
  }
  for (const auto& t : tokenVars) {
    REQUIRE(pkbInsert.insertEntity(t));
  }
  REQUIRE(pkbInsert.insertAssignPattern(stmts[2], tokenLHS, tokens2));
  REQUIRE(pkbInsert.insertAssignPattern(stmts[6], tokenLHS, tokens6));
  for (const auto& i : ifVars) {
    REQUIRE(pkbInsert.insertEntity(i));
    REQUIRE(pkbInsert.insertContainerPattern(stmts[4], i));
  }
  for (const auto& w : whileVars) {
    REQUIRE(pkbInsert.insertEntity(w));
    REQUIRE(pkbInsert.insertContainerPattern(stmts[3], w));
  }
  for (const auto& s : stmts) {
    if (s.type == SPA::CONST) continue;
    REQUIRE(pkbInsert.insertProcStmt(proc, s));
  }

  SECTION ("New PKBQuery Entity Extraction") {
    auto resultVars = pkbQuery.getEntities(SPA::VAR);
    REQUIRE(resultVars.size() == 15);
    for (const auto& v : resultVars) {
      REQUIRE(varRefs.count(v.label));
    }
    auto resultStmts = pkbQuery.getEntities(SPA::STMT);
    REQUIRE(resultStmts.size() == 9);
    for (const auto& resultStmt : resultStmts) {
      REQUIRE(std::find(stmts.begin(), stmts.end(), resultStmt) != stmts.end());
    }
    auto resultAssigns = pkbQuery.getEntities(SPA::ASSIGN_STMT);
    REQUIRE(resultAssigns.size() == 3);
    for (const auto& resultAssign : resultAssigns) {
      REQUIRE(std::find(stmts.begin(), stmts.end(), resultAssign) !=
              stmts.end());
    }

    auto entityTypes = pkbQuery.getEntityTypeOfLabel("5");
    REQUIRE(entityTypes.size() == 2);
    vector<EntityType> entityTypesWithLabelFive = {EntityType::CONST,
                                                   EntityType::CALL_STMT};
    for (const auto& type : entityTypesWithLabelFive) {
      REQUIRE(entityTypes.find(type) != entityTypes.end());
    }
  }

  /*
  SECTION ("OLD PKBQuery Entity Extraction (To be deprecated)") {
    auto vars = pkbQuery.getEntitiesOfType(SPA::VAR);
    REQUIRE(vars.size() == 15);
    for (const auto& ref : varRefs) {
      REQUIRE(vars.find(ref) != vars.end());
    }

    auto stmts = pkbQuery.getEntitiesOfType(SPA::STMT);
    REQUIRE(stmts.size() == 9);
    for (int i = 1; i <= 9; i++) {
      REQUIRE(stmts.find(SPA::format("{}", i)) != stmts.end());
    }

    auto assignStmts = pkbQuery.getEntitiesOfType(SPA::ASSIGN_STMT);
    REQUIRE(assignStmts.size() == 3);
    vector<EntityRef> assignStmtRefs = {"2", "6", "8"};
    for (const auto& ref : assignStmtRefs) {
      REQUIRE(assignStmts.find(ref) != assignStmts.end());
    }

    auto entityTypes = pkbQuery.getEntityTypeOfLabel("5");
    REQUIRE(entityTypes.size() == 2);
    vector<EntityType> entityTypesWithLabelFive = {EntityType::CONST,
                                                   EntityType::CALL_STMT};
    for (const auto& type : entityTypesWithLabelFive) {
      REQUIRE(entityTypes.find(type) != entityTypes.end());
    }
  }
  */

  SECTION ("PKBQuery Parent & Parent*") {
    for (const auto& p : parentPairs) {
      REQUIRE(pkbQuery.hasRelation(stmts[p.first], stmts[p.second],
                                   RelationType::PARENT));
      REQUIRE(pkbQuery.hasRelation(stmts[p.first], stmts[p.second],
                                   RelationType::PARENT_T));
      REQUIRE_FALSE(pkbQuery.hasRelation(stmts[p.second], stmts[p.first],
                                         RelationType::PARENT));
      REQUIRE_FALSE(pkbQuery.hasRelation(stmts[p.second], stmts[p.first],
                                         RelationType::PARENT_T));
    }
    REQUIRE(pkbQuery.hasRelation(stmts[3], stmts[7], RelationType::PARENT_T));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[3], stmts[7], RelationType::PARENT));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[1], stmts[2], RelationType::PARENT));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[1], stmts[2], RelationType::PARENT_T));

    REQUIRE(pkbQuery.hasRelation(stmts[3], SPA::WILDCARD, SPA::PARENT));
    REQUIRE(pkbQuery.hasRelation(stmts[3], SPA::WILDCARD, SPA::PARENT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[7], SPA::WILDCARD, SPA::PARENT));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[7], SPA::WILDCARD, SPA::PARENT_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[4], SPA::PARENT));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[4], SPA::PARENT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[9], SPA::PARENT));
    REQUIRE_FALSE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[9], SPA::PARENT_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::PARENT));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::PARENT_T));
  }

  SECTION ("PKBQuery Follows & Follows*") {
    for (const auto& f : followsPairs) {
      REQUIRE(pkbQuery.hasRelation(stmts[f.first], stmts[f.second],
                                   RelationType::FOLLOWS));
      REQUIRE(pkbQuery.hasRelation(stmts[f.first], stmts[f.second],
                                   RelationType::FOLLOWS_T));
      REQUIRE_FALSE(pkbQuery.hasRelation(stmts[f.second], stmts[f.first],
                                         RelationType::FOLLOWS));
      REQUIRE_FALSE(pkbQuery.hasRelation(stmts[f.second], stmts[f.first],
                                         RelationType::FOLLOWS_T));
    }
    REQUIRE(pkbQuery.hasRelation(stmts[2], stmts[9], RelationType::FOLLOWS_T));
    REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[9], RelationType::FOLLOWS_T));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[2], stmts[9], RelationType::FOLLOWS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[5], stmts[6], RelationType::FOLLOWS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[5], stmts[6], RelationType::FOLLOWS_T));

    REQUIRE(pkbQuery.hasRelation(stmts[1], SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE(pkbQuery.hasRelation(stmts[1], SPA::WILDCARD, SPA::FOLLOWS_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[7], SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[7], SPA::WILDCARD, SPA::FOLLOWS_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[8], SPA::FOLLOWS));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[8], SPA::FOLLOWS_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[5], SPA::FOLLOWS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(SPA::WILDCARD, stmts[5], SPA::FOLLOWS_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::FOLLOWS_T));
  }

  SECTION ("PKBQuery Uses") {
    for (const auto& u : usesVars) {
      REQUIRE(pkbQuery.hasRelation(u.first, u.second, RelationType::USES));
      REQUIRE(pkbQuery.hasRelation(proc, u.second, RelationType::USES));
    }
    REQUIRE_FALSE(pkbQuery.hasRelation(usesVars[0].first, usesVars[1].second,
                                       RelationType::USES));
    REQUIRE_FALSE(pkbQuery.hasRelation(usesVars[1].first, usesVars[0].second,
                                       RelationType::USES));
    REQUIRE_THROWS(pkbQuery.hasRelation(usesVars[1].first, usesVars[2].first,
                                        RelationType::USES));
    REQUIRE_THROWS(pkbQuery.hasRelation(usesVars[0].second, usesVars[1].second,
                                        RelationType::USES));
    REQUIRE_THROWS(pkbQuery.hasRelation(usesVars[0].second, usesVars[0].first,
                                        RelationType::USES));
    REQUIRE_FALSE(pkbQuery.hasRelation(proc, Entity(EntityType::VAR, "notUsed"),
                                       RelationType::USES));

    REQUIRE(pkbQuery.hasRelation(proc, SPA::WILDCARD, SPA::USES));
    REQUIRE(pkbQuery.hasRelation(usesVars[2].first, SPA::WILDCARD, SPA::USES));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(SPA::PROC, "otherProc"),
                                       SPA::WILDCARD, SPA::USES));
    REQUIRE_THROWS(
        pkbQuery.hasRelation(usesVars[2].second, SPA::WILDCARD, SPA::USES));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[1], SPA::WILDCARD, SPA::USES));

    REQUIRE_THROWS(
        pkbQuery.hasRelation(SPA::WILDCARD, usesVars[1].second, SPA::USES));
    REQUIRE_THROWS(
        pkbQuery.hasRelation(SPA::WILDCARD, usesVars[1].first, SPA::USES));
    REQUIRE_THROWS(pkbQuery.hasRelation(
        SPA::WILDCARD, Entity(SPA::VAR, "notUsed"), SPA::USES));

    REQUIRE_THROWS(
        pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::USES));
  }

  SECTION ("PKBQuery Modifies") {
    for (const auto& m : modifiesVars) {
      REQUIRE(pkbQuery.hasRelation(m.first, m.second, RelationType::MODIFIES));
      REQUIRE(pkbQuery.hasRelation(proc, m.second, RelationType::MODIFIES));
    }
    REQUIRE_FALSE(pkbQuery.hasRelation(
        modifiesVars[0].first, modifiesVars[2].second, RelationType::MODIFIES));
    REQUIRE_FALSE(pkbQuery.hasRelation(
        modifiesVars[2].first, modifiesVars[0].second, RelationType::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(
        modifiesVars[1].first, modifiesVars[2].first, RelationType::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(modifiesVars[0].second,
                                        modifiesVars[1].second,
                                        RelationType::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(
        modifiesVars[0].second, modifiesVars[0].first, RelationType::MODIFIES));
    REQUIRE_FALSE(pkbQuery.hasRelation(
        proc, Entity(EntityType::VAR, "notModified"), RelationType::MODIFIES));

    REQUIRE(pkbQuery.hasRelation(proc, SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE(pkbQuery.hasRelation(modifiesVars[0].first, SPA::WILDCARD,
                                 SPA::MODIFIES));
    REQUIRE_FALSE(pkbQuery.hasRelation(Entity(SPA::PROC, "otherProc"),
                                       SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(modifiesVars[0].second, SPA::WILDCARD,
                                        SPA::MODIFIES));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[7], SPA::WILDCARD, SPA::MODIFIES));

    REQUIRE_THROWS(pkbQuery.hasRelation(SPA::WILDCARD, modifiesVars[1].second,
                                        SPA::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(SPA::WILDCARD, modifiesVars[1].first,
                                        SPA::MODIFIES));
    REQUIRE_THROWS(pkbQuery.hasRelation(
        SPA::WILDCARD, Entity(SPA::VAR, "notUsed"), SPA::MODIFIES));

    REQUIRE_THROWS(
        pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::MODIFIES));
  }

  SECTION ("PKBQuery Calls & Calls*") {
    for (const auto& c : callsPairs) {
      REQUIRE(pkbQuery.hasRelation(callsProcs[c.first], callsProcs[c.second],
                                   RelationType::CALLS));
      REQUIRE(pkbQuery.hasRelation(callsProcs[c.first], callsProcs[c.second],
                                   RelationType::CALLS_T));
      REQUIRE_FALSE(pkbQuery.hasRelation(
          callsProcs[c.second], callsProcs[c.first], RelationType::CALLS));
      REQUIRE_FALSE(pkbQuery.hasRelation(
          callsProcs[c.second], callsProcs[c.first], RelationType::CALLS_T));
    }
    REQUIRE(pkbQuery.hasRelation(callsProcs[1], callsProcs[5],
                                 RelationType::CALLS_T));
    REQUIRE(pkbQuery.hasRelation(callsProcs[2], callsProcs[5],
                                 RelationType::CALLS_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(callsProcs[1], callsProcs[5],
                                       RelationType::CALLS));
    REQUIRE_FALSE(pkbQuery.hasRelation(callsProcs[1], callsProcs[4],
                                       RelationType::CALLS));
    REQUIRE_FALSE(pkbQuery.hasRelation(callsProcs[1], callsProcs[4],
                                       RelationType::CALLS_T));

    REQUIRE(pkbQuery.hasRelation(callsProcs[1], SPA::WILDCARD, SPA::CALLS));
    REQUIRE(pkbQuery.hasRelation(callsProcs[1], SPA::WILDCARD, SPA::CALLS_T));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(callsProcs[5], SPA::WILDCARD, SPA::CALLS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(callsProcs[5], SPA::WILDCARD, SPA::CALLS_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, callsProcs[3], SPA::CALLS));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, callsProcs[3], SPA::CALLS_T));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(SPA::WILDCARD, callsProcs[2], SPA::CALLS));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(SPA::WILDCARD, callsProcs[2], SPA::CALLS_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::CALLS));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::CALLS_T));
  }

  SECTION ("PKBQuery Next & Next*") {
    for (const auto& n : nextPairs) {
      REQUIRE(pkbQuery.hasRelation(stmts[n.first], stmts[n.second],
                                   RelationType::NEXT));
      REQUIRE(pkbQuery.hasRelation(stmts[n.first], stmts[n.second],
                                   RelationType::NEXT_T));
    }
    REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[9], RelationType::NEXT_T));
    REQUIRE(pkbQuery.hasRelation(stmts[4], stmts[3], RelationType::NEXT_T));
    REQUIRE(pkbQuery.hasRelation(stmts[5], stmts[7], RelationType::NEXT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[1], stmts[3], RelationType::NEXT));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[8], stmts[2], RelationType::NEXT));
    REQUIRE_FALSE(
        pkbQuery.hasRelation(stmts[8], stmts[2], RelationType::NEXT_T));

    REQUIRE(pkbQuery.hasRelation(stmts[4], SPA::WILDCARD, SPA::NEXT));
    REQUIRE(pkbQuery.hasRelation(stmts[4], SPA::WILDCARD, SPA::NEXT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[9], SPA::WILDCARD, SPA::NEXT));
    REQUIRE_FALSE(pkbQuery.hasRelation(stmts[9], SPA::WILDCARD, SPA::NEXT_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[5], SPA::NEXT));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[5], SPA::NEXT_T));
    REQUIRE_FALSE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[1], SPA::NEXT));
    REQUIRE_FALSE(pkbQuery.hasRelation(SPA::WILDCARD, stmts[1], SPA::NEXT_T));

    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::NEXT));
    REQUIRE(pkbQuery.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::NEXT_T));
  }

  SECTION ("PKBQuery Assign Pattern") {
    vector<vector<int>> subexprsIdx = {{2}, {4},       {6},
                                       {8}, {2, 3, 4}, {6, 7, 8}};
    for (const auto& idxs : subexprsIdx) {
      vector<RawToken> expr(idxs.size());
      std::transform(idxs.begin(), idxs.end(), expr.begin(),
                     [&](int i) { return tokens2[i]; });
      REQUIRE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS, expr, true));
      REQUIRE(pkbQuery.hasAssignPattern(stmts[6], tokenLHS, expr, true));
      REQUIRE_FALSE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS, expr, false));
      REQUIRE_FALSE(pkbQuery.hasAssignPattern(stmts[6], tokenLHS, expr, false));
    }
    Entity otherVar = Entity(SPA::VAR, "otherV");
    REQUIRE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS, tokens2, false));
    REQUIRE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS, tokens2, true));
    REQUIRE(pkbQuery.hasAssignPattern(stmts[2], SPA::WILDCARD, tokens2, true));
    REQUIRE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS, {}, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(stmts[2], otherVar, {}, true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS,
                                            SPA::split("v + x "), true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(stmts[2], tokenLHS,
                                            SPA::split("x * y + z "), true));
    REQUIRE_FALSE(pkbQuery.hasAssignPattern(
        stmts[2], tokenLHS, SPA::split("x * y + z * t "), true));

    REQUIRE_THROWS(pkbQuery.hasAssignPattern(stmts[0], tokenLHS, {}, true));
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(stmts[3], tokenLHS, {}, true));
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(proc, tokenLHS, {}, true));
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(stmts[2], stmts[0], {}, true));
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(stmts[2], proc, {}, true));
    REQUIRE_THROWS(pkbQuery.hasAssignPattern(stmts[2], stmts[6], {}, true));
  }

  SECTION ("PKBQuery Container Pattern") {
    for (const auto& i : ifVars) {
      REQUIRE(pkbQuery.hasContainerPattern(stmts[4], i));
    }
    for (const auto& w : whileVars) {
      REQUIRE(pkbQuery.hasContainerPattern(stmts[3], w));
    }
    REQUIRE_FALSE(pkbQuery.hasContainerPattern(stmts[4], whileVars[2]));
    REQUIRE_FALSE(pkbQuery.hasContainerPattern(stmts[3], ifVars[1]));

    REQUIRE_THROWS(pkbQuery.hasContainerPattern(stmts[2], ifVars[1]));
    REQUIRE_THROWS(pkbQuery.hasContainerPattern(stmts[0], ifVars[1]));
    REQUIRE_THROWS(pkbQuery.hasContainerPattern(proc, ifVars[1]));
    REQUIRE_THROWS(pkbQuery.hasContainerPattern(stmts[4], stmts[0]));
    REQUIRE_THROWS(pkbQuery.hasContainerPattern(stmts[3], stmts[2]));

    REQUIRE(pkbQuery.hasContainerPattern(SPA::WILDCARD, ifVars[0]));
    REQUIRE(pkbQuery.hasContainerPattern(SPA::WILDCARD, whileVars[2]));
    REQUIRE_FALSE(pkbQuery.hasContainerPattern(SPA::WILDCARD,
                                               Entity(SPA::VAR, "unusedVar")));

    REQUIRE(pkbQuery.hasContainerPattern(stmts[4], SPA::WILDCARD));
    REQUIRE(pkbQuery.hasContainerPattern(stmts[3], SPA::WILDCARD));
    REQUIRE_FALSE(pkbQuery.hasContainerPattern(Entity(SPA::WHILE_STMT, "1"),
                                               SPA::WILDCARD));
    REQUIRE_FALSE(
        pkbQuery.hasContainerPattern(Entity(SPA::IF_STMT, "3"), SPA::WILDCARD));
    REQUIRE_FALSE(
        pkbQuery.hasContainerPattern(Entity(SPA::IF_STMT, "2"), SPA::WILDCARD));

    REQUIRE(pkbQuery.hasContainerPattern(SPA::WILDCARD, SPA::WILDCARD));
  }

  SECTION ("PKBQuery Affects") {
    PKBManager pkba;
    PKBInsert pkbInsertAffects(pkba);
    PKBQuery pkbQueryAffects(pkba);
    Entity procP = Entity(SPA::PROC, "p");
    Entity procQ = Entity(SPA::PROC, "q");
    vector<Entity> stmts = {
        Entity(SPA::STMT, "0"),         Entity(SPA::ASSIGN_STMT, "1"),
        Entity(SPA::ASSIGN_STMT, "2"),  Entity(SPA::IF_STMT, "3"),
        Entity(SPA::ASSIGN_STMT, "4"),  Entity(SPA::CALL_STMT, "5"),
        Entity(SPA::ASSIGN_STMT, "6"),  Entity(SPA::ASSIGN_STMT, "7"),
        Entity(SPA::ASSIGN_STMT, "8"),  Entity(SPA::READ_STMT, "9"),
        Entity(SPA::ASSIGN_STMT, "10"), Entity(SPA::ASSIGN_STMT, "11"),
        Entity(SPA::WHILE_STMT, "12"),  Entity(SPA::IF_STMT, "13"),
        Entity(SPA::ASSIGN_STMT, "14"), Entity(SPA::ASSIGN_STMT, "15"),
        Entity(SPA::ASSIGN_STMT, "16"),
    };
    int numStmts = stmts.size() - 1;
    vector<int> procPstmts = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    vector<int> procQstmts = {11, 12, 13, 14, 15, 16};
    vector<std::pair<int, int>> nextPairs = {
        {1, 2},   {2, 3},   {3, 4},   {3, 7},   {4, 5},   {5, 6},
        {6, 8},   {7, 8},   {8, 9},   {9, 10},  {11, 12}, {12, 13},
        {12, 16}, {13, 14}, {13, 15}, {14, 12}, {15, 12},
    };
    vector<std::pair<Entity, vector<int>>> usedVars = {
        {Entity(SPA::VAR, "x"), {3, 5, 7, 8, 12, 13, 14, 16}},
        {Entity(SPA::VAR, "y"), {2, 3, 4, 5, 6, 8, 12, 13, 15, 16}},
        {Entity(SPA::VAR, "z"), {3, 5, 10, 11, 12, 16}},
        {Entity(SPA::VAR, "k"), {2, 3, 8}},
    };
    vector<std::pair<Entity, vector<int>>> modifiedVars = {
        {Entity(SPA::VAR, "x"), {2, 3, 5, 6, 11, 12, 13, 15}},
        {Entity(SPA::VAR, "y"), {3, 4, 5, 12, 13, 14}},
        {Entity(SPA::VAR, "z"), {8, 9}},
        {Entity(SPA::VAR, "k"), {1, 3, 5, 7, 16}},
    };
    for (const auto& s : stmts) {
      REQUIRE(pkbInsertAffects.insertEntity(s));
    }
    for (const auto& i : procPstmts) {
      REQUIRE(pkbInsertAffects.insertProcStmt(procP, stmts[i]));
    }
    for (const auto& i : procQstmts) {
      REQUIRE(pkbInsertAffects.insertProcStmt(procQ, stmts[i]));
    }
    for (const auto& p : nextPairs) {
      REQUIRE(pkbInsertAffects.insertNext(stmts[p.first], stmts[p.second]));
    }
    for (const auto& u : usedVars) {
      REQUIRE(pkbInsertAffects.insertEntity(u.first));
      for (const auto& i : u.second) {
        REQUIRE(pkbInsertAffects.insertUses(stmts[i], u.first));
      }
    }
    for (const auto& m : modifiedVars) {
      REQUIRE(pkbInsertAffects.insertEntity(m.first));
      for (const auto& i : m.second) {
        REQUIRE(pkbInsertAffects.insertModifies(stmts[i], m.first));
      }
    }
    vector<std::pair<int, int>> trueAffectsPairs = {
        {1, 2}, {2, 8}, {6, 8}, {11, 16}, {14, 16}, {14, 15}, {15, 14},
    };
    vector<std::pair<int, int>> falseAffectsPairs = {
        {1, 8}, {4, 6}, {6, 7}, {8, 10}, {16, 6}, {4, 16},
    };
    for (const auto& p : trueAffectsPairs) {
      REQUIRE(pkbQueryAffects.hasRelation(stmts[p.first], stmts[p.second],
                                          SPA::AFFECTS));
    }
    for (const auto& p : falseAffectsPairs) {
      REQUIRE_FALSE(pkbQueryAffects.hasRelation(stmts[p.first], stmts[p.second],
                                                SPA::AFFECTS));
    }
    unordered_set<int> trueAffectsLHS = {1, 2, 6, 7, 11, 14, 15};
    unordered_set<int> trueAffectsRHS = {2, 7, 8, 14, 15, 16};
    for (int i = 1; i <= numStmts; i++) {
      REQUIRE(
          trueAffectsLHS.count(i) ==
          pkbQueryAffects.hasRelation(stmts[i], SPA::WILDCARD, SPA::AFFECTS));
      REQUIRE(
          trueAffectsRHS.count(i) ==
          pkbQueryAffects.hasRelation(SPA::WILDCARD, stmts[i], SPA::AFFECTS));
    }
    REQUIRE(pkbQueryAffects.hasRelation(SPA::WILDCARD, SPA::WILDCARD,
                                        SPA::AFFECTS));
  }
}
