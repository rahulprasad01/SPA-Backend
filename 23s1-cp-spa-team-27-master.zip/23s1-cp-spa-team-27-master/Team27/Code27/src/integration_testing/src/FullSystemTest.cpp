#include <algorithm>
#include <filesystem>
#include <iostream>
#include <numeric>
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "QueryProcessingSubsystem/QueryProcessor.h"
#include "SourceProcessor/SourceProcessor.h"
#include "TestUtils.h"
#include "catch.hpp"
using namespace SP;
using namespace TEST;
using namespace QPS;

std::list<int> getStmtLabels(const std::list<std::string>& nums) {
  std::list<int> out(nums.size());
  std::transform(nums.begin(), nums.end(), out.begin(),
                 [](const std::string& t) { return std::stoi(t); });
  out.sort();
  return out;
}

TEST_CASE ("Full System Test: sprint1_demo_entities_source.txt") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);
  QueryProcessor qp(pkbQuery);
  std::list<string> results;
  sp.process(getTest("sprint1_demo_entities_source.txt"));
  SECTION ("1") {
    qp.evaluate("constant c; Select c", results);
    std::list<int> expected = {0, 5, 7};
    REQUIRE(getStmtLabels(results) == expected);
  }
}

TEST_CASE ("Full System Test: basicSPA_patterns_source.txt") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);
  QueryProcessor qp(pkbQuery);
  std::list<string> results;
  sp.process(getTest("basicSPA_patterns_source.txt"));
  SECTION ("1") {
    qp.evaluate("assign a; Select a pattern a (_, _\" 2 \"_)", results);
    std::list<int> expected = {1, 14};
    REQUIRE(getStmtLabels(results) == expected);
  }
  SECTION ("Partial const search") {
    qp.evaluate("assign a; variable v; Select a pattern a (v, _\"1\"_)",
                results);
    std::list<int> expected = {6, 8, 17, 20, 21, 23, 25, 27};
    REQUIRE(getStmtLabels(results) == expected);
  }
}

TEST_CASE ("Full System Test: basicSPA_suchthatpattern_source.txt") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);
  QueryProcessor qp(pkbQuery);
  std::list<string> results;
  sp.process(getTest("basicSPA_suchthatpattern_source.txt"));
  SECTION ("y*y") {
    qp.evaluate(
        "assign a; variable v; Select a such that Parent (29, a) pattern a "
        "(\"x\", \"y*y\")",
        results);
    std::list<int> expected = {48};
    REQUIRE(getStmtLabels(results) == expected);
  }
  SECTION ("timeout?") {
    qp.evaluate(
        "assign a; variable v; Select v pattern a (v, _\"y\"_) such that Uses "
        "(29, \"w\")",
        results);
    std::list<string> expected = {"x", "y", "z"};
    REQUIRE(results == expected);
  }
}

TEST_CASE ("Full System Test: sprint1_demo_uses_source.txt") {
  PKB::PKBManager pkb;
  PKB::PKBInsert pkbInsert(pkb);
  PKB::PKBQuery pkbQuery(pkb);
  SourceProcessor sp(pkbInsert);
  QueryProcessor qp(pkbQuery);
  std::list<string> results;
  sp.process(getTest("sprint1_demo_uses_source.txt"));
  SECTION ("1") {
    qp.evaluate("read rs; variable v1, v2; Select v1 such that Uses(rs, v2)",
                results);
    std::list<int> expected = {};
    REQUIRE(getStmtLabels(results) == expected);
  }
}
