#pragma once
#include <filesystem>
#include "catch.hpp"

// 6 levels of nesting:
// Team27\Code27\out\build\x64-Debug\src
#ifdef unix  // fix for unix
#define NESTING 4
#else
#define NESTING 6
#endif
namespace fs = std::filesystem;

namespace TEST {

inline std::string getTest(const std::string& filename) {
  fs::path dir = fs::current_path();
  // if TESTS_INPUT_FOLDER is defined and exists, that folder is used instead
  const char* env_folder = std::getenv("TESTS_INPUT_FOLDER");
  if (env_folder != nullptr && fs::exists(std::string(env_folder))) {
    std::cout << "Using test folder: " << env_folder << std::endl;
    dir = std::string(env_folder);
  } else {
    for (int i = 0; i < NESTING; ++i) {
      dir = dir.parent_path();
    }
    dir = dir.append("Tests27");
  }
  REQUIRE(fs::is_directory(dir));
  fs::path file = dir.append(filename);
  REQUIRE(fs::exists(file));
  return file.string();
}

template <typename T>
inline bool allInSet(const std::unordered_set<T>& actual,
                     const std::vector<T>& expected) {
  for (const auto& e : expected) {
    if (!actual.count(e)) return false;
  }
  return true;
}
}  // namespace TEST
