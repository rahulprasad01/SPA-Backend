#include <iostream>
#include "QueryProcessingSubsystem/QueryTokenizer.h"
#include "catch.hpp"

using namespace QPS;
using namespace SPA;

TEST_CASE ("QueryToken constructor") {
  QueryTokenType type = QueryTokenType::WORD;
  QueryToken token{type, "abd"};
  REQUIRE(token.value == "abd");
  REQUIRE(token.type == QueryTokenType::WORD);
}

void print_tokens(const vector<QueryToken>& tokens) {
  for (const auto& tok : tokens) {
    std::cerr << "'" << tok.value << "', ";
  }
  std::cerr << std::endl;
}

void check_tokens(const vector<QueryToken>& tokens,
                  const vector<std::string>& texts,
                  const vector<QueryTokenType>& types) {
  for (int i = 0; i < texts.size(); i++) {
    REQUIRE(tokens[i].type == types[i]);
    REQUIRE(tokens[i].value == texts[i]);
  }
}

TEST_CASE ("Valid PQL") {
  QueryTokenizer pqltokenizer;
  using Q = QueryTokenType;
  SECTION ("Declarations") {
    vector<QueryToken> tokens = pqltokenizer.tokenize(
        "stmt s; read r; print p; while w; if ifs; assign a; variable v; "
        "constant c; procedure proc;");
    vector<std::string> texts = {
        "stmt",     "s", ";", "read",     "r",   ";", "print",     "p",    ";",
        "while",    "w", ";", "if",       "ifs", ";", "assign",    "a",    ";",
        "variable", "v", ";", "constant", "c",   ";", "procedure", "proc", ";"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER,
    };
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns") {
    vector<QueryToken> tokens = pqltokenizer.tokenize("\" a % b - 23 \"");
    vector<std::string> texts = {"\"", "a", "%", "b", "-", "23", "\""};
    vector<QueryTokenType> types = {
        Q::DELIMITER, Q::WORD, Q::OP, Q::WORD, Q::OP, Q::NUMBER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns and partial patterns") {
    vector<QueryToken> tokens = pqltokenizer.tokenize("_\" a % b - 23 \"_");
    vector<std::string> texts = {"_\"", "a", "%", "b", "-", "23", "\"_"};
    vector<QueryTokenType> types = {
        Q::DELIMITER, Q::WORD, Q::OP, Q::WORD, Q::OP, Q::NUMBER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns clause") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("pattern a (_,_\" a % b - 23 \"_)");
    vector<std::string> texts = {"pattern", "a", "(", "_",  ",",   "_\"", "a",
                                 "%",       "b", "-", "23", "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::OP,        Q::WORD,      Q::OP,
        Q::NUMBER,    Q::DELIMITER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns clause") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("pattern a (_,_\" a % b - 23 \"_)");
    vector<std::string> texts = {"pattern", "a", "(", "_",  ",",   "_\"", "a",
                                 "%",       "b", "-", "23", "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::OP,        Q::WORD,      Q::OP,
        Q::NUMBER,    Q::DELIMITER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns y*y edge case") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("pattern a (_,_\" y*y - 23 \"_)");
    vector<std::string> texts = {"pattern", "a", "(", "_",  ",",   "_\"", "y",
                                 "*",       "y", "-", "23", "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::OP,        Q::WORD,      Q::OP,
        Q::NUMBER,    Q::DELIMITER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Patterns spaced out _ and \" edge case") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("pattern a (_,_    \" y*y - 23 \"  _)");
    vector<std::string> texts = {"pattern", "a", "(", "_",  ",",   "_\"", "y",
                                 "*",       "y", "-", "23", "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::OP,        Q::WORD,      Q::OP,
        Q::NUMBER,    Q::DELIMITER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Attr ref") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("v.varName = p3.procName");
    vector<std::string> texts = {"v",  ".", "varName", "=",
                                 "p3", ".", "procName"};
    vector<QueryTokenType> types = {Q::WORD, Q::DELIMITER, Q::WORD, Q::OP,
                                    Q::WORD, Q::DELIMITER, Q::WORD};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Attr ref") {
    vector<QueryToken> tokens = pqltokenizer.tokenize("v.stmt# = ifs.stmt#");
    vector<std::string> texts = {"v", ".", "stmt#", "=", "ifs", ".", "stmt#"};
    vector<QueryTokenType> types = {Q::WORD, Q::DELIMITER, Q::WORD, Q::OP,
                                    Q::WORD, Q::DELIMITER, Q::WORD};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Underscores") {
    vector<QueryToken> tokens = pqltokenizer.tokenize("(_,a)");
    vector<std::string> texts = {"(", "_", ",", "a", ")"};
    vector<QueryTokenType> types = {
        Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::WORD, Q::DELIMITER,
    };
    check_tokens(tokens, texts, types);
  }
  SECTION ("Select and Such That (Parent*) Clause") {
    vector<QueryToken> tokens =
        pqltokenizer.tokenize("Select a such that Parent* (w, a)");
    vector<std::string> texts = {"Select", "a", "such", "that", "Parent*",
                                 "(",      "w", ",",    "a",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::WORD,      Q::WORD, Q::WORD,
        Q::DELIMITER, Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Modifies Clause") {
    vector<QueryToken> tokens = pqltokenizer.tokenize("Modifies (a, \"x\")");
    vector<std::string> texts = {"Modifies", "(", "a",  ",",
                                 "\"",       "x", "\"", ")"};
    vector<QueryTokenType> types = {Q::WORD,      Q::DELIMITER, Q::WORD,
                                    Q::DELIMITER, Q::DELIMITER, Q::WORD,
                                    Q::DELIMITER, Q::DELIMITER};
    check_tokens(tokens, texts, types);
  }
}

TEST_CASE ("Invalid Query") {
  QueryTokenizer pqltokenizer;
  REQUIRE_THROWS(pqltokenizer.tokenize("001"));
  REQUIRE_THROWS(pqltokenizer.tokenize(":"));
  REQUIRE_THROWS(pqltokenizer.tokenize("|"));
  REQUIRE_THROWS(pqltokenizer.tokenize("&"));
}