#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "QueryProcessingSubsystem/Clause.h"
#include "QueryProcessingSubsystem/NotClause.h"
#include "QueryProcessingSubsystem/PatternClause.h"
#include "QueryProcessingSubsystem/SuchThatClause.h"
#include "QueryProcessingSubsystem/WithClause.h"
#include "catch.hpp"

using namespace QPS;
using namespace SPA;
using namespace PKB;

TEST_CASE ("NotClause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  Entity ent1 = Entity(ASSIGN_STMT, "1");
  Entity ent2 = Entity(ASSIGN_STMT, "2");
  pkbInsert.insertEntity(ent1);
  pkbInsert.insertEntity(ent2);
  pkbInsert.insertFollows(ent1, ent2);
  SECTION ("NotClause equality operator") {
    std::shared_ptr<SuchThatClause> stc1 = std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "6"), RelationType::FOLLOWS);
    std::shared_ptr<SuchThatClause> stc2 = std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "6"), RelationType::FOLLOWS);
    NotClause clause1(stc1);
    NotClause clause2(stc2);
    NotClause clause3(std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "6"), RelationType::FOLLOWS));
    NotClause clause4(std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "6"), RelationType::FOLLOWS));
    NotClause clause5(std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "5"), RelationType::FOLLOWS));
    REQUIRE(clause1 == clause2);
    REQUIRE(clause2 == clause3);
    REQUIRE(clause3 == clause4);
    REQUIRE_FALSE(clause4 == clause5);
    REQUIRE_FALSE(clause1 != clause2);
    REQUIRE_FALSE(clause2 != clause3);
    REQUIRE_FALSE(clause3 != clause4);
    REQUIRE(clause4 != clause5);
  }
  SECTION ("Simple SuchThatClause") {
    Candidate cand;
    cand.emplaceRef({EntityType::ASSIGN_STMT, "a"},
                    Entity(EntityType::ASSIGN_STMT, "1"));
    std::shared_ptr<SuchThatClause> stc1 = std::make_shared<SuchThatClause>(
        Declaration{EntityType::ASSIGN_STMT, "a"},
        Entity(EntityType::ASSIGN_STMT, "2"), RelationType::FOLLOWS);
    NotClause clause1(stc1);
    REQUIRE(stc1->test(cand, pkbQuery));
    REQUIRE(stc1->test(cand, pkbQuery) != clause1.test(cand, pkbQuery));
    std::shared_ptr<SuchThatClause> stc2 = std::make_shared<SuchThatClause>(
        Entity(EntityType::ASSIGN_STMT, "2"),
        Declaration{EntityType::ASSIGN_STMT, "a"}, RelationType::FOLLOWS);
    NotClause clause2(stc2);
    REQUIRE_FALSE(stc2->test(cand, pkbQuery));
    REQUIRE(stc2->test(cand, pkbQuery) != clause2.test(cand, pkbQuery));
  }
}

TEST_CASE ("SuchThat Clause equality operator") {
  SuchThatClause clause1(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "6"),
                         RelationType::FOLLOWS);
  SuchThatClause clause2(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "6"),
                         RelationType::FOLLOWS);
  REQUIRE(clause1 == clause2);
}

TEST_CASE ("WithClause") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  Entity ent1 = Entity(ASSIGN_STMT, "1");
  Entity ent2 = Entity(ASSIGN_STMT, "2");
  ent1.addAttribute(EntityAttrType::STMTNO, "1");
  ent2.addAttribute(EntityAttrType::STMTNO, "2");
  pkbInsert.insertEntity(ent1);
  pkbInsert.insertEntity(ent2);
  SECTION ("WithClause to_string method") {
    WithClause clause(std::make_pair(Declaration{EntityType::ASSIGN_STMT, "a"},
                                     EntityAttrType::PROCNAME),
                      std::string("Nothing"));
    REQUIRE(clause.to_string() == "with a.procName = \"Nothing\"");
  }
  SECTION ("Simple WithClause") {
    Candidate cand;
    cand.emplaceRef({EntityType::ASSIGN_STMT, "a"}, ent1);
    WithClause clause1(std::make_pair(Declaration{EntityType::ASSIGN_STMT, "a"},
                                      EntityAttrType::STMTNO),
                       std::string("1"));
    WithClause clause2(std::make_pair(Declaration{EntityType::ASSIGN_STMT, "a"},
                                      EntityAttrType::STMTNO),
                       std::string("2"));
    REQUIRE(clause1.test(cand, pkbQuery));
    REQUIRE_FALSE(clause2.test(cand, pkbQuery));
  }
}

TEST_CASE ("Pattern Clause equality operator") {
  PatternClause clause1(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "v"), {"x"}, false);
  PatternClause clause2(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "v"), {"x"}, false);
  PatternClause clause3(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "v"), {"y"}, false);
  PatternClause clause4(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "v"), {"_", "y", "_"}, true);
  PatternClause clause5(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "_"), {"y"}, false);
  PatternClause clause6(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "_"), {"_", "y", "_"}, true);
  // Wildcard test
  PatternClause clause7(Declaration{EntityType::ASSIGN_STMT, "a"},
                        Entity(EntityType::VAR, "v"), {"_"}, true);

  // Check equality with self and another clause with the same inputs
  REQUIRE(clause1 == clause1);
  REQUIRE(clause1 == clause2);

  // Check equality between exact pattern and exact pattern
  REQUIRE_FALSE(clause1 == clause3);

  // Check equality between exact pattern and partial pattern, different RHS
  // variable
  REQUIRE_FALSE(clause1 == clause4);

  // Check equality between exact pattern and partial pattern, same RHS variable
  REQUIRE_FALSE(clause3 == clause4);

  // Check equality between exact pattern and wildcard + exact pattern
  REQUIRE_FALSE(clause3 == clause5);

  // Check equality between exact pattern and wildcard + partial pattern
  REQUIRE_FALSE(clause3 == clause6);
}
