#include "QueryProcessingSubsystem/Query.h"
#include "QueryProcessingSubsystem/SuchThatClause.h"
#include "catch.hpp"

using namespace QPS;
using namespace SPA;

TEST_CASE ("Query equality operator") {
  SuchThatClause clause1(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "6"),
                         RelationType::FOLLOWS);
  SuchThatClause clause2(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "6"),
                         RelationType::FOLLOWS);
  SuchThatClause clause3(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "6"),
                         RelationType::FOLLOWS);
  SuchThatClause clause4(Declaration{EntityType::ASSIGN_STMT, "a"},
                         Entity(EntityType::ASSIGN_STMT, "7"),
                         RelationType::FOLLOWS);
  Query query1;
  query1.addDeclaration(Declaration{EntityType::ASSIGN_STMT, "a"});
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addClause(std::make_shared<SuchThatClause>(clause2));
  Query query2;
  query2.addDeclaration(Declaration{EntityType::ASSIGN_STMT, "a"});
  query2.addClause(std::make_shared<SuchThatClause>(clause3));
  query2.addClause(std::make_shared<SuchThatClause>(clause1));
  Query query3;
  query3.addClause(std::make_shared<SuchThatClause>(clause2));
  query3.addClause(std::make_shared<SuchThatClause>(clause4));
  REQUIRE(query1 == query2);
  REQUIRE(query1 != query3);
  REQUIRE(query3 != query2);
}
