#include <memory>
#include "QueryProcessingSubsystem/QueryParser.h"
#include "QueryProcessingSubsystem/QueryTokenizer.h"
#include "catch.hpp"

using namespace QPS;
using std::make_shared;
using std::string;
using Q = QueryTokenType;

shared_ptr<NotClause> makeNotCl(shared_ptr<Clause> cl) {
  return make_shared<NotClause>(cl);
}

vector<QueryToken> makeTokens(vector<std::string> texts,
                              vector<QueryTokenType> types) {
  vector<QueryToken> tokens;
  REQUIRE(texts.size() == types.size());
  for (size_t i = 0; i < texts.size(); i++) {
    tokens.push_back(QueryToken(types[i], texts[i]));
  }
  return tokens;
}

TEST_CASE ("QueryParser: Select") {
  QueryParser parser;
  SECTION ("Select BOOLEAN") {
    string test = "Select BOOLEAN";
    vector<std::string> texts = {"Select", "BOOLEAN"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected;
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("stmt BOOLEAN; Select BOOLEAN") {
    string test = "stmt BOOLEAN; Select BOOLEAN";
    vector<std::string> texts = {"stmt", "BOOLEAN", ";", "Select", "BOOLEAN"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD,
                                    Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::STMT, "BOOLEAN"))
            .selectDecl("BOOLEAN");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("stmt BOOLEAN; Select BOOLEAN") {
    string test = "stmt BOOLEAN, a; Select <BOOLEAN, a>";
    vector<std::string> texts = {"stmt", "BOOLEAN", ",", "a", ";", "Select",
                                 "<",    "BOOLEAN", ",", "a", ">"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER, Q::WORD,
        Q::DELIMITER, Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::STMT, "BOOLEAN"))
            .addDeclaration(Declaration(EntityType::STMT, "a"))
            .selectDecl("BOOLEAN")
            .selectDecl("a");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Invalid: Select <BOOLEAN>") {
    string test = "Select <BOOLEAN>";
    vector<std::string> texts = {"Select", "<", "BOOLEAN", ">"};
    vector<QueryTokenType> types = {Q::WORD, Q::DELIMITER, Q::WORD,
                                    Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Invalid: Select <a, BOOLEAN>") {
    string test = "assign a; Select <a, BOOLEAN>";
    vector<std::string> texts = {"assign", "a", ";",       "Select", "<",
                                 "a",      ",", "BOOLEAN", ">"};
    vector<QueryTokenType> types = {Q::WORD,      Q::WORD,      Q::DELIMITER,
                                    Q::WORD,      Q::DELIMITER, Q::WORD,
                                    Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Invalid: Select <a.stmt>") {
    string test = "assign a; Select <a.stmt>";
    vector<std::string> texts = {"assign", "a", ";",    "Select", "<",
                                 "a",      ".", "stmt", ">"};
    vector<QueryTokenType> types = {Q::WORD,      Q::WORD,      Q::DELIMITER,
                                    Q::WORD,      Q::DELIMITER, Q::WORD,
                                    Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Declare 1, Select 1") {
    string test = "assign a; Select a";
    vector<std::string> texts = {"assign", "a", ";", "Select", "a"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD,
                                    Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected =
        Query().addDeclaration(Declaration(ASSIGN_STMT, "a")).selectDecl("a");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare >1 of 1 type, Select 1") {
    string test = "assign a, a1; Select a1";
    vector<std::string> texts = {"assign", "a", ",", "a1", ";", "Select", "a1"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD,      Q::DELIMITER,
                                    Q::WORD, Q::DELIMITER, Q::WORD,
                                    Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "a1"))
                         .selectDecl("a1");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare >1 of >1 types, Select 1") {
    string test = "assign a, a1; while w; Select a1";
    vector<std::string> texts = {"assign", "a", ",", "a1",     ";",
                                 "while",  "w", ";", "Select", "a1"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "a1"))
                         .selectDecl("a1")
                         .addDeclaration(Declaration(WHILE_STMT, "w"));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare >1 of >1 types, Select >1") {
    string test = "assign a, a1; while w; Select <a1, w>";
    vector<std::string> texts = {"assign", "a", ",", "a1",     ";",
                                 "while",  "w", ";", "Select", "<",
                                 "a1",     ",", "w", ">"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "a1"))
                         .addDeclaration(Declaration(WHILE_STMT, "w"))
                         .selectDecl("a1")
                         .selectDecl("w");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare >1 of >1 types, Select >1 with entity attribute on one") {
    string test = "assign a, a1; while w; Select <a1.stmt#, w>";
    vector<std::string> texts = {"assign", "a", ",",      "a1", ";",  "while",
                                 "w",      ";", "Select", "<",  "a1", ".",
                                 "stmt#",  ",", "w",      ">"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::DELIMITER,
        Q::WORD,      Q::DELIMITER, Q::WORD,      Q::DELIMITER,
        Q::WORD,      Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "a1"))
                         .addDeclaration(Declaration(WHILE_STMT, "w"))
                         .selectDeclAttr("a1", EntityAttrType::STMTNO)
                         .selectDecl("w");
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select all possible attributes") {
    string test =
        "procedure procedure; call call; variable variable; read read; print "
        "print; constant constant; stmt stmt; while while; if if; assign "
        "assign; Select <procedure.procName, call.procName, variable.varName, "
        "read.varName, print.varName, constant.value, stmt.stmt#, read.stmt#, "
        "print.stmt#, call.stmt#, while.stmt#, if.stmt#, assign.stmt#>";
    Query expected = Query()
                         .addDeclaration(Declaration(PROC, "procedure"))
                         .addDeclaration(Declaration(CALL_STMT, "call"))
                         .addDeclaration(Declaration(VAR, "variable"))
                         .addDeclaration(Declaration(READ_STMT, "read"))
                         .addDeclaration(Declaration(PRINT_STMT, "print"))
                         .addDeclaration(Declaration(CONST, "constant"))
                         .addDeclaration(Declaration(STMT, "stmt"))
                         .addDeclaration(Declaration(WHILE_STMT, "while"))
                         .addDeclaration(Declaration(IF_STMT, "if"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "assign"))
                         .selectDeclAttr("procedure", EntityAttrType::PROCNAME)
                         .selectDeclAttr("call", EntityAttrType::PROCNAME)
                         .selectDeclAttr("variable", EntityAttrType::VARNAME)
                         .selectDeclAttr("read", EntityAttrType::VARNAME)
                         .selectDeclAttr("print", EntityAttrType::VARNAME)
                         .selectDeclAttr("constant", EntityAttrType::VALUE)
                         .selectDeclAttr("stmt", EntityAttrType::STMTNO)
                         .selectDeclAttr("read", EntityAttrType::STMTNO)
                         .selectDeclAttr("print", EntityAttrType::STMTNO)
                         .selectDeclAttr("call", EntityAttrType::STMTNO)
                         .selectDeclAttr("while", EntityAttrType::STMTNO)
                         .selectDeclAttr("if", EntityAttrType::STMTNO)
                         .selectDeclAttr("assign", EntityAttrType::STMTNO);
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select single entity in arrow brackets") {
    string test = "variable v, v1; read r; Select <v>";
    Query expected = Query()
                         .addDeclaration(Declaration(VAR, "v"))
                         .addDeclaration(Declaration(VAR, "v1"))
                         .addDeclaration(Declaration(READ_STMT, "r"))
                         .selectDecl("v");
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select single entityAttr in arrow brackets") {
    string test = "variable v, v1; read r; Select <v.varName>";
    Query expected = Query()
                         .addDeclaration(Declaration(VAR, "v"))
                         .addDeclaration(Declaration(VAR, "v1"))
                         .addDeclaration(Declaration(READ_STMT, "r"))
                         .selectDeclAttr("v", EntityAttrType::VARNAME);
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select all types of attributes") {
    string test =
        "variable v; read r; print p; call cl; assign a; if i; while w; "
        "procedure pr; constant c; Select "
        "<r.varName,p.varName,cl.procName,pr.procName,w.stmt#,i.stmt#,cl.stmt#,"
        "a.stmt#,r.stmt#,p.stmt#,c.value>";
    Query expected = Query()
                         .addDeclaration(Declaration(VAR, "v"))
                         .addDeclaration(Declaration(READ_STMT, "r"))
                         .addDeclaration(Declaration(PRINT_STMT, "p"))
                         .addDeclaration(Declaration(CALL_STMT, "cl"))
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .addDeclaration(Declaration(IF_STMT, "i"))
                         .addDeclaration(Declaration(WHILE_STMT, "w"))
                         .addDeclaration(Declaration(PROC, "pr"))
                         .addDeclaration(Declaration(CONST, "c"))
                         .selectDeclAttr("r", EntityAttrType::VARNAME)
                         .selectDeclAttr("p", EntityAttrType::VARNAME)
                         .selectDeclAttr("cl", EntityAttrType::PROCNAME)
                         .selectDeclAttr("pr", EntityAttrType::PROCNAME)
                         .selectDeclAttr("w", EntityAttrType::STMTNO)
                         .selectDeclAttr("i", EntityAttrType::STMTNO)
                         .selectDeclAttr("cl", EntityAttrType::STMTNO)
                         .selectDeclAttr("a", EntityAttrType::STMTNO)
                         .selectDeclAttr("r", EntityAttrType::STMTNO)
                         .selectDeclAttr("p", EntityAttrType::STMTNO)
                         .selectDeclAttr("c", EntityAttrType::VALUE);
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Invalid: Entity of entity attribute not found") {
    string test = "assign a, a1; while w; Select <a2.stmt#, w>";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Invalid: Entity attribute type not available for declaration") {
    string test = "assign a, a1; while w; Select <a2.procName, w>";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
}

TEST_CASE ("QueryParser: Select such that Parent/Parent*") {
  QueryParser parser;
  SECTION ("Declare 1, Select 1 such that Parent") {
    string test = "assign a; Select a such that Parent(1, a)";
    vector<std::string> texts = {"assign", "a",    ";",      "Select", "a",
                                 "such",   "that", "Parent", "(",      "1",
                                 ",",      "a",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD, Q::WORD,      Q::DELIMITER, Q::NUMBER,
        Q::DELIMITER, Q::WORD, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected =
        Query()
            .addDeclaration(Declaration(ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<SuchThatClause>(
                Entity(EntityType::STMT, "1"),
                Declaration{EntityType::ASSIGN_STMT, "a"}, PARENT));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare 1, Select 1 such that Parent with wildcard") {
    string test = "assign a; Select a such that Parent(_, 1)";
    vector<std::string> texts = {"assign", "a",    ";",      "Select", "a",
                                 "such",   "that", "Parent", "(",      "_",
                                 ",",      "1",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,   Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::NUMBER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .selectDecl("a")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::NULL_ENTITY, ""),
                             Entity{EntityType::STMT, "1"}, PARENT));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare 1, Select 1 such that Parent* with wildcard") {
    string test = "assign a; Select a such that Parent*(_, 1)";
    vector<std::string> texts = {"assign", "a",    ";",       "Select", "a",
                                 "such",   "that", "Parent*", "(",      "_",
                                 ",",      "1",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,   Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::NUMBER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .selectDecl("a")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::NULL_ENTITY, ""),
                             Entity{EntityType::STMT, "1"}, PARENT_T));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
}

TEST_CASE ("QueryParser: Select such that Follows/Follows*") {
  QueryParser parser;
  SECTION ("Declare 1, Select 1 such that Follows") {
    string test = "assign a; Select a such that Follows(1, a)";
    vector<std::string> texts = {"assign", "a",    ";",       "Select", "a",
                                 "such",   "that", "Follows", "(",      "1",
                                 ",",      "a",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD, Q::WORD,      Q::DELIMITER, Q::NUMBER,
        Q::DELIMITER, Q::WORD, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected =
        Query()
            .addDeclaration(Declaration(ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<SuchThatClause>(
                Entity(EntityType::STMT, "1"),
                Declaration{EntityType::ASSIGN_STMT, "a"}, FOLLOWS));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare 1, Select 1 such that Follows with wildcard") {
    string test = "assign a; Select a such that Follows(_, 1)";
    vector<std::string> texts = {"assign", "a",    ";",       "Select", "a",
                                 "such",   "that", "Follows", "(",      "_",
                                 ",",      "1",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,   Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::NUMBER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .selectDecl("a")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::NULL_ENTITY, ""),
                             Entity{EntityType::STMT, "1"}, FOLLOWS));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare 1, Select 1 such that Follows* with wildcard") {
    string test = "assign a; Select a such that Follows*(_, 1)";
    vector<std::string> texts = {"assign", "a",    ";",        "Select", "a",
                                 "such",   "that", "Follows*", "(",      "_",
                                 ",",      "1",    ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,   Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::NUMBER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .selectDecl("a")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::NULL_ENTITY, ""),
                             Entity{EntityType::STMT, "1"}, FOLLOWS_T));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Declare 1, Select 1 such that Follows* and Parent") {
    string test =
        "assign a; Select a such that Follows*(_, 1) and Parent(a, _)";
    vector<std::string> texts = {
        "assign",   "a", ";", "Select", "a", "such", "that",
        "Follows*", "(", "_", ",",      "1", ")",    "and",
        "Parent",   "(", "a", ",",      "_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,   Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::NUMBER, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,   Q::DELIMITER, Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(ASSIGN_STMT, "a"))
                         .selectDecl("a")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::NULL_ENTITY, ""),
                             Entity{EntityType::STMT, "1"}, FOLLOWS_T))
                         .addClause(make_shared<SuchThatClause>(
                             Declaration(EntityType::ASSIGN_STMT, "a"),
                             Entity{EntityType::NULL_ENTITY, ""}, PARENT));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
}

TEST_CASE ("QueryParser: Uses") {
  QueryParser parser;
  SECTION ("Select 1 such that Uses proc") {
    string test = "if ifs; variable v; Select v such that Uses(\"proc\", v)";
    vector<std::string> texts = {
        "if",   "ifs",  ";", "variable", "v",    ";",  "Select", "v", "such",
        "that", "Uses", "(", "\"",       "proc", "\"", ",",      "v", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD, Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD, Q::WORD,
        Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::WORD, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::PROC, "proc"),
                             Declaration{EntityType::VAR, "v"}, USES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Uses stmtNum") {
    string test = "if ifs; variable v; Select v such that Uses(5, v)";
    vector<std::string> texts = {
        "if",   "ifs",  ";",    "variable", "v", ";", "Select", "v",
        "such", "that", "Uses", "(",        "5", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD,   Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,   Q::WORD,      Q::WORD,      Q::DELIMITER,
        Q::NUMBER, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::STMT, "5"),
                             Declaration{EntityType::VAR, "v"}, USES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Uses stmt synonym") {
    string test = "if ifs; variable v; Select v such that Uses(ifs, v)";
    vector<std::string> texts = {
        "if",   "ifs",  ";",    "variable", "v",   ";", "Select", "v",
        "such", "that", "Uses", "(",        "ifs", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Declaration(EntityType::IF_STMT, "ifs"),
                             Declaration{EntityType::VAR, "v"}, USES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Uses proc synonym") {
    string test = "procedure p; variable v; Select v such that Uses(p, v)";
    vector<std::string> texts = {
        "procedure", "p",    ";",    "variable", "v", ";", "Select", "v",
        "such",      "that", "Uses", "(",        "p", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(PROC, "p"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Declaration(EntityType::PROC, "p"),
                             Declaration{EntityType::VAR, "v"}, USES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
}

TEST_CASE ("QueryParser: Modifies") {
  QueryParser parser;
  SECTION ("Select 1 such that Modifies proc") {
    string test =
        "if ifs; variable v; Select v such that Modifies(\"proc\", v)";
    vector<std::string> texts = {"if",       "ifs",    ";",  "variable", "v",
                                 ";",        "Select", "v",  "such",     "that",
                                 "Modifies", "(",      "\"", "proc",     "\"",
                                 ",",        "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD, Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD, Q::WORD,
        Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::WORD, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::PROC, "proc"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Modifies stmtNum") {
    string test = "if ifs; variable v; Select v such that Modifies(5, v)";
    vector<std::string> texts = {
        "if",   "ifs",  ";",        "variable", "v", ";", "Select", "v",
        "such", "that", "Modifies", "(",        "5", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD,   Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::WORD,   Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,   Q::WORD,      Q::WORD,      Q::DELIMITER,
        Q::NUMBER, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Entity(EntityType::STMT, "5"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Modifies stmt synonym") {
    string test = "if ifs; variable v; Select v such that Modifies(ifs, v)";
    vector<std::string> texts = {
        "if",   "ifs",  ";",        "variable", "v",   ";", "Select", "v",
        "such", "that", "Modifies", "(",        "ifs", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(IF_STMT, "ifs"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Declaration(EntityType::IF_STMT, "ifs"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 such that Modifies proc synonym") {
    string test = "procedure p; variable v; Select v such that Modifies(p, v)";
    vector<std::string> texts = {
        "procedure", "p",    ";",        "variable", "v", ";", "Select", "v",
        "such",      "that", "Modifies", "(",        "p", ",", "v",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::WORD,      Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    Query expected = Query()
                         .addDeclaration(Declaration(PROC, "p"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(make_shared<SuchThatClause>(
                             Declaration(EntityType::PROC, "p"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Support for single NOT clause versions") {
    string test =
        "procedure p; variable v; Select v such that not Modifies(p, v)";
    Query expected = Query()
                         .addDeclaration(Declaration(PROC, "p"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .selectDecl("v")
                         .addClause(makeNotCl(make_shared<SuchThatClause>(
                             Declaration(EntityType::PROC, "p"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Support for multiple NOT clause versions") {
    string test =
        "procedure p; variable v; stmt s; Select v such that not Modifies(p, "
        "v) and not Uses(s, v)";
    Query expected = Query()
                         .addDeclaration(Declaration(PROC, "p"))
                         .addDeclaration(Declaration(VAR, "v"))
                         .addDeclaration(Declaration(STMT, "s"))
                         .selectDecl("v")
                         .addClause(makeNotCl(make_shared<SuchThatClause>(
                             Declaration(EntityType::PROC, "p"),
                             Declaration{EntityType::VAR, "v"}, MODIFIES)))
                         .addClause(makeNotCl(make_shared<SuchThatClause>(
                             Declaration(EntityType::STMT, "s"),
                             Declaration{EntityType::VAR, "v"}, USES)));
    REQUIRE(expected == parser.parse(test));
  }
}

TEST_CASE ("QueryParser: Calls/Calls*") {
  QueryParser parser;
  SECTION ("Calls proc syn, proc syn") {
    string test = "procedure p, p1; Select p such that Calls(p, p1)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(p, p1, CALLS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls* proc syn, proc syn") {
    string test = "procedure p, p1; Select p such that Calls*(p, p1)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(p, p1, CALLS_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls proc wildcard, proc syn") {
    string test = "procedure p, p1; Select p such that Calls(_, p1)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(WILDCARD, p1, CALLS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls proc syn, proc wildcard") {
    string test = "procedure p, p1; Select p such that Calls(p, _)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(p, WILDCARD, CALLS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls* proc syn, proc wildcard") {
    string test = "procedure p, p1; Select p such that Calls*(p, _)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(p, WILDCARD, CALLS_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls* proc wildcard, proc syn") {
    string test = "procedure p, p1; Select p such that Calls*(_, p1)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(WILDCARD, p1, CALLS_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls proc wildcard, proc wildcard") {
    string test = "procedure p, p1; Select p such that Calls(_, _)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(WILDCARD, WILDCARD, CALLS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Calls* proc wildcard, proc wildcard") {
    string test = "procedure p, p1; Select p such that Calls*(_, _)";
    Declaration p(EntityType::PROC, "p");
    Declaration p1(EntityType::PROC, "p1");
    Query expected =
        Query().addDeclaration(p).addDeclaration(p1).selectDecl("p").addClause(
            make_shared<SuchThatClause>(WILDCARD, WILDCARD, CALLS_T));
    REQUIRE(expected == parser.parse(test));
  }
}

TEST_CASE ("QueryParser: Next/Next*") {
  QueryParser parser;
  SECTION ("Next stmt syn while syn") {
    string test = "stmt s; while w; Select s such that Next(s, w)";
    Declaration s(EntityType::STMT, "s");
    Declaration w(EntityType::WHILE_STMT, "w");
    Query expected = Query()
                         .addDeclaration(s)
                         .addDeclaration(w)
                         .selectDecl(s.label)
                         .addClause(make_shared<SuchThatClause>(s, w, NEXT));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next stmt syn stmt syn") {
    string test = "stmt s, s1; Select s such that Next(s, s1)";
    Declaration s(EntityType::STMT, "s");
    Declaration s1(EntityType::STMT, "s1");
    Query expected = Query()
                         .addDeclaration(s)
                         .addDeclaration(s1)
                         .selectDecl(s.label)
                         .addClause(make_shared<SuchThatClause>(s, s1, NEXT));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next* stmt syn while syn") {
    string test = "stmt s; while w; Select s such that Next*(s, w)";
    Declaration s(EntityType::STMT, "s");
    Declaration w(EntityType::WHILE_STMT, "w");
    Query expected = Query()
                         .addDeclaration(s)
                         .addDeclaration(w)
                         .selectDecl(s.label)
                         .addClause(make_shared<SuchThatClause>(s, w, NEXT_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next* stmt syn stmt syn") {
    string test = "stmt s, s1; Select s such that Next*(s, s1)";
    Declaration s(EntityType::STMT, "s");
    Declaration s1(EntityType::STMT, "s1");
    Query expected = Query()
                         .addDeclaration(s)
                         .addDeclaration(s1)
                         .selectDecl(s.label)
                         .addClause(make_shared<SuchThatClause>(s, s1, NEXT_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next wildcard stmt syn") {
    string test = "stmt s, s1; Select s such that Next(_, s1)";
    Declaration s(EntityType::STMT, "s");
    Declaration s1(EntityType::STMT, "s1");
    Query expected =
        Query()
            .addDeclaration(s)
            .addDeclaration(s1)
            .selectDecl(s.label)
            .addClause(make_shared<SuchThatClause>(WILDCARD, s1, NEXT));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next* stmt syn wildcard") {
    string test = "stmt s; while w; Select s such that Next*(s, _)";
    Declaration s(EntityType::STMT, "s");
    Declaration w(EntityType::WHILE_STMT, "w");
    Query expected =
        Query()
            .addDeclaration(s)
            .addDeclaration(w)
            .selectDecl(s.label)
            .addClause(make_shared<SuchThatClause>(s, WILDCARD, NEXT_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next* while syn wildcard") {
    string test = "stmt s; while w; Select s such that Next*(w, _)";
    Declaration s(EntityType::STMT, "s");
    Declaration w(EntityType::WHILE_STMT, "w");
    Query expected =
        Query()
            .addDeclaration(s)
            .addDeclaration(w)
            .selectDecl(s.label)
            .addClause(make_shared<SuchThatClause>(w, WILDCARD, NEXT_T));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next wildcard wildcard") {
    string test = "Select BOOLEAN such that Next(_, _)";
    Query expected = Query().addClause(
        make_shared<SuchThatClause>(WILDCARD, WILDCARD, NEXT));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Next* wildcard wildcard") {
    string test = "Select BOOLEAN such that Next*(_, _)";
    Query expected = Query().addClause(
        make_shared<SuchThatClause>(WILDCARD, WILDCARD, NEXT_T));
    REQUIRE(expected == parser.parse(test));
  }
}

TEST_CASE ("QueryParser: Affects") {
  QueryParser parser;
  SECTION ("Affects assign syn assign syn") {
    string test = "assign a, a1; Select a1 such that Affects(a, a1)";
    Declaration a(EntityType::ASSIGN_STMT, "a");
    Declaration a1(EntityType::ASSIGN_STMT, "a1");
    Query expected =
        Query()
            .addDeclaration(a)
            .addDeclaration(a1)
            .selectDecl(a1.label)
            .addClause(make_shared<SuchThatClause>(a, a1, AFFECTS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Affects wildcard assign syn") {
    string test = "assign a, a1; Select a1 such that Affects(_, a1)";
    Declaration a(EntityType::ASSIGN_STMT, "a");
    Declaration a1(EntityType::ASSIGN_STMT, "a1");
    Query expected =
        Query()
            .addDeclaration(a)
            .addDeclaration(a1)
            .selectDecl(a1.label)
            .addClause(make_shared<SuchThatClause>(WILDCARD, a1, AFFECTS));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Affects assign syn wildcard") {
    string test = "assign a, a1; Select a1 such that Affects(a, _)";
    Declaration a(EntityType::ASSIGN_STMT, "a");
    Declaration a1(EntityType::ASSIGN_STMT, "a1");
    Query expected =
        Query()
            .addDeclaration(a)
            .addDeclaration(a1)
            .selectDecl(a1.label)
            .addClause(make_shared<SuchThatClause>(a, WILDCARD, AFFECTS));
    REQUIRE(expected == parser.parse(test));
  }
}

TEST_CASE ("QueryParser: assign Pattern") {
  QueryParser parser;
  SECTION ("Select 1 pattern (_, exact match)") {
    string test = "assign a; Select a pattern a(_, \"a +b\")";
    vector<std::string> texts = {"assign", "a", ";",  "Select", "a",  "pattern",
                                 "a",      "(", "_",  ",",      "\"", "a",
                                 "+",      "b", "\"", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::WORD,      Q::WORD,      Q::WORD,      Q::DELIMITER,
        Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::WORD,
        Q::OP,        Q::WORD,      Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {"a", "+", "b"};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::NULL_ENTITY, ""), expr, false));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern (synonym, partial match)") {
    string test = "variable v; assign a; Select a pattern a(v, _\"a +b\"_)";
    vector<std::string> texts = {"variable", "v",      ";",   "assign",  "a",
                                 ";",        "Select", "a",   "pattern", "a",
                                 "(",        "v",      ",",   "_\"",     "a",
                                 "+",        "b",      "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD, Q::DELIMITER, Q::DELIMITER, Q::WORD,
        Q::OP,        Q::WORD, Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {"a", "+", "b"};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Declaration(EntityType::VAR, "v"), expr, true));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern (var, partial match with const)") {
    string test =
        "variable v; assign a; Select a pattern a(\"v\", _\"a %13\"_)";
    vector<std::string> texts = {
        "variable", "v",       ";", "assign", "a",  ";",   "Select",
        "a",        "pattern", "a", "(",      "\"", "v",   "\"",
        ",",        "_\"",     "a", "%",      "13", "\"_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::WORD,      Q::OP,        Q::NUMBER,    Q::DELIMITER,
        Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {"a", "%", "13"};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::VAR, "v"), expr, true));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern (var, wildcard)") {
    string test = "variable v; assign a; Select a pattern a(\"v\", _)";
    vector<std::string> texts = {
        "variable", "v", ";",  "assign", "a",  ";", "Select", "a", "pattern",
        "a",        "(", "\"", "v",      "\"", ",", "_",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .selectDecl("a")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::VAR, "v"), expr, false));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern while (var, wildcard)") {
    string test = "variable v; while w; Select w pattern w(\"v\", _)";
    vector<std::string> texts = {
        "variable", "v", ";",  "while", "w",  ";", "Select", "w", "pattern",
        "w",        "(", "\"", "v",     "\"", ",", "_",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::WHILE_STMT, "w"))
            .selectDecl("w")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::WHILE_STMT, "w"),
                Entity(EntityType::VAR, "v")));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern while (var syn, wildcard)") {
    string test = "variable v; while w; Select w pattern w(v, _)";
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::WHILE_STMT, "w"))
            .selectDecl("w")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::WHILE_STMT, "w"),
                Declaration(EntityType::VAR, "v")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 pattern while (wildcard, wildcard)") {
    string test = "variable v; while w; Select w pattern w(_, _)";
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::WHILE_STMT, "w"))
            .selectDecl("w")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::WHILE_STMT, "w"), WILDCARD));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 pattern if (var, wildcard)") {
    string test = "variable v; if w; Select w pattern w(\"v\", _, _)";
    vector<std::string> texts = {
        "variable", "v",  ";", "if", "w", ";", "Select", "w", "pattern", "w",
        "(",        "\"", "v", "\"", ",", "_", ",",      "_", ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {};
    Query expected = Query()
                         .addDeclaration(Declaration(EntityType::VAR, "v"))
                         .addDeclaration(Declaration(EntityType::IF_STMT, "w"))
                         .selectDecl("w")
                         .addClause(make_shared<PatternClause>(
                             Declaration(EntityType::IF_STMT, "w"),
                             Entity(EntityType::VAR, "v")));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern if (var syn, wildcard)") {
    string test = "variable v; if w; Select w pattern w(v, _,_)";
    Query expected = Query()
                         .addDeclaration(Declaration(EntityType::VAR, "v"))
                         .addDeclaration(Declaration(EntityType::IF_STMT, "w"))
                         .selectDecl("w")
                         .addClause(make_shared<PatternClause>(
                             Declaration(EntityType::IF_STMT, "w"),
                             Declaration(EntityType::VAR, "v")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 pattern if (wildcard, wildcard)") {
    string test = "variable v; if w; Select w pattern w(_, _,_)";
    Query expected = Query()
                         .addDeclaration(Declaration(EntityType::VAR, "v"))
                         .addDeclaration(Declaration(EntityType::IF_STMT, "w"))
                         .selectDecl("w")
                         .addClause(make_shared<PatternClause>(
                             Declaration(EntityType::IF_STMT, "w"), WILDCARD));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 pattern assign and pattern assign") {
    string test =
        "variable v; assign a, b; Select a pattern a(\"v\", _) and b(v, _)";
    vector<std::string> texts = {
        "variable", "v",       ";", "assign", "a",  ",", "b",  ";", "Select",
        "a",        "pattern", "a", "(",      "\"", "v", "\"", ",", "_",
        ")",        "and",     "b", "(",      "v",  ",", "_",  ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER, Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::WORD,
        Q::WORD,      Q::DELIMITER, Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    vector<RawToken> expr = {};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "b"))
            .selectDecl("a")
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::VAR, "v"), expr, false))
            .addClause(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "b"),
                Declaration(EntityType::VAR, "v"), expr, false));
    REQUIRE(expected == parser.parse(test));
    REQUIRE(expected == parser.parseTokens(tokens));
  }
  SECTION ("Select 1 pattern not assign") {
    string test = "variable v; assign a, b; Select a pattern not a(\"v\", _)";
    vector<RawToken> expr = {};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "b"))
            .selectDecl("a")
            .addClause(makeNotCl(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::VAR, "v"), expr, false)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 pattern not assign and not assign") {
    string test =
        "variable v; assign a, b; Select a pattern not a(\"v\", _) and not "
        "b(v, _)";
    vector<RawToken> expr = {};
    Query expected =
        Query()
            .addDeclaration(Declaration(EntityType::VAR, "v"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "a"))
            .addDeclaration(Declaration(EntityType::ASSIGN_STMT, "b"))
            .selectDecl("a")
            .addClause(makeNotCl(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "a"),
                Entity(EntityType::VAR, "v"), expr, false)))
            .addClause(makeNotCl(make_shared<PatternClause>(
                Declaration(EntityType::ASSIGN_STMT, "b"),
                Declaration(EntityType::VAR, "v"), expr, false)));
    REQUIRE(expected == parser.parse(test));
  }
}

TEST_CASE ("QueryParser: With pattern") {
  QueryParser parser;
  SECTION ("Select 1 with entityLabel = entityLabel") {
    string test = "Select BOOLEAN with \"m\" = \"m\"";
    Query expected = Query().addClause(
        make_shared<WithClause>(std::string("m"), std::string("m")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with entityLabel = anotherEntLabel") {
    string test = "Select BOOLEAN with \"m\" = \"nm\"";
    Query expected = Query().addClause(
        make_shared<WithClause>(std::string("m"), std::string("nm")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Invalid: Select 1 with entityLabel = number") {
    REQUIRE_THROWS_AS(parser.parse("Select BOOLEAN with \"m\" = 12"),
                      SemanticError);
    REQUIRE_THROWS_AS(parser.parse("Select BOOLEAN with 12 = \"m\""),
                      SemanticError);
  }
  SECTION ("Invalid: Select 1 with varName = name") {
    REQUIRE_THROWS_AS(
        parser.parse("assign a; Select BOOLEAN with a.stmt# = \"test\""),
        SemanticError);
    REQUIRE_THROWS_AS(
        parser.parse("assign a; Select BOOLEAN with \"test\" = a.stmt#"),
        SemanticError);
  }
  SECTION ("Invalid: Select 1 with varName = name") {
    REQUIRE_THROWS_AS(
        parser.parse("print a; Select BOOLEAN with a.varName = 12"),
        SemanticError);
    REQUIRE_THROWS_AS(
        parser.parse("print a; Select BOOLEAN with 12 = a.varName"),
        SemanticError);
  }
  SECTION ("Invalid: Select 1 with varName = name") {
    REQUIRE_THROWS_AS(
        parser.parse("print a, a1; Select BOOLEAN with a.varName = a1.stmt#"),
        SemanticError);
    REQUIRE_THROWS_AS(
        parser.parse("print a, a1; Select BOOLEAN with a1.stmt# = a.varName"),
        SemanticError);
  }
  SECTION ("Select 1 with decl = varName") {
    string test = "variable var; Select var with var.varName = \"test\"";
    Declaration var(EntityType::VAR, "var");
    Query expected =
        Query().addDeclaration(var).selectDecl(var.label).addClause(
            make_shared<WithClause>(
                std::make_pair(var, EntityAttrType::VARNAME),
                std::string("test")));
    REQUIRE(expected == parser.parse(test));
    test = "variable var; Select var with \"test\" = var.varName";
    expected = Query().addDeclaration(var).selectDecl(var.label).addClause(
        make_shared<WithClause>(std::string("test"),
                                std::make_pair(var, EntityAttrType::VARNAME)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = stmtNum") {
    string test = "read r; Select r with r.stmt# = 13";
    Declaration var(EntityType::READ_STMT, "r");
    Query expected =
        Query().addDeclaration(var).selectDecl(var.label).addClause(
            make_shared<WithClause>(std::make_pair(var, EntityAttrType::STMTNO),
                                    std::string("13")));
    REQUIRE(expected == parser.parse(test));
    test = "read r; Select r with 13 = r.stmt#";
    expected = Query().addDeclaration(var).selectDecl(var.label).addClause(
        make_shared<WithClause>(std::string("13"),
                                std::make_pair(var, EntityAttrType::STMTNO)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = read varName") {
    string test = "read r; Select r with r.varName = \"test\"";
    Declaration read(EntityType::READ_STMT, "r");
    Query expected = Query()
                         .addDeclaration(read)
                         .selectDecl(read.label)
                         .addClause(make_shared<WithClause>(
                             std::make_pair(read, EntityAttrType::VARNAME),
                             std::string("test")));
    REQUIRE(expected == parser.parse(test));
    test = "read r; Select r with \"test\" = r.varName";
    expected = Query()
                   .addDeclaration(read)
                   .selectDecl(read.label)
                   .addClause(make_shared<WithClause>(
                       std::string("test"),
                       std::make_pair(read, EntityAttrType::VARNAME)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = print varName") {
    string test = "print p; Select p with p.varName = \"test\"";
    Declaration p(EntityType::PRINT_STMT, "p");
    Query expected = Query().addDeclaration(p).selectDecl(p.label).addClause(
        make_shared<WithClause>(std::make_pair(p, EntityAttrType::VARNAME),
                                std::string("test")));
    REQUIRE(expected == parser.parse(test));
    test = "print p; Select p with \"test\" = p.varName";
    expected = Query().addDeclaration(p).selectDecl(p.label).addClause(
        make_shared<WithClause>(std::string("test"),
                                std::make_pair(p, EntityAttrType::VARNAME)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = call procName") {
    string test = "call c; Select c with c.procName = \"test\"";
    Declaration c(EntityType::CALL_STMT, "c");
    Query expected = Query().addDeclaration(c).selectDecl(c.label).addClause(
        make_shared<WithClause>(std::make_pair(c, EntityAttrType::PROCNAME),
                                std::string("test")));
    REQUIRE(expected == parser.parse(test));
    test = "call c; Select c with \"test\" = c.procName";
    expected = Query().addDeclaration(c).selectDecl(c.label).addClause(
        make_shared<WithClause>(std::string("test"),
                                std::make_pair(c, EntityAttrType::PROCNAME)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = procName") {
    string test = "procedure proc; Select proc with proc.procName = \"test\"";
    Declaration proc(EntityType::PROC, "proc");
    Query expected = Query()
                         .addDeclaration(proc)
                         .selectDecl(proc.label)
                         .addClause(make_shared<WithClause>(
                             std::make_pair(proc, EntityAttrType::PROCNAME),
                             std::string("test")));
    REQUIRE(expected == parser.parse(test));
    test = "procedure proc; Select proc with \"test\" = proc.procName";
    expected = Query()
                   .addDeclaration(proc)
                   .selectDecl(proc.label)
                   .addClause(make_shared<WithClause>(
                       std::string("test"),
                       std::make_pair(proc, EntityAttrType::PROCNAME)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = constVal") {
    string test = "constant c; Select c with c.value = 420";
    Declaration con(EntityType::CONST, "c");
    Query expected =
        Query().addDeclaration(con).selectDecl(con.label).addClause(
            make_shared<WithClause>(std::make_pair(con, EntityAttrType::VALUE),
                                    std::string("420")));
    REQUIRE(expected == parser.parse(test));
    test = "constant c; Select c with 420 = c.value";
    expected = Query().addDeclaration(con).selectDecl(con.label).addClause(
        make_shared<WithClause>(std::string("420"),
                                std::make_pair(con, EntityAttrType::VALUE)));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with decl = constVal with const as BOOLEAN") {
    string test = "constant BOOLEAN; Select BOOLEAN with BOOLEAN.value = 420";
    Declaration con(EntityType::CONST, "BOOLEAN");
    Query expected =
        Query().addDeclaration(con).selectDecl(con.label).addClause(
            make_shared<WithClause>(std::make_pair(con, EntityAttrType::VALUE),
                                    std::string("420")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with and with") {
    string test =
        "read r; constant c; Select c with c.value = 420 and r.varName = "
        "\"text\"";
    Declaration con(EntityType::CONST, "c");
    Declaration r(EntityType::READ_STMT, "r");
    Query expected =
        Query()
            .addDeclaration(con)
            .addDeclaration(r)
            .selectDecl(con.label)
            .addClause(make_shared<WithClause>(
                std::make_pair(con, EntityAttrType::VALUE), std::string("420")))
            .addClause(make_shared<WithClause>(
                std::make_pair(r, EntityAttrType::VARNAME),
                std::string("text")));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with not") {
    string test =
        "read r; constant c; Select c with not r.varName = "
        "\"text\"";
    Declaration con(EntityType::CONST, "c");
    Declaration r(EntityType::READ_STMT, "r");
    Query expected = Query()
                         .addDeclaration(con)
                         .addDeclaration(r)
                         .selectDecl(con.label)
                         .addClause(makeNotCl(make_shared<WithClause>(
                             std::make_pair(r, EntityAttrType::VARNAME),
                             std::string("text"))));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with and with not") {
    string test =
        "read r; constant c; Select c with c.value = 420 and not r.varName = "
        "\"text\"";
    Declaration con(EntityType::CONST, "c");
    Declaration r(EntityType::READ_STMT, "r");
    Query expected =
        Query()
            .addDeclaration(con)
            .addDeclaration(r)
            .selectDecl(con.label)
            .addClause(make_shared<WithClause>(
                std::make_pair(con, EntityAttrType::VALUE), std::string("420")))
            .addClause(makeNotCl(make_shared<WithClause>(
                std::make_pair(r, EntityAttrType::VARNAME),
                std::string("text"))));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Select 1 with not and with not") {
    string test =
        "read r; constant c; Select c with not c.value = 420 and not r.varName "
        "= "
        "\"text\"";
    Declaration con(EntityType::CONST, "c");
    Declaration r(EntityType::READ_STMT, "r");
    Query expected = Query()
                         .addDeclaration(con)
                         .addDeclaration(r)
                         .selectDecl(con.label)
                         .addClause(makeNotCl(make_shared<WithClause>(
                             std::make_pair(con, EntityAttrType::VALUE),
                             std::string("420"))))
                         .addClause(makeNotCl(make_shared<WithClause>(
                             std::make_pair(r, EntityAttrType::VARNAME),
                             std::string("text"))));
    REQUIRE(expected == parser.parse(test));
  }
  SECTION ("Invalid: Select 1 with entityLabel = numberWithQuotes") {
    string test = "Select BOOLEAN with \"m\" = \"12\"";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "Select BOOLEAN with \"123\" = \"m\"";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "Select BOOLEAN with \"123\" = \"456\"";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "assign a, a1; Select a1 with a1 = \"456\"";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "assign a, a1; Select a1 with a1 = a.stmt#";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "assign a, a1; Select a1 with a1.stmt# = a";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    test = "assign a, a1; Select a1 with a1 = a";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("Invalid: Entity attribute type not available for declaration") {
    string test =
        "assign a, a1; procedure p; Select BOOLEAN with a2.procName = "
        "p.procName";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Invalid: with a.stmt = 12") {
    string test = "assign a; Select a with a.stmt = 12";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("Invalid: with a.stmt#.varName") {
    string test = "assign a; Select a with a.stmt#.varName = 12";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
}

TEST_CASE ("QueryParser: invalid tokens") {
  QueryParser parser;
  SECTION ("Invalid Synonym") {
    string test = "procedure b; while 2; Select b";
    vector<std::string> texts = {"procedure", "b", ";",      "while",
                                 "2",         ";", "Select", "b"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD,   Q::DELIMITER,
                                    Q::WORD, Q::NUMBER, Q::DELIMITER,
                                    Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Synonym not in declarations") {
    string test = "assign a, a1; while w; Select b";
    vector<std::string> texts = {"assign", "a", ",", "a1",     ";",
                                 "while",  "w", ";", "Select", "b"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SemanticError);
  }
  SECTION ("Synonym duplicated") {
    string test = "assign w, a1; while w; Select a1";
    vector<std::string> texts = {"assign", "w", ",", "a1",     ";",
                                 "while",  "w", ";", "Select", "a1"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SemanticError);
  }
  SECTION ("Such that: Invalid ref (stmt number instead of varName)") {
    string test = "if ifs; Select ifs such that Modifies (\"caller\", 12)";
    vector<std::string> texts = {"if",     "ifs",  ";",        "Select", "ifs",
                                 "such",   "that", "Modifies", "(",      "\"",
                                 "caller", "\"",   ",",        "12",     ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::DELIMITER, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD, Q::WORD,      Q::WORD,      Q::DELIMITER, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::DELIMITER, Q::NUMBER,    Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Such that: Invalid ref (name instead of stmt number)") {
    string test = "if ifs; Select ifs such that Follows* (\"caller\", 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION (
      "Such that: First argument of Uses/Modifies should not be wildcard") {
    string test = "if ifs; Select ifs such that Uses (_, \"test\")";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
    test = "if ifs; Select ifs such that Modifies (_, \"test\")";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Such that: Invalid synonym type") {
    string test =
        "procedure proc; read r; Select proc such that Follows(proc, r)";
    vector<std::string> texts = {
        "procedure", "proc", ";",       "read", "r",    ";", "Select", "proc",
        "such",      "that", "Follows", "(",    "proc", ",", "r",      ")"};
    vector<QueryTokenType> types = {
        Q::WORD, Q::WORD,      Q::DELIMITER, Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,     Q::WORD, Q::DELIMITER,
        Q::WORD, Q::DELIMITER, Q::NUMBER,    Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SemanticError);
  }
  SECTION ("Pattern: Invalid declaration type (SemanticError)") {
    string test = "variable v; read r; Select v pattern r (v, _)";
    vector<std::string> texts = {"variable", "v",      ";", "read",    "r",
                                 ";",        "Select", "v", "pattern", "r",
                                 "(",        "v",      ",", "_",       ")"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD, Q::WORD,      Q::WORD,      Q::WORD,
        Q::DELIMITER, Q::WORD, Q::DELIMITER, Q::DELIMITER, Q::DELIMITER};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SemanticError);
  }
  SECTION ("Synonym not in declarations, 2 wildcard params") {
    string test = "assign s; Select s pattern s1(_, _)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Synonym not in declarations, left decl, right wildcard") {
    string test = "assign s; variable v; Select s pattern s1(v, _)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Synonym not in declarations, left wildcard, right pattern") {
    string test = "assign s; variable v; Select s pattern s1(_, _\"v\"_)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Synonym not in declarations, left entity, right pattern") {
    string test = "assign s; variable v; Select s pattern s1(\"v\", _\"v\"_)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Synonym not in declarations, 3 params, left decl") {
    string test = "assign s; variable v; Select s pattern s1(v, _, _)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Synonym not in declarations, 3 params") {
    string test = "assign s; Select s pattern s1(_, _, _)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("Pattern: Dangling such that") {
    string test = "variable v; assign r; Select v such that";
    vector<std::string> texts = {"variable", "v",      ";", "assign", "r",
                                 ";",        "Select", "v", "such",   "that"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD, Q::DELIMITER, Q::WORD, Q::WORD,
        Q::DELIMITER, Q::WORD, Q::WORD,      Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Pattern: Dangling pattern") {
    string test = "variable v; assign r; Select v pattern";
    vector<std::string> texts = {"variable", "v",      ";", "assign", "r",
                                 ";",        "Select", "v", "pattern"};
    vector<QueryTokenType> types = {Q::WORD, Q::WORD, Q::DELIMITER,
                                    Q::WORD, Q::WORD, Q::DELIMITER,
                                    Q::WORD, Q::WORD, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("Pattern: Dangling and") {
    string test = "variable v; assign r; Select v pattern r (v, _) and";
    vector<std::string> texts = {"variable", "v", ";",       "assign", "r", ";",
                                 "Select",   "v", "pattern", "r",      "(", "v",
                                 ",",        "_", ")",       "and"};
    vector<QueryTokenType> types = {
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::WORD,      Q::DELIMITER, Q::WORD,      Q::WORD,
        Q::WORD,      Q::WORD,      Q::DELIMITER, Q::WORD,
        Q::DELIMITER, Q::DELIMITER, Q::DELIMITER, Q::WORD};
    vector<QueryToken> tokens = makeTokens(texts, types);
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
    REQUIRE_THROWS_AS(parser.parseTokens(tokens), SyntaxError);
  }
  SECTION ("SemanticError: ifs declaration with wrong pattern") {
    string test = "if ifs; while w; variable v; Select ifs pattern ifs(_,_)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
  SECTION ("SemanticError: w declaration with wrong pattern") {
    string test = "if ifs; while w; variable v; Select w pattern w(_,_,_)";
    REQUIRE_THROWS_AS(parser.parse(test), SemanticError);
  }
}

TEST_CASE ("QueryParser: Mixed clauses (WIP)") {
  QueryParser parser;
  SECTION ("Valid 3 unique clause types: Select such that pattern with") {
    Declaration v(EntityType::VAR, "v");
    Declaration a(EntityType::ASSIGN_STMT, "a");
    vector<RawToken> expr = {};
    string varNameLabel = "yes";
    string test =
        "variable v; assign a; Select v such that Modifies(a, v) pattern a (v, "
        "_) with v.varName = \"yes\"";
    Query query =
        Query()
            .addDeclaration(v)
            .addDeclaration(a)
            .selectDecl(v.label)
            .addClause(make_shared<SuchThatClause>(a, v, MODIFIES))
            .addClause(make_shared<PatternClause>(a, v, expr, false))
            .addClause(make_shared<WithClause>(
                std::make_pair(v, EntityAttrType::VARNAME), varNameLabel));
    REQUIRE(query == parser.parse(test));
  }
  SECTION (
      "Valid 2 unique clause types interleaving: Select pattern with pattern") {
    Declaration v(EntityType::VAR, "v");
    Declaration a(EntityType::ASSIGN_STMT, "a");
    Declaration a1(EntityType::ASSIGN_STMT, "a1");
    vector<RawToken> expr = {};
    string varNameLabel = "yes";
    string test =
        "variable v; assign a, a1; Select v pattern a1 (v, _) with v.varName = "
        "\"yes\" pattern a (v, _)";
    Query query =
        Query()
            .addDeclaration(v)
            .addDeclaration(a)
            .addDeclaration(a1)
            .selectDecl(v.label)
            .addClause(make_shared<PatternClause>(a1, v, expr, false))
            .addClause(make_shared<WithClause>(
                std::make_pair(v, EntityAttrType::VARNAME), varNameLabel))
            .addClause(make_shared<PatternClause>(a, v, expr, false));
    REQUIRE(query == parser.parse(test));
  }
}

TEST_CASE (
    "QueryParser: SyntaxErrors take precedence over all SemanticErrors below") {
  QueryParser parser;
  SECTION ("SemanticError: first arg of Uses") {
    string test = "if ifs; Select ifs such that Uses (_, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("SemanticError: declaration not found") {
    string test = "if ifs; Select p such that Uses (ifs, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("SemanticError: variable declaration not found") {
    string test = "read r; Select v pattern r (v, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("SemanticError: variable declaration not allowed") {
    string test = "variable v; Select v such that Uses (v, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("SemanticError: variable declaration not allowed") {
    string test = "variable v; Select v such that Uses (v, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
  SECTION ("SemanticError: variable declaration not allowed") {
    string test = "variable v; Select v such that Uses (v, 12)";
    REQUIRE_THROWS_AS(parser.parse(test), SyntaxError);
  }
}