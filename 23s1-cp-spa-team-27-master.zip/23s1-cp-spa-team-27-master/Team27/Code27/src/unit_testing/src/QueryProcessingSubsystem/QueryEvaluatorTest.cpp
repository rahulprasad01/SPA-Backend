#include <iostream>
#include <numeric>
#include "../Common/TestUtils.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "QueryProcessingSubsystem/PatternClause.h"
#include "QueryProcessingSubsystem/Query.h"
#include "QueryProcessingSubsystem/QueryEvaluator.h"
#include "QueryProcessingSubsystem/SuchThatClause.h"
#include "catch.hpp"

using namespace SPA;
using namespace PKB;
using namespace QPS;
using namespace TEST;

TEST_CASE ("QueryEvaluator: Empty PKB") {
  PKBManager pkbManager;
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  Query query;
  Declaration d1{EntityType::ASSIGN_STMT, "a"};
  query.addDeclaration(d1).selectDecl(d1.label);
  QueryEvaluator queryEvaluator;
  std::vector<QueryEvaluator::RecordRef> result =
      queryEvaluator.evaluateQuery(query, pkbQuery);
  REQUIRE(result == expected);
}

TEST_CASE ("QueryEvaluator: Check No Relation") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  for (int i = 1; i <= 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    pkbInsert.insertFollows(eprev, e);
  }
  SECTION ("Select only") {
    Query query;
    Declaration d1{EntityType::ASSIGN_STMT, "a"};
    query.addDeclaration(d1).selectDecl("a");
    QueryEvaluator queryEvaluator;
    for (int i = 1; i <= 10; ++i) {
      Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
      expected.push_back({e.label});
    }
    REQUIRE(TEST::allInVector(queryEvaluator.evaluateQuery(query, pkbQuery),
                              expected));
  }
  SECTION ("Follows") {
    Query query;
    Declaration d1{EntityType::ASSIGN_STMT, "a"};
    query.addDeclaration(d1).selectDecl(d1.label).addClause(
        std::make_shared<SuchThatClause>(Entity(ASSIGN_STMT, "1"), d1,
                                         FOLLOWS_T));
    QueryEvaluator queryEvaluator;
    for (int i = 2; i <= 10; ++i) {
      Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
      expected.push_back({e.label});
    }
    REQUIRE(TEST::allInVector(queryEvaluator.evaluateQuery(query, pkbQuery),
                              expected));
  }
}

TEST_CASE ("QueryEvaluator: Check Simple Follows") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  Entity stmt3(EntityType::ASSIGN_STMT, "3");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertEntity(stmt3);
  pkbInsert.insertFollows(stmt1, stmt2);
  pkbInsert.insertFollows(stmt2, stmt3);
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::FOLLOWS));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS_T));
  REQUIRE(pkbQuery.hasRelation(stmt2, stmt3, RelationType::FOLLOWS_T));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt3, RelationType::FOLLOWS_T));
  QueryEvaluator queryEvaluator;
  Query query1, query2;
  Declaration declaration1{EntityType::ASSIGN_STMT, "s"};
  SuchThatClause clause1(declaration1, stmt2, RelationType::FOLLOWS);
  SuchThatClause clause2(declaration1, stmt3, RelationType::FOLLOWS_T);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration1).selectDecl(declaration1.label);
  query2.addClause(std::make_shared<SuchThatClause>(clause2));
  query2.addDeclaration(declaration1).selectDecl(declaration1.label);
  std::vector<QueryEvaluator::RecordRef> result1 =
      queryEvaluator.evaluateQuery(query1, pkbQuery);
  std::vector<QueryEvaluator::RecordRef> result2 =
      queryEvaluator.evaluateQuery(query2, pkbQuery);
  REQUIRE(result1 == std::vector<QueryEvaluator::RecordRef>{{stmt1.label}});
  REQUIRE(result2 ==
          std::vector<QueryEvaluator::RecordRef>{{stmt1.label}, {stmt2.label}});
}

TEST_CASE ("QueryEvaluator: Check Simple Uses") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected1;
  std::vector<QueryEvaluator::RecordRef> expected2;
  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::PRINT_STMT, "3"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  pkbInsert.insertEntity(var);
  pkbInsert.insertEntity(proc);
  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
    pkbInsert.insertUses(stmt, var);
    REQUIRE(pkbQuery.hasRelation(stmt, var, RelationType::USES));
  }
  pkbInsert.insertUses(proc, var);
  REQUIRE(pkbQuery.hasRelation(proc, var, RelationType::USES));

  QueryEvaluator queryEvaluator;
  Query query1, query2;

  // Check if stmt in stmts uses the var v
  // stmt s; variable v; Select s such that Uses(s, v)
  Declaration declaration1{EntityType::STMT, "s"};
  SuchThatClause clause1(declaration1, var, RelationType::USES);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration1).selectDecl(declaration1.label);
  std::vector<QueryEvaluator::RecordRef> result1 =
      queryEvaluator.evaluateQuery(query1, pkbQuery);
  for (const auto& stmt : stmts) {
    expected1.push_back({stmt.label});
  }
  REQUIRE(result1 == expected1);

  // Check if procedure p uses var v
  // procedure p; variable v; Select p such that Uses(p, v)
  Declaration declaration2{EntityType::PROC, "p"};
  SuchThatClause clause2(declaration2, var, RelationType::USES);
  query2.addClause(std::make_shared<SuchThatClause>(clause2));
  query2.addDeclaration(declaration2).selectDecl(declaration2.label);
  std::vector<QueryEvaluator::RecordRef> result2 =
      queryEvaluator.evaluateQuery(query2, pkbQuery);
  expected2.push_back({proc.label});
  REQUIRE(result2 == expected2);
}

TEST_CASE ("QueryEvaluator: Check Simple Modifies") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected1;
  std::vector<QueryEvaluator::RecordRef> expected2;

  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::READ_STMT, "2"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  pkbInsert.insertEntity(var);
  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
    pkbInsert.insertModifies(stmt, var);
    REQUIRE(pkbQuery.hasRelation(stmt, var, RelationType::MODIFIES));
  }
  pkbInsert.insertEntity(proc);
  pkbInsert.insertModifies(proc, var);
  REQUIRE(pkbQuery.hasRelation(proc, var, RelationType::MODIFIES));

  QueryEvaluator queryEvaluator;
  Query query1, query2;

  // Check if stmt in stmts modifies the var v
  // stmt s; variable v; Select s such that Modifies(s, v)
  Declaration declaration1{EntityType::STMT, "s"};
  Declaration declaration2{EntityType::VAR, "v"};
  SuchThatClause clause1(declaration1, var, RelationType::MODIFIES);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration1)
      .addDeclaration(declaration2)
      .selectDecl(declaration1.label);
  std::vector<QueryEvaluator::RecordRef> result1 =
      queryEvaluator.evaluateQuery(query1, pkbQuery);
  for (const auto& stmt : stmts) {
    expected1.push_back({stmt.label});
  }
  REQUIRE(result1 == expected1);

  // Check if procedure p modifies var v
  // procedure p; variable v; Select p such that Modifies(p, v)
  Declaration declaration3{EntityType::PROC, "p"};
  SuchThatClause clause2(declaration3, var, RelationType::MODIFIES);
  query2.addClause(std::make_shared<SuchThatClause>(clause2));
  query2.addDeclaration(declaration3).selectDecl(declaration3.label);
  std::vector<QueryEvaluator::RecordRef> result2 =
      queryEvaluator.evaluateQuery(query2, pkbQuery);
  expected2.push_back({proc.label});
  REQUIRE(result2 == expected2);
}

TEST_CASE ("QueryEvaluator: Check Simple Parent and Parent*") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);

  vector<Entity> stmts = {
      Entity(SPA::READ_STMT, "1"),   Entity(SPA::IF_STMT, "2"),
      Entity(SPA::CALL_STMT, "3"),   Entity(SPA::WHILE_STMT, "4"),
      Entity(SPA::ASSIGN_STMT, "5"), Entity(SPA::PRINT_STMT, "6"),
  };

  // read
  // if {
  //    call
  //    while {
  //        =
  //    }
  //    print
  // }
  vector<std::pair<int, int>> pairs = {
      {1, 2},
      {1, 3},
      {1, 5},
      {3, 4},
  };

  for (const auto& stmt : stmts) {
    pkbInsert.insertEntity(stmt);
  }

  for (const auto& p : pairs) {
    pkbInsert.insertParent(stmts[p.first], stmts[p.second]);
    REQUIRE(pkbQuery.hasRelation(stmts[p.first], stmts[p.second],
                                 RelationType::PARENT));
  }

  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[2], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[3], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[3], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[3], stmts[4], RelationType::PARENT));
  REQUIRE(pkbQuery.hasRelation(stmts[1], stmts[4], RelationType::PARENT_T));
  REQUIRE(pkbQuery.hasRelation(stmts[3], stmts[4], RelationType::PARENT_T));
  REQUIRE_FALSE(pkbQuery.hasRelation(stmts[3], stmts[5], RelationType::PARENT));
  REQUIRE_FALSE(
      pkbQuery.hasRelation(stmts[1], stmts[0], RelationType::PARENT_T));

  QueryEvaluator queryEvaluator;
  Query query1, query2;
  std::vector<QueryEvaluator::RecordRef> expected1 = {{stmts[1].label}};
  std::vector<QueryEvaluator::RecordRef> expected2 = {
      {stmts[2].label}, {stmts[3].label}, {stmts[4].label}, {stmts[5].label}};

  // Check Parent relation
  // stmt s; Select s such that Parent(s, 4)
  Declaration declaration1{EntityType::STMT, "s"};
  SuchThatClause clause1(declaration1, stmts[3], RelationType::PARENT);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration1).selectDecl(declaration1.label);
  std::vector<QueryEvaluator::RecordRef> result1 =
      queryEvaluator.evaluateQuery(query1, pkbQuery);
  REQUIRE(result1 == expected1);

  // Check Parent* relation
  // stmt s; Select s such that Parent*(2, s)
  Declaration declaration2{EntityType::STMT, "s"};
  SuchThatClause clause2(stmts[1], declaration2, RelationType::PARENT_T);
  query2.addClause(std::make_shared<SuchThatClause>(clause2));
  query2.addDeclaration(declaration2).selectDecl(declaration2.label);
  std::vector<QueryEvaluator::RecordRef> result2 =
      queryEvaluator.evaluateQuery(query2, pkbQuery);
  REQUIRE(result2 == expected2);
}

TEST_CASE ("QueryEvaluator: Check Wildcard") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  for (int i = 1; i < 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    expected.push_back({eprev.label});
    pkbInsert.insertFollows(eprev, e);
  }
  // assign a; Select a such that Follows(a, _)
  Query query;
  Declaration d1{EntityType::ASSIGN_STMT, "a"};
  query.addDeclaration(d1).selectDecl(d1.label).addClause(
      std::make_shared<SuchThatClause>(d1, Entity(EntityType::NULL_ENTITY, ""),
                                       RelationType::FOLLOWS));
  QueryEvaluator queryEvaluator;
  REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
}

TEST_CASE ("QueryEvaluator: Check many such that (a)") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  for (int i = 1; i < 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    pkbInsert.insertFollows(eprev, e);
    if (i == 9) break;
    expected.push_back({eprev.label});
  }
  // assign a, b, c; Select a such that Follows(a, b) such that Follows(b, c)
  Query query;
  Declaration a{EntityType::ASSIGN_STMT, "a"};
  Declaration b{EntityType::ASSIGN_STMT, "b"};
  Declaration c{EntityType::ASSIGN_STMT, "c"};
  query.addDeclaration(a)
      .addDeclaration(b)
      .addDeclaration(c)
      .selectDecl("a")
      .addClause(std::make_shared<SuchThatClause>(a, b, RelationType::FOLLOWS))
      .addClause(std::make_shared<SuchThatClause>(b, c, RelationType::FOLLOWS));
  // std::cout << query << std::endl;
  QueryEvaluator queryEvaluator;
  REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
}

TEST_CASE ("QueryEvaluator: Check unused declarations") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  for (int i = 1; i < 10; ++i) {
    Entity eprev(EntityType::ASSIGN_STMT, std::to_string(i - 1));
    Entity e(EntityType::ASSIGN_STMT, std::to_string(i));
    pkbInsert.insertEntity(e);
    if (i == 1) continue;
    pkbInsert.insertFollows(eprev, e);
    expected.push_back({eprev.label});
  }
  // assign a, b; variable c; Select a such that Follows(a, b)
  Query query;
  Declaration a{EntityType::ASSIGN_STMT, "a"};
  Declaration b{EntityType::ASSIGN_STMT, "b"};
  Declaration c{EntityType::VAR, "c"};
  query.addDeclaration(a)
      .addDeclaration(b)
      .addDeclaration(c)
      .selectDecl("a")
      .addClause(std::make_shared<SuchThatClause>(a, b, RelationType::FOLLOWS));
  QueryEvaluator queryEvaluator;
  REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
}

TEST_CASE ("QueryEvaluator: basic pattern") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  std::vector<QueryEvaluator::RecordRef> expected;
  Entity e(EntityType::ASSIGN_STMT, "1");
  pkbInsert.insertEntity(e);
  vector<char> chars(10);
  std::iota(chars.begin(), chars.end(), 'a');
  for (char x : chars) {
    pkbInsert.insertEntity({EntityType::VAR, std::string(1, x)});
  }
  Entity b(EntityType::VAR, "b");
  vector<RawToken> expr = {"b", "+", "c", "/", "e"};
  pkbInsert.insertModifies(e, b);
  pkbInsert.insertUses(e, {EntityType::VAR, "b"});
  pkbInsert.insertUses(e, {EntityType::VAR, "c"});
  pkbInsert.insertUses(e, {EntityType::VAR, "e"});
  pkbManager.getPatternStorageHandle().insertAssignPattern(e, b, expr);
  SECTION ("stmt a") {
    // assign a; Select a pattern a ("b", "b + c / e")
    Query query;
    Declaration a{EntityType::ASSIGN_STMT, "a"};
    query.addDeclaration(a).selectDecl("a").addClause(
        std::make_shared<PatternClause>(a, b, expr, false));
    QueryEvaluator queryEvaluator;
    expected.push_back({"1"});
    REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
  }
  SECTION ("lhs var v") {
    // assign a; variable v; Select v pattern a (v, "b + c / e")
    Query query;
    Declaration a{EntityType::ASSIGN_STMT, "a"};
    Declaration v{EntityType::VAR, "v"};
    query.addDeclaration(a).addDeclaration(v).selectDecl("v").addClause(
        std::make_shared<PatternClause>(a, v, expr, false));
    QueryEvaluator queryEvaluator;
    expected.push_back({"b"});
    REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
  }
  SECTION ("rhs var v") {
    // assign a; variable v; Select v pattern a (_, "b + c / e") such that
    // Uses(a, v)
    Query query;
    Declaration a{EntityType::ASSIGN_STMT, "a"};
    Declaration v{EntityType::VAR, "v"};
    query.addDeclaration(a)
        .addDeclaration(v)
        .selectDecl("v")
        .addClause(std::make_shared<PatternClause>(a, WILDCARD, expr, false))
        .addClause(std::make_shared<SuchThatClause>(a, v, RelationType::USES));
    QueryEvaluator queryEvaluator;
    expected.push_back({"b"});
    expected.push_back({"c"});
    expected.push_back({"e"});
    REQUIRE(queryEvaluator.evaluateQuery(query, pkbQuery) == expected);
  }
}

TEST_CASE ("QueryEvaluator: Select BOOLEAN") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  PKBQuery pkbQuery(pkbManager);
  Entity stmt1(EntityType::ASSIGN_STMT, "1");
  Entity stmt2(EntityType::ASSIGN_STMT, "2");
  pkbInsert.insertEntity(stmt1);
  pkbInsert.insertEntity(stmt2);
  pkbInsert.insertFollows(stmt1, stmt2);
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS));
  REQUIRE(pkbQuery.hasRelation(stmt1, stmt2, RelationType::FOLLOWS_T));
  QueryEvaluator queryEvaluator;
  Query query1;
  Declaration declaration{EntityType::ASSIGN_STMT, "s"};
  SuchThatClause clause1(declaration, stmt2, RelationType::FOLLOWS);
  query1.addClause(std::make_shared<SuchThatClause>(clause1));
  query1.addDeclaration(declaration);
  std::vector<QueryEvaluator::RecordRef> result1 =
      queryEvaluator.evaluateQuery(query1, pkbQuery);
  REQUIRE(result1 == std::vector<QueryEvaluator::RecordRef>{{"TRUE"}});
}
