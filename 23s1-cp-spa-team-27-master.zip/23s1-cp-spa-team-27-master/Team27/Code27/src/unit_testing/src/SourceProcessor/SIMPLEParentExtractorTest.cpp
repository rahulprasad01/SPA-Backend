#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/ParentExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

StmtPair pair(int s1, int s2) {
  return std::make_pair(std::to_string(s1), std::to_string(s2));
}

// checks exact order
void checkPairs(vector<StmtPair>& expected, vector<StmtPair>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    REQUIRE(expected[i].first == actual[i].first);
    REQUIRE(expected[i].second == actual[i].second);
  }
}

TEST_CASE ("Parent Extractor: Basic nested structure") {
  auto whileStmt = makeWhileNode(
      1, {"pred"}, {},
      {makeWhileNode(2, {"pred"}, {}, {makeUnaryNode(3, READ_STMT, "varA")})});
  auto proc = makeProcNode("process", {whileStmt});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  vector<StmtPair> expected = {pair(1, 2), pair(2, 3)};
  checkPairs(expected, actual);
}

TEST_CASE ("Parent Extractor: Deeper nested structure") {
  auto readStmt1 = makeUnaryNode(1, READ_STMT, "pred");
  auto printStmt2 = makeUnaryNode(2, PRINT_STMT, "varB");
  auto whileStmt3 =
      makeWhileNode(3, {"pred1"}, {},
                    {
                        makeUnaryNode(4, CALL_STMT, "help"),
                        makeWhileNode(5, {"pred2"}, {"2"},
                                      {makeUnaryNode(6, PRINT_STMT, "varC")}),
                        makeUnaryNode(7, CALL_STMT, "help"),
                    });
  auto proc = makeProcNode("process", {readStmt1, printStmt2, whileStmt3});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  vector<StmtPair> expected = {pair(3, 4), pair(3, 5), pair(5, 6), pair(3, 7)};
  checkPairs(expected, actual);
}

TEST_CASE ("Parent Extractor: Parent relationships within If statements") {
  auto ifStmt =
      makeIfNode(1, {"condition"}, {}, {makeUnaryNode(2, READ_STMT, "varA")},
                 {makeUnaryNode(3, PRINT_STMT, "varB")});
  auto proc = makeProcNode("process", {ifStmt});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  // Testing parent relationships within If statements
  vector<StmtPair> expected = {pair(1, 2), pair(1, 3)};
  checkPairs(expected, actual);
}

TEST_CASE ("Parent Extractor: Complex control flow with nested structures") {
  auto readStmt1 = makeUnaryNode(1, READ_STMT, "pred");
  auto whileStmt2 =
      makeWhileNode(3, {"x"}, {}, {makeUnaryNode(4, PRINT_STMT, "varC")});
  auto ifStmt4 = makeIfNode(2, {"y"}, {}, {whileStmt2},
                            {makeUnaryNode(5, PRINT_STMT, "varD")});
  auto proc = makeProcNode("process", {readStmt1, ifStmt4});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  // Testing parent relationships in complex control flow
  vector<StmtPair> expected = {pair(2, 3), pair(3, 4), pair(2, 5)};
  checkPairs(expected, actual);
}

TEST_CASE ("Parent Extractor: Edge cases - Empty procedure") {
  auto proc = makeProcNode("empty_proc", {});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  // Testing parent relationships in an empty procedure
  REQUIRE(actual.empty());
}

TEST_CASE ("Parent Extractor: Negative case - No parent relationships") {
  auto readStmt1 = makeUnaryNode(1, READ_STMT, "pred");
  auto printStmt2 = makeUnaryNode(2, PRINT_STMT, "varB");
  auto proc = makeProcNode("process", {readStmt1, printStmt2});
  ParentExtractor pe;
  pe.run({proc});
  auto actual = pe.getParentChild();
  // Testing a scenario with no parent relationships
  REQUIRE(actual.empty());
}
