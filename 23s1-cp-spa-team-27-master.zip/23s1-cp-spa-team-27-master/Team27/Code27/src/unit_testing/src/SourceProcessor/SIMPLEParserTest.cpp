#include "SIMPLETestTools.h"
#include "SourceProcessor/SIMPLEParser.h"
#include "catch.hpp"

using namespace SPA;

TEST_CASE ("SIMPLEParser") {
  SIMPLEParser spparser;
  SECTION ("Single procedure, single read") {
    auto tokens = procA();
    std::string str = "procedure nameA { read testVar; }";
    vector<shared_ptr<ProcAST>> expectedProc = {
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }
  SECTION ("Parser: single procedure, multiple unaries") {
    auto tokens = procB();
    std::string str =
        "procedure nameB { read testVar; print testVar; call "
        "someProcToBeChecked; }";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameB", {
                     makeUnaryNode(1, READ_STMT, "testVar"),
                     makeUnaryNode(2, PRINT_STMT, "testVar"),
                     makeUnaryNode(3, CALL_STMT, "someProcToBeChecked"),
                 })};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }
  SECTION ("Parser: multiple procedure, multiple unaries") {
    auto tokens = procB();
    extend(tokens, procA());
    std::string str =
        "procedure nameB { read testVar; print testVar; call "
        "someProcToBeChecked; }"
        "procedure nameA { read testVar; }";
    vector<shared_ptr<ProcAST>> expectedProc = {
        makeProcNode("nameB",
                     {
                         makeUnaryNode(1, READ_STMT, "testVar"),
                         makeUnaryNode(2, PRINT_STMT, "testVar"),
                         makeUnaryNode(3, CALL_STMT, "someProcToBeChecked"),
                     }),
        makeProcNode("nameA", {makeUnaryNode(4, READ_STMT, "testVar")})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }
  SECTION ("Single procedure, single ifstmt") {
    auto tokens = procC();
    std::string str =
        "procedure nameC {"
        "if (!(VAR != 801)) then {"
        "print testVar; call someProcToBeChecked; }"
        "else { call anotherProc; }}";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameC",
        {makeIfNode(1, {"VAR"}, {"801"},
                    {makeUnaryNode(2, PRINT_STMT, "testVar"),
                     makeUnaryNode(3, CALL_STMT, "someProcToBeChecked")},
                    {makeUnaryNode(4, CALL_STMT, "anotherProc")})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }
  SECTION ("Single procedure, single whilestmt") {
    auto tokens = procD();
    std::string str =
        "procedure nameD {"
        "while (someCond <= a + b) {"
        "read someCond; } } ";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameD", {makeWhileNode(1, {"someCond", "a", "b"}, {},
                                {makeUnaryNode(2, READ_STMT, "someCond")})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION ("Single procedure, single whilestmt with assign stmt") {
    auto tokens = procF();
    std::string str =
        "procedure nameF {"
        "while ((a != 100) && (b != 9)) {"
        "test = one + two / 2; }}";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameF",
        {makeWhileNode(1, {"a", "b"}, {"100", "9"},
                       {makeAssignNode(2, "test", {"one", "two"}, {"2"},
                                       {"one", "+", "two", "/", "2"})})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION ("Single procedure, single ifstmt and single whilestmt") {
    auto tokens = procG();
    std::string str =
        "procedure nameG {"
        "if (a != b) then {"
        "a = (a - ((b + c) % 10)) * 5; }"
        "else { print testVar; }"
        "while (a <= b) {"
        "read someCond; }}";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameG",
        {makeIfNode(1, {"a", "b"}, {},
                    {makeAssignNode(2, "a", {"a", "b", "c"}, {"10", "5"},
                                    {"(", "a", "-", "(", "(", "b", "+", "c",
                                     ")", "%", "10", ")", ")", "*", "5"})},
                    {makeUnaryNode(3, PRINT_STMT, "testVar")}),
         makeWhileNode(4, {"a", "b"}, {},
                       {makeUnaryNode(5, READ_STMT, "someCond")})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION ("Single procedure, single ifstmt in a whilestmt") {
    auto tokens = procH();
    std::string str =
        "procedure nameH {"
        "while (a != b) {"
        "if (a < b) then {"
        "a = a + 1; }"
        "else { print testVar; }}}";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameH",
        {makeWhileNode(
            1, {"a", "b"}, {},
            {makeIfNode(2, {"a", "b"}, {},
                        {makeAssignNode(3, "a", {"a"}, {"1"}, {"a", "+", "1"})},
                        {makeUnaryNode(4, PRINT_STMT, "testVar")})})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION (
      "Single procedure, single ifstmt and single whilestmt and single "
      "whilestmt in ifstmt") {
    auto tokens = procI();
    std::string str =
        "procedure nameI {"
        "if (a != b) then {"
        "print a; }"
        "else { print testVar; }"
        "while (a >= b) {"
        "a = a - 1; }"
        "while (a <= b) {"
        "if (a > 1) then {"
        "a = b; }"
        "else { print testVar; }}}";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "nameI",
        {makeIfNode(1, {"a", "b"}, {}, {makeUnaryNode(2, PRINT_STMT, "a")},
                    {makeUnaryNode(3, PRINT_STMT, "testVar")}),
         makeWhileNode(4, {"a", "b"}, {},
                       {makeAssignNode(5, "a", {"a"}, {"1"}, {"a", "-", "1"})}),
         makeWhileNode(
             6, {"a", "b"}, {},
             {makeIfNode(7, {"a"}, {"1"},
                         {makeAssignNode(8, "a", {"b"}, {}, {"b"})},
                         {makeUnaryNode(9, PRINT_STMT, "testVar")})})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION ("Multiple procedure, single ifstmt and multiple whilestmt") {
    // Combine
    auto tokens = procD();
    extend(tokens, procH());
    std::string str =
        "procedure nameD {"
        "while (someCond <= a + b) {"
        "read someCond; } } "
        "procedure nameH {"
        "while (a != b) {"
        "if (a < b) then {"
        "a = a + 1; }"
        "else { print testVar; }}}";
    vector<shared_ptr<ProcAST>> expectedProc = {
        makeProcNode("nameD", {makeWhileNode(
                                  1, {"someCond", "a", "b"}, {},
                                  {makeUnaryNode(2, READ_STMT, "someCond")})}),
        makeProcNode(
            "nameH",
            {makeWhileNode(
                3, {"a", "b"}, {},
                {makeIfNode(
                    4, {"a", "b"}, {},
                    {makeAssignNode(5, "a", {"a"}, {"1"}, {"a", "+", "1"})},
                    {makeUnaryNode(6, PRINT_STMT, "testVar")})})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }

  SECTION ("Multiple procedure, multiple ifstmt and single whilestmt") {
    auto tokens = procC();
    extend(tokens, procH());
    std::string str =
        "procedure nameC {"
        "if (!(VAR != 801)) then {"
        "print testVar; call someProcToBeChecked; }"
        "else { call anotherProc; }}"
        "procedure nameH {"
        "while (a != b) {"
        "if (a < b) then {"
        "a = a + 1; }"
        "else { print testVar; }}}";
    vector<shared_ptr<ProcAST>> expectedProc = {
        makeProcNode(
            "nameC",
            {makeIfNode(1, {"VAR"}, {"801"},
                        {makeUnaryNode(2, PRINT_STMT, "testVar"),
                         makeUnaryNode(3, CALL_STMT, "someProcToBeChecked")},
                        {makeUnaryNode(4, CALL_STMT, "anotherProc")})}),
        makeProcNode(
            "nameH",
            {makeWhileNode(
                5, {"a", "b"}, {},
                {makeIfNode(
                    6, {"a", "b"}, {},
                    {makeAssignNode(7, "a", {"a"}, {"1"}, {"a", "+", "1"})},
                    {makeUnaryNode(8, PRINT_STMT, "testVar")})})})};
    matchProcList(expectedProc, spparser.parseTokens(tokens));
    matchProcList(expectedProc, spparser.parse(str));
  }
  SECTION ("Invalid while/if condition: presence of = operator") {
    std::string str =
        "procedure A { if (x = 0) then { read x; } else { print x; } }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("Invalid while/if condition: no relop") {
    std::string str =
        "procedure A { if (80) then { read x; } else { print x; } }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("Invalid while/if condition: invalid rel") {
    std::string str =
        "procedure A { if (80 || x < 0) then { read x; } else { print x; } }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("Invalid while/if condition: invalid rel") {
    std::string str =
        "procedure A { if (80 || x < 0) then { read x; } else { print x; } }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("Valid assign stmt: overloaded keyword as variable") {
    std::string str =
        "procedure A { read = read; print = print + read; call = 1 + "
        "call; while = 1 + if; if = 2 + while; }";
    vector<shared_ptr<ProcAST>> expectedProc = {makeProcNode(
        "A", {
                 makeAssignNode(1, "read", {"read"}, {}, {"read"}),
                 makeAssignNode(2, "print", {"print", "read"}, {},
                                {"print", "+", "read"}),
                 makeAssignNode(3, "call", {"call"}, {"1"}, {"1", "+", "call"}),
                 makeAssignNode(4, "while", {"if"}, {"1"}, {"1", "+", "if"}),
                 makeAssignNode(5, "if", {"while"}, {"2"}, {"2", "+", "while"}),
             })};
    matchProcList(expectedProc, spparser.parse(str));
  }
}
TEST_CASE ("Invalid assign statements") {
  SIMPLEParser spparser;
  SECTION ("no right bracket") {
    std::string str = "procedure A { x = 7 * (x + 1; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("no left bracket") {
    std::string str = "procedure A { x = 7 * x + 1); }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("bad + expression") {
    std::string str = "procedure A { x = 2 +; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("no semicolon") {
    std::string str = "procedure A { x = 2 + x }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("empty") {
    std::string str = "procedure A { x = ; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("leading zeroes") {
    std::string str = "procedure A { x = 2 * 01; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("far left op") {
    std::string str = "procedure A { x = - 2 * 01; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("more unmatched bracs") {
    std::string str = "procedure A { x = )(2 * 1; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("empty inside bracs") {
    std::string str = "procedure A { x = (); }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("two consecutive terms") {
    std::string str = "procedure A { x = y z; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
  SECTION ("invalid terms") {
    std::string str = "procedure A { x = y && 1; }";
    REQUIRE_THROWS(spparser.parse(str));
  }
}

void checkThrows(vector<SIMPLEToken> tokens) {
  SIMPLEParser spparser;
  REQUIRE_THROWS(spparser.parseTokens(tokens));
}

TEST_CASE ("Parser Syntax Errors: Check") {
  checkThrows(badNoBracketsRelExpr());
  checkThrows(badNoOpenBracket());
  checkThrows(badExtraCloseBracket());
  checkThrows(badNoSemicolon());
  checkThrows(badArithExpr());
  checkThrows(badArithExpr2());
  checkThrows(badEmptyStmtList());
}