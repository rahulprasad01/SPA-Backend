#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/FollowsExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

FollowsPair fpair(int s1, int s2) {
  return std::make_pair(std::to_string(s1), std::to_string(s2));
}

// checks exact order
void checkFollowsPairs(vector<FollowsPair>& expected,
                       vector<FollowsPair>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    REQUIRE(expected[i].first == actual[i].first);
    REQUIRE(expected[i].second == actual[i].second);
  }
}

TEST_CASE ("Follows Extractor: No follows") {
  auto whileStmt = makeWhileNode(
      1, {"pred"}, {},
      {makeWhileNode(2, {"pred"}, {}, {makeUnaryNode(3, READ_STMT, "varA")})});
  auto proc = makeProcNode("process", {whileStmt});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Unary") {
  auto readStmt = makeUnaryNode(1, READ_STMT, "varRead");
  auto printStmt = makeUnaryNode(2, PRINT_STMT, "varPrint");
  auto callStmt = makeUnaryNode(3, CALL_STMT, "Call");
  auto proc = makeProcNode("process", {readStmt, printStmt, callStmt});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(2, 3)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Assign") {
  auto assignStmt1 = makeAssignNode(1, "var1", {"x"}, {"1"}, {});
  auto assignStmt2 = makeAssignNode(2, "var2", {"y"}, {"2"}, {});
  auto assignStmt3 = makeAssignNode(3, "var3", {"z"}, {"3"}, {});
  auto proc = makeProcNode("process", {assignStmt1, assignStmt2, assignStmt3});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(2, 3)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: If Statement") {
  auto readStmt = makeUnaryNode(1, READ_STMT, "varRead");
  auto ifStmt = makeIfNode(2, {"pred1"}, {"2"},
                           {
                               makeUnaryNode(3, PRINT_STMT, "varPrint"),
                               makeUnaryNode(4, CALL_STMT, "Call"),
                           },
                           {makeAssignNode(5, "var1", {"x"}, {}, {}),
                            makeAssignNode(6, "var2", {"y"}, {}, {})});
  auto callStmt = makeUnaryNode(7, CALL_STMT, "Call");
  auto proc = makeProcNode("process", {readStmt, ifStmt, callStmt});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(3, 4), fpair(5, 6),
                                  fpair(2, 7)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Deeper nested structure") {
  auto readStmt1 = makeUnaryNode(1, READ_STMT, "pred");
  auto printStmt2 = makeUnaryNode(2, PRINT_STMT, "varB");
  auto whileStmt3 =
      makeWhileNode(3, {"pred1"}, {},
                    {
                        makeUnaryNode(4, CALL_STMT, "help"),
                        makeWhileNode(5, {"pred2"}, {"19"},
                                      {makeUnaryNode(6, PRINT_STMT, "varC")}),
                        makeUnaryNode(7, CALL_STMT, "help"),
                    });
  auto proc = makeProcNode("process", {readStmt1, printStmt2, whileStmt3});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(2, 3), fpair(4, 5),
                                  fpair(5, 7)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Unary statements with Follows") {
  auto proc = makeProcNode("process", {makeUnaryNode(1, READ_STMT, "varA"),
                                       makeUnaryNode(2, PRINT_STMT, "varB"),
                                       makeUnaryNode(3, READ_STMT, "varC")});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(2, 3)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Assign statements with Follows") {
  auto proc =
      makeProcNode("process", {makeAssignNode(1, "x", {"var4"}, {"1", "4"},
                                              {"1", "/", "var4", "+", "4"}),
                               makeAssignNode(2, "y", {"var5"}, {"2", "4"},
                                              {"2", "/", "var5", "+", "4"}),
                               makeAssignNode(3, "z", {"var6"}, {"3", "4"},
                                              {"3", "/", "var6", "+", "4"})});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(1, 2), fpair(2, 3)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: If statements with Follows") {
  auto proc = makeProcNode(
      "process", {makeIfNode(1, {"cd", "ef"}, {},
                             {makeAssignNode(2, "x", {"var2"}, {"1", "4"},
                                             {"1", "/", "var2", "+", "4"}),
                              makeAssignNode(3, "y", {"var3"}, {"2", "4"},
                                             {"2", "/", "var3", "+", "4"})},
                             {makeUnaryNode(5, READ_STMT, "var6")}),
                  makeIfNode(4, {"ab"}, {},
                             {makeAssignNode(5, "a", {"var5"}, {"10", "4"},
                                             {"10", "/", "var5", "+", "4"})},
                             {makeUnaryNode(6, READ_STMT, "var7")})});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(2, 3), fpair(1, 4)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: While statements with Follows") {
  auto proc = makeProcNode(
      "process",
      {makeWhileNode(1, {}, {},
                     {makeAssignNode(2, "x", {"var2"}, {"1", "4"},
                                     {"1", "/", "var2", "+", "4"}),
                      makeAssignNode(3, "y", {"var3"}, {"2", "4"},
                                     {"2", "/", "var3", "+", "4"})}),
       makeWhileNode(4, {}, {},
                     {makeAssignNode(5, "a", {"var5"}, {"10", "4"},
                                     {"10", "/", "var5", "+", "4"})})});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(2, 3), fpair(1, 4)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: While and If statements with Follows") {
  auto proc = makeProcNode(
      "process",
      {makeWhileNode(
           1, {}, {},
           {makeIfNode(2, {"ab", "cd"}, {},
                       {makeAssignNode(3, "x", {"var3"}, {"1", "4"},
                                       {"1", "/", "var3", "+", "4"})},
                       {makeUnaryNode(4, PRINT_STMT, "var1")}),
            makeWhileNode(4, {}, {},
                          {makeAssignNode(5, "y", {"var5"}, {"2", "4"},
                                          {"2", "/", "var5", "+", "4"})})}),
       makeWhileNode(6, {}, {},
                     {makeAssignNode(7, "a", {"var7"}, {"10", "4"},
                                     {"10", "/", "var7", "+", "4"})})});
  FollowsExtractor pe;
  pe.run({proc});
  auto actual = pe.getFollows();
  vector<FollowsPair> expected = {fpair(2, 4), fpair(1, 6)};
  checkFollowsPairs(expected, actual);
}

TEST_CASE ("Follows Extractor: Negative case - No follows relationships") {
  auto proc1 =
      makeProcNode("procA", {makeAssignNode(1, "x", {"varA"}, {"4", "10"},
                                            {"4", "/", "varA", "+", "10"})});
  auto proc2 =
      makeProcNode("procB", {makeAssignNode(2, "y", {"varB"}, {"4", "10"},
                                            {"4", "/", "varB", "+", "10"})});

  FollowsExtractor fe;
  fe.run({proc1, proc2});
  auto actual = fe.getFollows();
  // Testing a scenario with no follows relationships

  REQUIRE(actual.empty());
}
