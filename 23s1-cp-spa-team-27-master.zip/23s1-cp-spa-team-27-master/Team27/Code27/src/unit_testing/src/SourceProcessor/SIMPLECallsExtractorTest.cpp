#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/CallsExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

// checks exact order
void checkCallsPairs(vector<CallsPair>& expected, vector<CallsPair>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    REQUIRE(expected[i].first == actual[i].first);
    REQUIRE(expected[i].second == actual[i].second);
  }
}

TEST_CASE ("Calls Extractor: two procs") {
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2")});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(2, READ_STMT, "var")});
  CallsExtractor pe;
  pe.run({proc1, proc2});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {{"proc1", "proc2"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: container statements calls") {
  auto proc1 = makeProcNode(
      "proc1", {makeUnaryNode(1, READ_STMT, "ok"),
                makeWhileNode(2, {"ok"}, {"1"},
                              {makeUnaryNode(3, CALL_STMT, "proc2")})});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(4, READ_STMT, "var")});
  CallsExtractor pe;
  pe.run({proc1, proc2});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {{"proc1", "proc2"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: container statements calls (if)") {
  auto proc1 = makeProcNode(
      "proc1",
      {makeIfNode(1, {"var"}, {"1"}, {makeUnaryNode(2, CALL_STMT, "called")},
                  {makeUnaryNode(3, CALL_STMT, "call")})});
  auto proc2 = makeProcNode(
      "called", {makeWhileNode(4, {"ok"}, {"3"},
                               {makeUnaryNode(5, PRINT_STMT, "test")})});
  auto proc3 = makeProcNode(
      "call",
      {makeIfNode(6, {"ok"}, {"2"}, {makeUnaryNode(7, CALL_STMT, "called")},
                  {makeUnaryNode(8, READ_STMT, "ok")})});
  CallsExtractor pe;
  pe.run({proc1, proc2, proc3});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "called"}, {"proc1", "call"}, {"call", "called"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: No Calls relations") {
  auto proc1 =
      makeProcNode("proc1", {makeUnaryNode(1, PRINT_STMT, "nonexistent")});
  CallsExtractor pe;
  pe.run({proc1});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: Cyclic calls") {
  // SIMPLE language should not have cyclic calls
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2")});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(2, CALL_STMT, "proc1")});
  CallsExtractor pe;
  pe.run({proc1, proc2});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {{"proc1", "proc2"}, {"proc2", "proc1"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: Multiple Calls") {
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2"),
                                      makeUnaryNode(2, CALL_STMT, "proc3")});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(3, READ_STMT, "varA")});
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(4, CALL_STMT, "proc4")});
  auto proc4 = makeProcNode("proc4", {makeUnaryNode(5, READ_STMT, "varB")});
  CallsExtractor pe;
  pe.run({proc1, proc2, proc3, proc4});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "proc2"}, {"proc1", "proc3"}, {"proc3", "proc4"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: Cross-Procedure Calls") {
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2")});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(2, CALL_STMT, "proc3")});
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(3, CALL_STMT, "proc4")});
  auto proc4 = makeProcNode("proc4", {makeUnaryNode(4, READ_STMT, "varA")});
  CallsExtractor pe;
  pe.run({proc1, proc2, proc3, proc4});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "proc2"}, {"proc2", "proc3"}, {"proc3", "proc4"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: Recursive Calls") {
  // SIMPLE language should not have recursive calls
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc1")});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(2, CALL_STMT, "proc2")});
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(3, CALL_STMT, "proc3")});
  CallsExtractor pe;
  pe.run({proc1, proc2, proc3});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "proc1"}, {"proc2", "proc2"}, {"proc3", "proc3"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: No Calls Relationship") {
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, READ_STMT, "varA")});
  auto proc2 = makeProcNode("proc2", {makeAssignNode(2, "x", {}, {}, {})});
  CallsExtractor pe;
  pe.run({proc1, proc2});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls Extractor: Multiple procedures") {
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2"),
                                      makeUnaryNode(2, CALL_STMT, "proc3")});

  auto proc2 = makeProcNode(
      "proc2",
      {makeIfNode(3, {"var1"}, {"1"},
                  {makeWhileNode(4, {"var2"}, {"2"},
                                 {makeUnaryNode(5, CALL_STMT, "proc3")})},
                  {makeAssignNode(6, "x", {"ab"}, {"4", "11"},
                                  {"4", "/", "ab", "+", "11"})}),
       makeAssignNode(7, "y", {"bc"}, {"4", "11"},
                      {"4", "/", "bc", "+", "11"})});

  auto proc3 = makeProcNode(
      "proc3", {makeWhileNode(8, {"var3"}, {"3"},
                              {makeUnaryNode(9, CALL_STMT, "proc4")})});

  auto proc4 =
      makeProcNode("proc4", {makeAssignNode(10, "z", {"cd"}, {"4", "11"},
                                            {"4", "/", "cd", "+", "11"})});

  auto proc5 = makeProcNode("proc5", {makeUnaryNode(11, CALL_STMT, "proc6")});

  auto proc6 = makeProcNode(
      "proc6",
      {makeIfNode(12, {"var4"}, {"4"}, {makeUnaryNode(13, CALL_STMT, "proc7")},
                  {makeAssignNode(14, "w", {"de"}, {"4", "11"},
                                  {"4", "/", "cd", "+", "11"})})});

  auto proc7 =
      makeProcNode("proc7", {makeAssignNode(15, "v", {"gh"}, {"3", "12"},
                                            {"3", "/", "gh", "+", "12"})});

  CallsExtractor pe;
  pe.run({proc1, proc2, proc3, proc4, proc5, proc6, proc7});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {{"proc1", "proc2"}, {"proc1", "proc3"},
                                {"proc2", "proc3"}, {"proc3", "proc4"},
                                {"proc5", "proc6"}, {"proc6", "proc7"}};
}

TEST_CASE ("Calls extractor: Nested while loops") {
  auto proc1 = makeProcNode(
      "proc1",
      {makeWhileNode(1, {"xy"}, {"4"},
                     {makeUnaryNode(2, CALL_STMT, "proc2"),
                      makeWhileNode(3, {"ok"}, {"2"},
                                    {makeUnaryNode(4, CALL_STMT, "proc3")})})});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(5, CALL_STMT, "proc3")});
  auto proc3 =
      makeProcNode("proc3", {makeAssignNode(15, "v", {"gh"}, {"3", "12"},
                                            {"3", "/", "gh", "+", "12"})});

  CallsExtractor pe;
  pe.run({proc1, proc2, proc3});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "proc2"}, {"proc1", "proc3"}, {"proc2", "proc3"}};
  checkCallsPairs(expected, actual);
}

TEST_CASE ("Calls extractor: Multiple nested containers") {
  auto proc1 = makeProcNode(
      "proc1",
      {makeWhileNode(
          1, {"ab"}, {"4", "11"},
          {makeIfNode(2, {"xy"}, {"4"}, {makeUnaryNode(3, CALL_STMT, "proc2")},
                      {makeUnaryNode(4, CALL_STMT, "proc3")}),
           makeUnaryNode(5, CALL_STMT, "proc4")})});
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(1, PRINT_STMT, "print")});
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(1, READ_STMT, "read")});
  auto proc4 = makeProcNode("proc4", {makeUnaryNode(1, PRINT_STMT, "var1")});

  CallsExtractor pe;
  pe.run({proc1, proc2, proc3, proc4});
  auto actual = pe.getCalls();
  vector<CallsPair> expected = {
      {"proc1", "proc2"},
      {"proc1", "proc3"},
      {"proc1", "proc4"},
  };
  checkCallsPairs(expected, actual);
}