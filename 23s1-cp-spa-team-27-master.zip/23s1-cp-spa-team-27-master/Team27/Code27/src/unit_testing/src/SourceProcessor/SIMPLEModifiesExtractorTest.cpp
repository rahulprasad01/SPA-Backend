

#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/ModifiesExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using std::unordered_map;
using std::unordered_set;
using namespace SP;
using EntityMap =
    unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>;

void printME(const ModifiesExtractor& ue) {
  auto map = ue.getStmtOrProcToVars();
  for (const auto& stmtSet : map) {
    std::cout << stmtSet.first << " (" << EntityToString(stmtSet.first.type)
              << "): ";
    for (const auto& vAST : stmtSet.second) {
      std::cout << vAST << ", ";
    }
    std::cout << std::endl;
  }
}

void matchModifiesMap(const EntityMap& expected, const ModifiesExtractor& ue) {
  auto map = ue.getStmtOrProcToVars();
  REQUIRE(map.size() >= expected.size());
  for (const auto& actualStmt : map) {
    REQUIRE((expected.find(actualStmt.first) != expected.end() ||
             actualStmt.second.size() == 0));
  }
  for (const auto& stmtSet : expected) {
    const auto& set = map[stmtSet.first];
    REQUIRE(set.size() == stmtSet.second.size());
    for (const auto& var : set) {
      REQUIRE(set.find(var) != set.end());
    }
  }
}

TEST_CASE ("Modifies Extractor Test : single print stmt: nothing") {
  ModifiesExtractor ue;

  SECTION ("single print stmt: nothing") {
    auto proc = makeProcNode("test", {makeUnaryNode(1, PRINT_STMT, "varA")});
    ue.run({proc});
    EntityMap expected = {};
    matchModifiesMap(expected, ue);
  }
  SECTION ("single assign stmt") {
    auto proc = makeProcNode(
        "test", {makeAssignNode(
                    1, "vba", {"a", "b", "c", "d"}, {"3", "10"},
                    {"a", "+", "3", "-", "b", "/", "c", "+", "10", "*", "d"})});
    ue.run({proc});
    unordered_set<std::string> varSet = {"vba"};
    EntityMap expected = {{Entity(PROC, "test"), varSet},
                          {Entity(ASSIGN_STMT, "1"), varSet}};
    matchModifiesMap(expected, ue);
  }
  SECTION ("single if stmt with read and assign stmts") {
    auto proc = makeProcNode(
        "test",
        {makeIfNode(1, {"ab", "cd"}, {"13"},
                    {makeAssignNode(2, "vba", {"a", "b", "c", "d"}, {"3", "10"},
                                    {"a", "+", "3", "-", "b", "/", "c", "+",
                                     "10", "*", "d"})},
                    {makeUnaryNode(3, READ_STMT, "varA")})});
    unordered_set<std::string> set3 = {"varA"};
    unordered_set<std::string> set2 = {"vba"};
    unordered_set<std::string> set1 = {"vba", "varA"};
    EntityMap expected = {{Entity(PROC, "test"), set1},
                          {Entity(IF_STMT, "1"), set1},
                          {Entity(ASSIGN_STMT, "2"), set2},
                          {Entity(READ_STMT, "3"), set3}};
    ue.run({proc});
    matchModifiesMap(expected, ue);
  }
  SECTION ("if stmt with mixed stmts") {
    auto proc = makeProcNode(
        "test", {makeIfNode(1, {"ab", "cd"}, {"202"},
                            {makeAssignNode(2, "var2", {"x"}, {"3", "10"},
                                            {"3", "/", "x", "+", "10"}),
                             makeAssignNode(3, "var3", {"y"}, {"3", "10"},
                                            {"3", "/", "y", "+", "10"})},
                            {
                                makeUnaryNode(4, PRINT_STMT, "varA"),
                                makeUnaryNode(5, READ_STMT, "varB"),
                            })});
    EntityMap expected = {{Entity(PROC, "test"), {"var2", "var3", "varB"}},
                          {Entity(IF_STMT, "1"), {"var2", "var3", "varB"}},
                          {Entity(ASSIGN_STMT, "2"), {"var2"}},
                          {Entity(ASSIGN_STMT, "3"), {"var3"}},
                          {Entity(READ_STMT, "5"), {"varB"}}};
    ue.run({proc});
    matchModifiesMap(expected, ue);
  }
  SECTION ("if stmt nested") {
    auto proc = makeProcNode(
        "test",
        {makeIfNode(
            1, {"ab", "cd"}, {},
            {makeAssignNode(2, "var2", {"x"}, {"3", "10"},
                            {"3", "/", "x", "+", "10"}),
             makeAssignNode(3, "var3", {"y"}, {"3", "10"},
                            {"3", "/", "x", "+", "10"})},
            {makeIfNode(4, {"ab"}, {}, {makeUnaryNode(5, PRINT_STMT, "varA")},
                        {makeUnaryNode(6, READ_STMT, "varB")})})});
    EntityMap expected = {{Entity(PROC, "test"), {"var2", "var3", "varB"}},
                          {Entity(IF_STMT, "1"), {"var2", "var3", "varB"}},
                          {Entity(ASSIGN_STMT, "2"), {"var2"}},
                          {Entity(ASSIGN_STMT, "3"), {"var3"}},
                          {Entity(IF_STMT, "4"), {"varB"}},
                          {Entity(READ_STMT, "6"), {"varB"}}};
    ue.run({proc});
    matchModifiesMap(expected, ue);
  }
  SECTION ("calls between 2 procedures") {
    auto proc1 = makeProcNode("callee", {makeUnaryNode(1, READ_STMT, "varA")});
    auto proc2 =
        makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
    EntityMap expected = {
        {Entity(PROC, "callee"), {"varA"}},
        {Entity(PROC, "caller"), {"varA"}},
        {Entity(READ_STMT, "1"), {"varA"}},
        {Entity(CALL_STMT, "2"), {"varA"}},
    };
    ue.run({proc1, proc2});
    matchModifiesMap(expected, ue);
  }
  SECTION ("Throws exception: cyclic calls between 2 procedures") {
    auto proc1 =
        makeProcNode("callee", {makeUnaryNode(1, CALL_STMT, "caller")});
    auto proc2 =
        makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
    REQUIRE_THROWS(ue.run({proc1, proc2}));
  }
}

TEST_CASE ("Modifies Extractor: Negative case - No modifies relationships") {
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, PRINT_STMT, "predB")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, PRINT_STMT, "predA")});

  ModifiesExtractor me;
  me.run({proc1, proc2});
  auto actual = me.getStmtOrProcToVars();

  EntityMap expected = {};
  matchModifiesMap(expected, me);
}

TEST_CASE ("Modifies Extractor Test : single assign") {
  ModifiesExtractor ue;
  auto proc = makeProcNode(
      "test", {makeAssignNode(1, "vba", {"a", "b", "c", "d"}, {},
                              {"a", "+", "b", "-", "c", "/", "d"})});
  // Procedure called "test" with 1 assign stmt (1), "vba" on lhs
  ue.run({proc});
  unordered_set<std::string> varSet = {"vba"};
  EntityMap expected = {{Entity(PROC, "test"), varSet},
                        {Entity(ASSIGN_STMT, "1"), varSet}};
  matchModifiesMap(expected, ue);
}

TEST_CASE ("Modifies Extractor Test : double assign") {
  ModifiesExtractor ue;
  auto proc = makeProcNode(
      "test", {makeAssignNode(1, "var1", {"a", "b", "c", "d"}, {},
                              {"a", "+", "b", "-", "c", "/", "d"}),
               makeAssignNode(2, "var2", {"a", "b", "c", "d"}, {},
                              {"a", "+", "b", "-", "c", "/", "d"})});
  // Procedure called "test" with 1 assign stmt (1), "vba" on lhs
  ue.run({proc});
  unordered_set<std::string> varSet = {"var1", "var2"};
  unordered_set<std::string> varSet1 = {"var1"};
  unordered_set<std::string> varSet2 = {"var2"};
  EntityMap expected = {
      {Entity(PROC, "test"), varSet},
      {Entity(ASSIGN_STMT, "1"), varSet1},
      {Entity(ASSIGN_STMT, "2"), varSet2},
  };
  matchModifiesMap(expected, ue);
}

TEST_CASE (
    "Modifies Extractor Test : single if stmt with read and assign stmts") {
  ModifiesExtractor ue;
  auto proc = makeProcNode(
      "test", {makeIfNode(1, {"ab", "cd"}, {"1"},
                          {makeAssignNode(2, "vba", {"a", "b", "c", "d"}, {},
                                          {"a", "+", "b", "-", "c", "/", "d"})},
                          {makeUnaryNode(3, READ_STMT, "varA")})});
  unordered_set<std::string> set3 = {"varA"};
  unordered_set<std::string> set2 = {"vba"};
  unordered_set<std::string> set1 = {"vba", "varA"};
  EntityMap expected = {{Entity(PROC, "test"), set1},
                        {Entity(IF_STMT, "1"), set1},
                        {Entity(ASSIGN_STMT, "2"), set2},
                        {Entity(READ_STMT, "3"), set3}};
  ue.run({proc});
  matchModifiesMap(expected, ue);
}
TEST_CASE ("Modifies Extractor Test : if stmt with mixed stmts") {
  ModifiesExtractor ue;
  auto proc = makeProcNode(
      "test", {makeIfNode(1, {"ab", "cd"}, {},
                          {makeAssignNode(2, "var2", {"x"}, {}, {}),
                           makeAssignNode(3, "var3", {"y"}, {}, {})},
                          {
                              makeUnaryNode(4, PRINT_STMT, "varA"),
                              makeUnaryNode(5, READ_STMT, "varB"),
                          })});
  EntityMap expected = {{Entity(PROC, "test"), {"var2", "var3", "varB"}},
                        {Entity(IF_STMT, "1"), {"var2", "var3", "varB"}},
                        {Entity(ASSIGN_STMT, "2"), {"var2"}},
                        {Entity(ASSIGN_STMT, "3"), {"var3"}},
                        {Entity(READ_STMT, "5"), {"varB"}}};
  ue.run({proc});
  matchModifiesMap(expected, ue);
}

TEST_CASE ("Modifies Extractor Test : if stmt nested") {
  ModifiesExtractor ue;
  auto proc = makeProcNode(
      "test",
      {makeIfNode(
          1, {"ab", "cd"}, {},
          {makeAssignNode(2, "var2", {"x"}, {}, {}),
           makeAssignNode(3, "var3", {"y"}, {}, {})},
          {makeIfNode(4, {"ab"}, {}, {makeUnaryNode(5, PRINT_STMT, "varA")},
                      {makeUnaryNode(6, READ_STMT, "varB")})})});
  EntityMap expected = {{Entity(PROC, "test"), {"var2", "var3", "varB"}},
                        {Entity(IF_STMT, "1"), {"var2", "var3", "varB"}},
                        {Entity(ASSIGN_STMT, "2"), {"var2"}},
                        {Entity(ASSIGN_STMT, "3"), {"var3"}},
                        {Entity(IF_STMT, "4"), {"varB"}},
                        {Entity(READ_STMT, "6"), {"varB"}}};
  ue.run({proc});
  matchModifiesMap(expected, ue);
}

TEST_CASE ("Modifies Extractor Test : calls between 2 procedures") {
  ModifiesExtractor ue;
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, READ_STMT, "varA")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
  EntityMap expected = {
      {Entity(PROC, "callee"), {"varA"}},
      {Entity(PROC, "caller"), {"varA"}},
      {Entity(READ_STMT, "1"), {"varA"}},
      {Entity(CALL_STMT, "2"), {"varA"}},
  };
  ue.run({proc1, proc2});
  matchModifiesMap(expected, ue);
}

TEST_CASE ("Modifies Extractor Test : many nesting calls") {
  ModifiesExtractor ue;
  auto proc1 = makeProcNode("procA", {makeUnaryNode(1, READ_STMT, "varA"),
                                      makeUnaryNode(2, CALL_STMT, "procC")});
  auto proc2 = makeProcNode("procB", {makeUnaryNode(3, READ_STMT, "varB")});
  auto proc3 = makeProcNode("procC", {makeUnaryNode(4, READ_STMT, "varC"),
                                      makeUnaryNode(5, CALL_STMT, "procB"),
                                      makeUnaryNode(6, CALL_STMT, "procD")});
  auto proc4 = makeProcNode("procD", {makeUnaryNode(7, READ_STMT, "varD")});
  EntityMap expected = {
      {Entity(PROC, "procA"), {"varA", "varB", "varC", "varD"}},
      {Entity(PROC, "procB"), {"varB"}},
      {Entity(PROC, "procC"), {"varB", "varC", "varD"}},
      {Entity(PROC, "procD"), {"varD"}},
      {Entity(READ_STMT, "1"), {"varA"}},
      {Entity(CALL_STMT, "2"), {"varB", "varC", "varD"}},
      {Entity(READ_STMT, "3"), {"varB"}},
      {Entity(READ_STMT, "4"), {"varC"}},
      {Entity(CALL_STMT, "5"), {"varB"}},
      {Entity(CALL_STMT, "6"), {"varD"}},
      {Entity(READ_STMT, "7"), {"varD"}}};
  ue.run({proc1, proc2, proc3, proc4});
  matchModifiesMap(expected, ue);
}

TEST_CASE (
    "Modifies Extractor Test : cyclic calls between 2 procedures (throw)") {
  ModifiesExtractor ue;
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, CALL_STMT, "caller")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
  REQUIRE_THROWS(ue.run({proc1, proc2}));
}

TEST_CASE (
    "Modifies Extractor Test : multiple procedure calls through while stmt") {
  ModifiesExtractor ue;
  SECTION ("single layers of nesting") {
    auto proc1 = makeProcNode(
        "caller", {makeWhileNode(1, {"c"}, {"10"},
                                 {makeUnaryNode(2, READ_STMT, "var"),
                                  makeUnaryNode(3, CALL_STMT, "callee")})});
    auto proc2 = makeProcNode("callee", {makeUnaryNode(4, READ_STMT, "var2")});
    EntityMap expected = {{Entity(PROC, "caller"), {"var", "var2"}},
                          {Entity(WHILE_STMT, "1"), {"var", "var2"}},
                          {Entity(READ_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2"}},
                          {Entity(READ_STMT, "4"), {"var2"}},
                          {Entity(PROC, "callee"), {"var2"}}};
    ue.run({proc1, proc2});
    matchModifiesMap(expected, ue);
  }
  SECTION ("Multiple layers of nesting") {
    auto proc1 = makeProcNode(
        "procA", {makeWhileNode(1, {"c"}, {"10"},
                                {makeUnaryNode(2, READ_STMT, "var"),
                                 makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {
                                           makeUnaryNode(4, READ_STMT, "var2"),
                                           makeUnaryNode(5, CALL_STMT, "procC"),
                                       });
    auto proc3 = makeProcNode("procC", {makeUnaryNode(6, READ_STMT, "var3")});
    EntityMap expected = {{Entity(PROC, "procA"), {"var", "var2", "var3"}},
                          {Entity(PROC, "procB"), {"var3", "var2"}},
                          {Entity(PROC, "procC"), {"var3"}},
                          {Entity(WHILE_STMT, "1"), {"var", "var2", "var3"}},
                          {Entity(READ_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2", "var3"}},
                          {Entity(READ_STMT, "4"), {"var2"}},
                          {Entity(CALL_STMT, "5"), {"var3"}},
                          {Entity(READ_STMT, "6"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchModifiesMap(expected, ue);
  }
}

TEST_CASE (
    "Modifies Extractor Test : multiple procedure calls through if stmt") {
  ModifiesExtractor ue;
  SECTION ("single layers of nesting") {
    auto proc1 = makeProcNode(
        "caller",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, READ_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "callee")})});
    auto proc2 = makeProcNode("callee", {makeUnaryNode(4, READ_STMT, "var2")});
    EntityMap expected = {{Entity(PROC, "caller"), {"var", "var2"}},
                          {Entity(IF_STMT, "1"), {"var", "var2"}},
                          {Entity(READ_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2"}},
                          {Entity(READ_STMT, "4"), {"var2"}},
                          {Entity(PROC, "callee"), {"var2"}}};
    ue.run({proc1, proc2});
    matchModifiesMap(expected, ue);
  }
  SECTION ("Multiple layers of nesting") {
    auto proc1 = makeProcNode(
        "procA",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, READ_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {
                                           makeUnaryNode(4, READ_STMT, "var2"),
                                           makeUnaryNode(5, CALL_STMT, "procC"),
                                       });
    auto proc3 = makeProcNode("procC", {makeUnaryNode(6, READ_STMT, "var3")});
    EntityMap expected = {{Entity(PROC, "procA"), {"var", "var2", "var3"}},
                          {Entity(PROC, "procB"), {"var3", "var2"}},
                          {Entity(PROC, "procC"), {"var3"}},
                          {Entity(IF_STMT, "1"), {"var", "var2", "var3"}},
                          {Entity(READ_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2", "var3"}},
                          {Entity(READ_STMT, "4"), {"var2"}},
                          {Entity(CALL_STMT, "5"), {"var3"}},
                          {Entity(READ_STMT, "6"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchModifiesMap(expected, ue);
  }
}

TEST_CASE ("Modifies calls between 3 procedures") {
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, CALL_STMT, "trial")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
  auto proc3 = makeProcNode("trial", {makeUnaryNode(3, READ_STMT, "varA")});
  EntityMap expected = {
      {Entity(PROC, "callee"), {"varA"}}, {Entity(PROC, "caller"), {"varA"}},
      {Entity(PROC, "trial"), {"varA"}},  {Entity(CALL_STMT, "1"), {"varA"}},
      {Entity(CALL_STMT, "2"), {"varA"}}, {Entity(READ_STMT, "3"), {"varA"}},
  };
  ModifiesExtractor ue;
  ue.run({proc1, proc2, proc3});
  matchModifiesMap(expected, ue);
}

TEST_CASE ("Modifies calls between 4 procedures") {
  auto proc1 = makeProcNode("caller", {makeUnaryNode(1, CALL_STMT, "callee")});
  auto proc2 = makeProcNode("callee", {makeUnaryNode(2, CALL_STMT, "test")});
  auto proc3 = makeProcNode("test", {makeUnaryNode(3, CALL_STMT, "trial")});

  auto proc4 = makeProcNode("trial", {makeUnaryNode(4, READ_STMT, "varA")});
  EntityMap expected = {
      {Entity(PROC, "callee"), {"varA"}}, {Entity(PROC, "caller"), {"varA"}},
      {Entity(PROC, "test"), {"varA"}},   {Entity(PROC, "trial"), {"varA"}},
      {Entity(CALL_STMT, "1"), {"varA"}}, {Entity(CALL_STMT, "2"), {"varA"}},
      {Entity(CALL_STMT, "3"), {"varA"}}, {Entity(READ_STMT, "4"), {"varA"}},
  };
  ModifiesExtractor ue;
  ue.run({proc1, proc2, proc3, proc4});
  matchModifiesMap(expected, ue);
}
