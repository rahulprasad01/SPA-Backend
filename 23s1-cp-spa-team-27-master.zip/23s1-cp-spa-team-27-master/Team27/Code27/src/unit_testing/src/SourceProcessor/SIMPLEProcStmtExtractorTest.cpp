#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/ProcStmtExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

ProcStmtPair pSt(std::string proc, int stmt) {
  return std::make_pair(proc, std::to_string(stmt));
}

void checkProcStmtPairs(vector<ProcStmtPair>& expected,
                        vector<ProcStmtPair>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    REQUIRE(expected[i].first == actual[i].first);
    REQUIRE(expected[i].second == actual[i].second);
  }
}

TEST_CASE ("No Statements") {
  ProcStmtExtractor pse;
  auto proc = makeProcNode("process", {});
  pse.run({proc});
  auto actual = pse.getProcStmts();
  vector<ProcStmtPair> expected = {};
  checkProcStmtPairs(expected, actual);
}

TEST_CASE ("One Statement") {
  ProcStmtExtractor pse;
  auto proc = makeProcNode("process", {makeUnaryNode(1, READ_STMT, "varA")});
  pse.run({proc});
  auto actual = pse.getProcStmts();
  vector<ProcStmtPair> expected = {pSt("process", 1)};
  checkProcStmtPairs(expected, actual);
}

TEST_CASE ("All statement types and multiple Processes") {
  ProcStmtExtractor pse;
  auto unaryProc =
      makeProcNode("unaryProc", {makeUnaryNode(1, READ_STMT, "varA"),
                                 makeUnaryNode(2, PRINT_STMT, "varB"),
                                 makeAssignNode(3, "varC", {"x"}, {"1"}, {}),
                                 makeUnaryNode(4, CALL_STMT, "containerProg")});
  auto containerProc = makeProcNode(
      "containerProc",
      {makeIfNode(
          5, {"pred1"}, {"2"},
          {
              makeUnaryNode(6, PRINT_STMT, "varPrint"),
              makeUnaryNode(7, CALL_STMT, "Call"),
          },
          {makeWhileNode(8, {"pred2"}, {"3"},
                         {makeAssignNode(9, "var1", {"x"}, {}, {})})})});
  pse.run({unaryProc, containerProc});
  auto actual = pse.getProcStmts();
  vector<ProcStmtPair> expected = {
      pSt("unaryProc", 1),     pSt("unaryProc", 2),     pSt("unaryProc", 3),
      pSt("unaryProc", 4),     pSt("containerProc", 5), pSt("containerProc", 6),
      pSt("containerProc", 7), pSt("containerProc", 8), pSt("containerProc", 9),
  };
  checkProcStmtPairs(expected, actual);
}