#include <memory>
#include <utility>
#include "Common/Entity.h"
#include "SourceProcessor/DesignExtractor/PatternExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

// must be in the same order.
void checkAssigns(const vector<StmtLHSExpr>& expected,
                  const vector<StmtLHSExpr>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    const auto& [eStmt, eLHS, eExpr] = expected[i];
    const auto& [aStmt, aLHS, aExpr] = actual[i];
    REQUIRE(eStmt == aStmt);
    REQUIRE(eLHS == aLHS);
    REQUIRE(eExpr.size() == aExpr.size());
    for (int j = 0; j < eExpr.size(); j++) {
      REQUIRE(eExpr[j] == aExpr[j]);
    }
  }
}

// must be in the same order.
void checkContainers(const vector<StmtExpr>& expected,
                     const vector<StmtExpr>& actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    const auto& [eStmt, eVars] = expected[i];
    const auto& [aStmt, aVars] = actual[i];
    REQUIRE(eStmt == aStmt);
    REQUIRE(eVars == aVars);
  }
}

StmtLHSExpr generateAssignRecord(int stmtNum, std::string lhs,
                                 vector<std::string> fullExpr) {
  return {Entity(ASSIGN_STMT, std::to_string(stmtNum)), Entity(VAR, lhs),
          fullExpr};
}

StmtExpr generateContainerRecord(int stmtNum, EntityType type,
                                 unordered_set<RawToken> vars) {
  return {Entity(type, std::to_string(stmtNum)), vars};
}

TEST_CASE ("Pattern Extractor: One assign stmt") {
  auto assign1 = makeAssignNode(1, "x", {"v0", "v1", "v2", "v3"}, {},
                                {"v0", "+", "v1", "/", "v2", "*", "v3"});
  auto proc = makeProcNode("test", {assign1});
  PatternExtractor pe;
  pe.run({proc});
  auto actualAssign = pe.getAssign();
  vector<StmtLHSExpr> expAssign = {
      generateAssignRecord(1, "x", {"v0", "+", "v1", "/", "v2", "*", "v3"})};
  checkAssigns(expAssign, actualAssign);
  auto actualCont = pe.getContainers();
  vector<StmtExpr> expCont = {};
  checkContainers(expCont, actualCont);
}

TEST_CASE ("Pattern Extractor: Assign stmt in while") {
  auto assign1 = makeAssignNode(2, "x", {"v0", "v1", "v2", "v3"}, {},
                                {"v0", "+", "v1", "/", "v2", "*", "v3"});
  auto proc =
      makeProcNode("test", {makeWhileNode(1, {"x", "y"}, {}, {assign1})});
  PatternExtractor pe;
  pe.run({proc});
  auto actualAssign = pe.getAssign();
  vector<StmtLHSExpr> expAssign = {
      generateAssignRecord(2, "x", {"v0", "+", "v1", "/", "v2", "*", "v3"})};
  checkAssigns(expAssign, actualAssign);
  auto actualCont = pe.getContainers();
  vector<StmtExpr> expCont = {
      generateContainerRecord(1, WHILE_STMT, {"x", "y"})};
  checkContainers(expCont, actualCont);
}

TEST_CASE ("Pattern Extractor: Assign stmt in if") {
  auto assign1 = makeAssignNode(2, "x", {"v0", "v1", "v2", "v3"}, {},
                                {"v0", "+", "v1", "/", "v2", "*", "v3"});
  auto proc =
      makeProcNode("test", {makeIfNode(1, {"x", "y"}, {}, {assign1},
                                       {makeUnaryNode(3, READ_STMT, "x")})});
  PatternExtractor pe;
  pe.run({proc});
  auto actualAssign = pe.getAssign();
  vector<StmtLHSExpr> expAssign = {
      generateAssignRecord(2, "x", {"v0", "+", "v1", "/", "v2", "*", "v3"})};
  checkAssigns(expAssign, actualAssign);
  auto actualCont = pe.getContainers();
  vector<StmtExpr> expCont = {generateContainerRecord(1, IF_STMT, {"x", "y"})};
  checkContainers(expCont, actualCont);
}

TEST_CASE ("Pattern Extractor: full program") {
  auto while3 =
      makeWhileNode(3, {"i"}, {"23"},
                    {makeAssignNode(4, "x", {"x", "y"}, {}, {"x", "+", "y"}),
                     makeUnaryNode(5, CALL_STMT, "Third"),
                     makeAssignNode(6, "i", {"i"}, {"4"},
                                    {"i", "%", "(", "4", "-", "i", ")"})});
  auto if7 = makeIfNode(7, {"x"}, {},
                        {makeAssignNode(8, "x", {"x"}, {"5"}, {"x", "+", "5"})},
                        {makeAssignNode(9, "z", {}, {"2"}, {"2"})});
  auto proc = makeProcNode(
      "Second",
      {makeAssignNode(1, "x", {}, {"1"}, {"1"}),
       makeAssignNode(2, "i", {}, {"5"}, {"5"}), while3, if7,
       makeAssignNode(10, "z", {"z", "x", "i"}, {}, {"z", "*", "x", "+", "i"}),
       makeAssignNode(11, "y", {"z"}, {}, {"z"}),
       makeAssignNode(12, "x", {"x", "y", "z"}, {},
                      {"x", "%", "(", "y", "+", "z", ")"})});
  PatternExtractor pe;
  pe.run({proc});
  auto actualAssign = pe.getAssign();
  vector<StmtLHSExpr> expAssign = {
      generateAssignRecord(1, "x", {"1"}),
      generateAssignRecord(2, "i", {"5"}),
      generateAssignRecord(4, "x", {"x", "+", "y"}),
      generateAssignRecord(6, "i", {"i", "%", "(", "4", "-", "i", ")"}),
      generateAssignRecord(8, "x", {"x", "+", "5"}),
      generateAssignRecord(9, "z", {"2"}),
      generateAssignRecord(10, "z", {"z", "*", "x", "+", "i"}),
      generateAssignRecord(11, "y", {"z"}),
      generateAssignRecord(12, "x", {"x", "%", "(", "y", "+", "z", ")"}),
  };
  checkAssigns(expAssign, actualAssign);
  auto actualCont = pe.getContainers();
  vector<StmtExpr> expCont = {
      generateContainerRecord(3, WHILE_STMT, {"i"}),
      generateContainerRecord(7, IF_STMT, {"x"}),
  };
  checkContainers(expCont, actualCont);
}