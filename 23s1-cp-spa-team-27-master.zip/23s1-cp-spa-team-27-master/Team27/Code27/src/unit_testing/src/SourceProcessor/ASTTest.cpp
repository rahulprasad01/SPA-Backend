#include "SIMPLETestTools.h"
#include "catch.hpp"

TEST_CASE ("AST == operators") {
  SECTION ("Unary stmt") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")});
    auto proc2 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")});
    matchProcs(proc1, proc2);
  }
  SECTION ("Assign stmt") {
    auto proc1 = makeProcNode(
        "nameA", {makeAssignNode(1, "testVar", {"a"}, {"1"}, {"a", "+", "1"})});
    auto proc2 = makeProcNode(
        "nameA", {makeAssignNode(1, "testVar", {"a"}, {"1"}, {"a", "+", "1"})});
    matchProcs(proc1, proc2);
  }
  SECTION ("While stmt") {
    auto proc1 = makeProcNode(
        "nameA", {makeWhileNode(1, {"a"}, {"1"},
                                {makeAssignNode(2, "testVar", {"a"}, {"1"},
                                                {"a", "+", "1"})})});
    auto proc2 = makeProcNode(
        "nameA", {makeWhileNode(1, {"a"}, {"1"},
                                {makeAssignNode(2, "testVar", {"a"}, {"1"},
                                                {"a", "+", "1"})})});
    matchProcs(proc1, proc2);
  }
  SECTION ("If stmt") {
    auto proc1 = makeProcNode(
        "nameA", {makeIfNode(1, {"a"}, {"1"},
                             {makeAssignNode(2, "testVar", {"a"}, {"1"},
                                             {"a", "+", "1"})},
                             {makeUnaryNode(3, CALL_STMT, "b")})});
    auto proc2 = makeProcNode(
        "nameA", {makeIfNode(1, {"a"}, {"1"},
                             {makeAssignNode(2, "testVar", {"a"}, {"1"},
                                             {"a", "+", "1"})},
                             {makeUnaryNode(3, CALL_STMT, "b")})});
    matchProcs(proc1, proc2);
  }
  SECTION ("Nested While stmt") {
    auto proc1 = makeProcNode(
        "nameA", {makeWhileNode(
                     1, {"a"}, {},
                     {makeWhileNode(2, {"b"}, {"1"},
                                    {makeAssignNode(3, "testVar", {"a"}, {"1"},
                                                    {"a", "+", "1"})})})});
    auto proc2 = makeProcNode(
        "nameA", {makeWhileNode(
                     1, {"a"}, {},
                     {makeWhileNode(2, {"b"}, {"1"},
                                    {makeAssignNode(3, "testVar", {"a"}, {"1"},
                                                    {"a", "+", "1"})})})});
    matchProcs(proc1, proc2);
  }
}

TEST_CASE ("AST != operators") {
  SECTION ("Name of procs") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")});
    auto proc2 =
        makeProcNode("nameB", {makeUnaryNode(1, READ_STMT, "testVar")});
    auto proc3 =
        makeProcNode("nameB", {makeUnaryNode(1, READ_STMT, "testVar")});
    bool isNotSame12 = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame12);
    bool isNotSame23 = *proc3.get() != *proc2.get();
    REQUIRE_FALSE(isNotSame23);
  }
  SECTION ("Num of stmts") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar"),
                               makeUnaryNode(2, READ_STMT, "testVar")});
    auto proc2 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")});
    bool isNotSame = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("Type of stmt") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, PRINT_STMT, "testVar")});
    auto proc2 =
        makeProcNode("nameA", {makeUnaryNode(1, READ_STMT, "testVar")});
    bool isNotSame = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("Stmt num") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, PRINT_STMT, "testVar")});
    auto proc2 =
        makeProcNode("nameA", {makeUnaryNode(2, PRINT_STMT, "testVar")});
    bool isNotSame = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("Stmt type") {
    auto proc1 =
        makeProcNode("nameA", {makeUnaryNode(1, PRINT_STMT, "testVar")});
    auto proc2 = makeProcNode(
        "nameA",
        {makeAssignNode(1, {"testVar"}, {"b"}, {"1"}, {"b", "+", "1"})});
    bool isNotSame = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("stmts num") {
    auto s1 = makeUnaryNode(1, READ_STMT, "a");
    auto s2 = makeUnaryNode(2, READ_STMT, "a");
    bool isNotSame = *s1.get() != *s2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("stmts type") {
    auto s1 = makeUnaryNode(1, PRINT_STMT, "a");
    auto s2 = makeUnaryNode(1, READ_STMT, "a");
    bool isNotSame = *s1.get() != *s2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("stmts val") {
    auto s1 = makeUnaryNode(1, PRINT_STMT, "a");
    auto s2 = makeUnaryNode(1, PRINT_STMT, "b");
    bool isNotSame = *s1.get() != *s2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("consts") {
    auto c1 = makeVarNode("a");
    auto c2 = makeVarNode("b");
    bool isNotSame = *c1.get() != *c2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("consts") {
    auto c1 = makeConstNode("a");
    auto c2 = makeConstNode("b");
    bool isNotSame = *c1.get() != *c2.get();
    REQUIRE(isNotSame);
  }
  SECTION ("diff num consts") {
    auto proc1 = makeProcNode(
        "nameA", {makeWhileNode(
                     1, {"a"}, {"1"},
                     {makeWhileNode(2, {"b"}, {"1"},
                                    {makeAssignNode(3, "testVar", {"a"}, {"1"},
                                                    {"a", "+", "1"})})})});
    auto proc2 = makeProcNode(
        "nameA", {makeWhileNode(
                     1, {"a"}, {},
                     {makeWhileNode(2, {"b"}, {"1"},
                                    {makeAssignNode(3, "testVar", {"a"}, {"1"},
                                                    {"a", "+", "1"})})})});
    bool isNotSame = *proc1.get() != *proc2.get();
    REQUIRE(isNotSame);
  }
}
