#pragma once
#include <vector>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/SIMPLETokenizer.h"
#include "catch.hpp"
using std::vector;

using namespace SP;
using namespace SPA;

inline SIMPLEToken word(std::string w) {
  return SIMPLEToken(SIMPLETokenType::WORD, w);
}
inline SIMPLEToken num(std::string n) {
  return SIMPLEToken(SIMPLETokenType::NUMBER, n);
}
inline SIMPLEToken aop(std::string o) {
  return SIMPLEToken(SIMPLETokenType::ARITH_OP, o);
}
inline SIMPLEToken condop(std::string o) {
  return SIMPLEToken(SIMPLETokenType::COND_OP, o);
}
inline SIMPLEToken relop(std::string o) {
  return SIMPLEToken(SIMPLETokenType::REL_OP, o);
}
inline SIMPLEToken delim(std::string d) {
  return SIMPLEToken(SIMPLETokenType::DELIMITER, d);
}

inline vector<SIMPLEToken> procA() {
  return {
      word("procedure"), word("nameA"), delim("{"), word("read"),
      word("testVar"),   delim(";"),    delim("}"),
  };
}

inline void extend(vector<SIMPLEToken>& a, vector<SIMPLEToken> b) {
  std::copy(b.begin(), b.end(), std::back_inserter(a));
}

inline vector<SIMPLEToken> procB() {
  return {word("procedure"),
          word("nameB"),
          delim("{"),
          word("read"),
          word("testVar"),
          delim(";"),
          word("print"),
          word("testVar"),
          delim(";"),
          word("call"),
          word("someProcToBeChecked"),
          delim(";"),
          delim("}")};
}

inline vector<SIMPLEToken> procC() {
  return {word("procedure"),
          word("nameC"),
          delim("{"),
          word("if"),
          delim("("),
          condop("!"),
          delim("("),
          word("VAR"),
          relop("!="),
          num("801"),
          delim(")"),
          delim(")"),
          word("then"),
          delim("{"),
          word("print"),
          word("testVar"),
          delim(";"),
          word("call"),
          word("someProcToBeChecked"),
          delim(";"),
          delim("}"),
          word("else"),
          delim("{"),
          word("call"),
          word("anotherProc"),
          delim(";"),
          delim("}"),
          delim("}")};
}

inline vector<SIMPLEToken> procD() {
  return {word("procedure"), word("nameD"),    delim("{"),  word("while"),
          delim("("),        word("someCond"), relop("<="), word("a"),
          aop("+"),          word("b"),        delim(")"),  delim("{"),
          word("read"),      word("someCond"), delim(";"),  delim("}"),
          delim("}")};
}

inline vector<SIMPLEToken> procE() {
  return {word("procedure"), word("nameE"), delim("{"),   word("while"),
          delim("("),        delim("("),    word("a"),    relop("!="),
          num("100"),        delim(")"),    condop("&&"), delim("("),
          word("b"),         relop("<="),   num("9"),     delim(")"),
          delim(")"),        delim("{"),    word("read"), word("someCond"),
          delim(";"),        delim("}"),    delim("}")};
}

inline vector<SIMPLEToken> procF() {
  return {word("procedure"), word("nameF"), delim("{"),   word("while"),
          delim("("),        delim("("),    word("a"),    relop("!="),
          num("100"),        delim(")"),    condop("&&"), delim("("),
          word("b"),         relop("<="),   num("9"),     delim(")"),
          delim(")"),        delim("{"),    word("test"), relop("="),
          word("one"),       aop("+"),      word("two"),  aop("/"),
          num("2"),          delim(";"),    delim("}"),   delim("}")};
}

inline vector<SIMPLEToken> procG() {
  return {word("procedure"), word("nameG"),   delim("{"),   word("if"),
          delim("("),        word("a"),       relop("!="),  word("b"),
          delim(")"),        word("then"),    delim("{"),   word("a"),
          relop("="),        delim("("),      word("a"),    aop("-"),
          delim("("),        delim("("),      word("b"),    aop("+"),
          word("c"),         delim(")"),      aop("%"),     num("10"),
          delim(")"),        delim(")"),      aop("*"),     num("5"),
          delim(";"),        delim("}"),      word("else"), delim("{"),
          word("print"),     word("testVar"), delim(";"),   delim("}"),
          word("while"),     delim("("),      word("a"),    relop("<="),
          word("b"),         delim(")"),      delim("{"),   word("read"),
          word("someCond"),  delim(";"),      delim("}"),   delim("}")};
}

inline vector<SIMPLEToken> procH() {
  return {word("procedure"), word("nameH"), delim("{"),  word("while"),
          delim("("),        word("a"),     relop("!="), word("b"),
          delim(")"),        delim("{"),    word("if"),  delim("("),
          word("a"),         relop("<"),    word("b"),   delim(")"),
          word("then"),      delim("{"),    word("a"),   relop("="),
          word("a"),         aop("+"),      num("1"),    delim(";"),
          delim("}"),        word("else"),  delim("{"),  word("print"),
          word("testVar"),   delim(";"),    delim("}"),  delim("}"),
          delim("}")};
}

inline vector<SIMPLEToken> procI() {
  return {word("procedure"), word("nameI"), delim("{"),      word("if"),
          delim("("),        word("a"),     relop("!="),     word("b"),
          delim(")"),        word("then"),  delim("{"),      word("print"),
          word("a"),         delim(";"),    delim("}"),      word("else"),
          delim("{"),        word("print"), word("testVar"), delim(";"),
          delim("}"),        word("while"), delim("("),      word("a"),
          relop(">="),       word("b"),     delim(")"),      delim("{"),
          word("a"),         relop("="),    word("a"),       aop("-"),
          num("1"),          delim(";"),    delim("}"),      word("while"),
          delim("("),        word("a"),     relop("<="),     word("b"),
          delim(")"),        delim("{"),    word("if"),      delim("("),
          word("a"),         relop(">"),    num("1"),        delim(")"),
          word("then"),      delim("{"),    word("a"),       relop("="),
          word("b"),         delim(";"),    delim("}"),      word("else"),
          delim("{"),        word("print"), word("testVar"), delim(";"),
          delim("}"),        delim("}"),    delim("}")};
}

inline vector<SIMPLEToken> badNoBracketsRelExpr() {
  return {word("procedure"), word("nameF"), delim("{"),   word("while"),
          delim("("),        word("a"),     relop("!="),  num("100"),
          condop("&&"),      word("b"),     relop("<="),  num("9"),
          delim(")"),        delim("{"),    word("read"), word("someCond"),
          delim(";"),        delim("}"),    delim("}")};
}

inline vector<SIMPLEToken> badNoSemicolon() {
  return {
      word("procedure"), word("nameA"),   delim("{"),
      word("read"),      word("testVar"), delim("}"),
  };
}

inline vector<SIMPLEToken> badNoOpenBracket() {
  return {
      word("procedure"), word("nameA"), word("read"),
      word("testVar"),   delim(";"),    delim("}"),
  };
}

inline vector<SIMPLEToken> badExtraCloseBracket() {
  return {
      word("procedure"), word("nameA"), delim("{"), word("read"),
      word("testVar"),   delim(";"),    delim("}"), delim("}"),
  };
}

inline vector<SIMPLEToken> badEmptyStmtList() {
  return {
      word("procedure"),
      word("nameA"),
      delim("{"),
      delim("}"),
  };
}

inline vector<SIMPLEToken> badRelExpr() {
  return {word("procedure"), word("nameD"),    delim("{"),  word("while"),
          delim("("),        word("someCond"), relop("!="), word("a"),
          aop("=="),         word("b"),        delim(")"),  delim("{"),
          word("read"),      word("someCond"), delim(";"),  delim("}"),
          delim("}")};
}

inline vector<SIMPLEToken> badArithExpr() {
  return {word("procedure"), word("nameD"),    delim("{"),       word("while"),
          delim("("),        word("someCond"), aop("*"),         aop("+"),
          word("a"),         aop("=="),        word("b"),        delim(")"),
          delim("{"),        word("read"),     word("someCond"), delim(";"),
          delim("}"),        delim("}")};
}

inline vector<SIMPLEToken> badArithExpr2() {
  return {word("procedure"), word("nameD"),    delim("{"), word("while"),
          delim("("),        word("someCond"), word("a"),  aop("=="),
          word("b"),         delim(")"),       delim("{"), word("read"),
          word("someCond"),  delim(";"),       delim("}"), delim("}")};
}

inline void matchProcs(shared_ptr<ProcAST> expected,
                       shared_ptr<ProcAST> actual) {
  bool isValid = *actual.get() == *expected.get();
  REQUIRE(isValid);
}

inline void matchProcList(vector<shared_ptr<ProcAST>> expected,
                          vector<shared_ptr<ProcAST>> actual) {
  REQUIRE(expected.size() == actual.size());
  for (int i = 0; i < expected.size(); i++) {
    bool isValid = *(actual[i]).get() == *(expected[i]).get();
    REQUIRE(isValid);
  }
}
