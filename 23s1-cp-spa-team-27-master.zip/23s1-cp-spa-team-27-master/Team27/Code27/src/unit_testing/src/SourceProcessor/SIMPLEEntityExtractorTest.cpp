#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/EntityExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using std::unordered_map;
using std::unordered_set;
using namespace SP;

void matchEntityAttribute(
    const unordered_map<EntityAttrType, std::string>& expected,
    const Entity& entity) {
  REQUIRE(entity.attributes.size() == expected.size());
  for (const auto& [type, val] : expected) {
    REQUIRE(entity.hasAttribute(type));
    REQUIRE(entity.getAttribute(type) == val);
  }
}

void matchEntitiesAttribute(
    const vector<unordered_map<EntityAttrType, std::string>>& expected,
    const EntityExtractor& ee) {
  const auto& entities = ee.getEntities();
  REQUIRE(entities.size() == expected.size());
  for (int i = 0; i < expected.size(); i++) {
    matchEntityAttribute(expected[i], entities[i]);
  }
}

TEST_CASE ("Atrribute Tests") {
  SECTION ("Sanity Check - 1 Proc 1 Statement 1 Var") {
    EntityExtractor ee;
    auto proc = makeProcNode("test", {makeUnaryNode(1, PRINT_STMT, "varA")});
    ee.run({proc});

    matchEntityAttribute({{PROCNAME, "test"}}, ee.getEntities()[0]);

    vector<unordered_map<EntityAttrType, std::string>> map = {
        {{PROCNAME, "test"}},
        {{STMTNO, "1"}, {VARNAME, "varA"}},
        {{VARNAME, "varA"}}};

    matchEntitiesAttribute(map, ee);
  }

  SECTION ("Unary and Assign Statements") {
    EntityExtractor ee;
    auto procA = makeProcNode("procA", {makeUnaryNode(1, PRINT_STMT, "varA"),
                                        makeUnaryNode(2, READ_STMT, "varB")});
    auto procB = makeProcNode(
        "procB",
        {makeUnaryNode(3, CALL_STMT, "procA"),
         makeAssignNode(4, "varC", {"varD"}, {"40"}, {"varD", "+", "40"})});
    ee.run({procA, procB});

    vector<unordered_map<EntityAttrType, std::string>> map = {
        // procA
        {{PROCNAME, "procA"}},
        {{STMTNO, "1"}, {VARNAME, "varA"}},
        {{VARNAME, "varA"}},
        {{STMTNO, "2"}, {VARNAME, "varB"}},
        {{VARNAME, "varB"}},
        // procB
        {{PROCNAME, "procB"}},
        {{STMTNO, "3"}, {PROCNAME, "procA"}},
        {{STMTNO, "4"}},
        {{VARNAME, "varC"}},
        {{VARNAME, "varD"}},
        {{VALUE, "40"}}};

    matchEntitiesAttribute(map, ee);
  }

  SECTION ("Container Statements") {
    EntityExtractor ee;
    auto procA = makeProcNode(
        "procA",
        {makeIfNode(1, {"varA"}, {"10"}, {makeUnaryNode(2, PRINT_STMT, "varB")},
                    {makeWhileNode(3, {"varC"}, {"30"},
                                   {makeUnaryNode(4, PRINT_STMT, "varD")})})});
    ee.run({procA});

    vector<unordered_map<EntityAttrType, std::string>> map = {
        {{PROCNAME, "procA"}},
        {{STMTNO, "1"}},
        {{VARNAME, "varA"}},
        {{VALUE, "10"}},
        {{STMTNO, "2"}, {VARNAME, "varB"}},
        {{VARNAME, "varB"}},
        {{STMTNO, "3"}},
        {{VARNAME, "varC"}},
        {{VALUE, "30"}},
        {{STMTNO, "4"}, {VARNAME, "varD"}},
        {{VARNAME, "varD"}}};

    matchEntitiesAttribute(map, ee);
  }

  SECTION ("Complete check") {
    EntityExtractor ee;
    auto procA = makeProcNode("procA", {makeUnaryNode(1, PRINT_STMT, "varA"),
                                        makeUnaryNode(2, READ_STMT, "varB")});
    auto procB = makeProcNode(
        "procB",
        {makeUnaryNode(3, CALL_STMT, "procA"),
         makeAssignNode(4, "varC", {"varD"}, {"40"}, {"varD", "+", "40"})});
    auto procC = makeProcNode(
        "procC",
        {makeIfNode(5, {"varE"}, {"50"}, {makeUnaryNode(6, PRINT_STMT, "varF")},
                    {makeWhileNode(7, {"varG"}, {"70"},
                                   {makeUnaryNode(8, CALL_STMT, "procB")})})});
    ee.run({procA, procB, procC});

    vector<unordered_map<EntityAttrType, std::string>> map = {
        {{PROCNAME, "procA"}},
        {{STMTNO, "1"}, {VARNAME, "varA"}},
        {{VARNAME, "varA"}},
        {{STMTNO, "2"}, {VARNAME, "varB"}},
        {{VARNAME, "varB"}},
        {{PROCNAME, "procB"}},
        {{STMTNO, "3"}, {PROCNAME, "procA"}},
        {{STMTNO, "4"}},
        {{VARNAME, "varC"}},
        {{VARNAME, "varD"}},
        {{VALUE, "40"}},
        {{PROCNAME, "procC"}},
        {{STMTNO, "5"}},
        {{VARNAME, "varE"}},
        {{VALUE, "50"}},
        {{STMTNO, "6"}, {VARNAME, "varF"}},
        {{VARNAME, "varF"}},
        {{STMTNO, "7"}},
        {{VARNAME, "varG"}},
        {{VALUE, "70"}},
        {{STMTNO, "8"}, {PROCNAME, "procB"}}};

    matchEntitiesAttribute(map, ee);
  }
}