#include <iostream>
#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/UsesExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;
using EntityMap =
    unordered_map<Entity, unordered_set<std::string>, Entity::KeyHasher>;

void printUE(const UsesExtractor& ue) {
  auto map = ue.getStmtOrProcToVars();
  for (const auto& stmtSet : map) {
    std::cout << stmtSet.first << ": " << std::endl;
    for (const auto& vAST : stmtSet.second) {
      std::cout << vAST << ", ";
    }
    std::cout << std::endl;
  }
}

void matchUsesMap(const EntityMap& expected, const UsesExtractor& ue) {
  auto map = ue.getStmtOrProcToVars();
  REQUIRE(map.size() >= expected.size());
  for (const auto& actualStmt : map) {
    REQUIRE((expected.find(actualStmt.first) != expected.end() ||
             actualStmt.second.size() == 0));
  }
  for (const auto& stmtSet : expected) {
    const auto& set = map[stmtSet.first];
    REQUIRE(set.size() == stmtSet.second.size());
    for (const auto& var : set) {
      REQUIRE(set.find(var) != set.end());
    }
  }
}

TEST_CASE ("Uses Extractor Test") {
  UsesExtractor ue;
  SECTION ("single print stmt") {
    auto proc = makeProcNode("test", {makeUnaryNode(1, PRINT_STMT, "varA")});
    ue.run({proc});
    unordered_set<std::string> varSet = {"varA"};
    EntityMap expected = {{Entity(PROC, "test"), varSet},
                          {Entity(PRINT_STMT, "1"), varSet}};
    matchUsesMap(expected, ue);
  }
  SECTION ("single assign stmt") {
    auto proc = makeProcNode(
        "test", {makeAssignNode(
                    1, "vba", {"a", "b", "c", "d"}, {"3", "10"},
                    {"a", "+", "3", "-", "b", "/", "c", "+", "10", "*", "d"})});
    ue.run({proc});
    unordered_set<std::string> varSet = {"a", "b", "c", "d"};
    EntityMap expected = {{Entity(PROC, "test"), varSet},
                          {Entity(ASSIGN_STMT, "1"), varSet}};
    matchUsesMap(expected, ue);
  }
  SECTION ("single if stmt") {
    auto proc = makeProcNode(
        "test",
        {makeIfNode(1, {"ab", "cd"}, {},
                    {makeAssignNode(2, "vba", {"a", "b", "c", "d"}, {"3", "10"},
                                    {"a", "+", "3", "-", "b", "/", "c", "+",
                                     "10", "*", "d"})},
                    {makeUnaryNode(3, PRINT_STMT, "varA")})});
    unordered_set<std::string> set3 = {"varA"};
    unordered_set<std::string> set2 = {"a", "b", "c", "d"};
    unordered_set<std::string> set1 = {"ab", "cd", "varA", "a", "b", "c", "d"};
    unordered_set<std::string> varSet = {"varA"};
    EntityMap expected = {
        {Entity(PROC, "test"), set1},
        {Entity(IF_STMT, "1"), set1},
        {Entity(ASSIGN_STMT, "2"), set2},
        {Entity(PRINT_STMT, "3"), set3},
    };
    ue.run({proc});
    matchUsesMap(expected, ue);
  }
  SECTION ("if stmt with mixed stmts") {
    auto proc = makeProcNode(
        "test", {makeIfNode(1, {"ab", "cd"}, {},
                            {makeAssignNode(2, "var2", {"x"}, {"3", "10"},
                                            {"3", "/", "x", "+", "10"}),
                             makeAssignNode(3, "var3", {"y"}, {"3", "10"},
                                            {"3", "/", "y", "+", "10"})},
                            {
                                makeUnaryNode(4, PRINT_STMT, "varA"),
                                makeUnaryNode(5, READ_STMT, "varA"),
                            })});
    EntityMap expected = {
        {Entity(PROC, "test"), {"ab", "cd", "x", "y", "varA"}},
        {Entity(IF_STMT, "1"), {"ab", "cd", "x", "y", "varA"}},
        {Entity(ASSIGN_STMT, "2"), {"x"}},
        {Entity(ASSIGN_STMT, "3"), {"y"}},
        {Entity(PRINT_STMT, "4"), {"varA"}}};
    ue.run({proc});
    matchUsesMap(expected, ue);
  }
  SECTION ("if stmt nested") {
    auto proc = makeProcNode(
        "test",
        {makeIfNode(
            1, {"ab", "cd"}, {},
            {makeAssignNode(2, "var2", {"x"}, {"3", "10"},
                            {"3", "/", "x", "+", "10"}),
             makeAssignNode(3, "var3", {"y"}, {"3", "10"},
                            {"3", "/", "y", "+", "10"})},
            {makeIfNode(4, {"ab"}, {}, {makeUnaryNode(5, PRINT_STMT, "varA")},
                        {makeUnaryNode(6, READ_STMT, "varB")})})});
    EntityMap expected = {
        {Entity(PROC, "test"), {"ab", "cd", "x", "y", "varA"}},
        {Entity(IF_STMT, "1"), {"ab", "cd", "x", "y", "varA"}},
        {Entity(ASSIGN_STMT, "2"), {"x"}},
        {Entity(ASSIGN_STMT, "3"), {"y"}},
        {Entity(IF_STMT, "4"), {"ab", "varA"}},
        {Entity(PRINT_STMT, "5"), {"varA"}}};
    ue.run({proc});
    matchUsesMap(expected, ue);
  }
  SECTION ("calls between 2 procedures") {
    auto proc1 = makeProcNode("callee", {makeUnaryNode(1, PRINT_STMT, "varA")});
    auto proc2 =
        makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
    EntityMap expected = {
        {Entity(PROC, "callee"), {"varA"}},
        {Entity(PROC, "caller"), {"varA"}},
        {Entity(PRINT_STMT, "1"), {"varA"}},
        {Entity(CALL_STMT, "2"), {"varA"}},
    };
    ue.run({proc1, proc2});
    matchUsesMap(expected, ue);
  }
  SECTION ("Throws exception: cyclic calls between 2 procedures") {
    auto proc1 =
        makeProcNode("callee", {makeUnaryNode(1, CALL_STMT, "caller")});
    auto proc2 =
        makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
    REQUIRE_THROWS(ue.run({proc1, proc2}));
  }
}

TEST_CASE (
    "Uses Extractor Test : multiple procedure calls through while stmt") {
  UsesExtractor ue;
  SECTION ("Calls chain max length = 1") {
    auto proc1 = makeProcNode(
        "caller", {makeWhileNode(1, {"c"}, {"10"},
                                 {makeUnaryNode(2, PRINT_STMT, "var"),
                                  makeUnaryNode(3, CALL_STMT, "callee")})});
    auto proc2 = makeProcNode("callee", {makeUnaryNode(4, PRINT_STMT, "var2")});
    EntityMap expected = {{Entity(PROC, "caller"), {"var", "var2", "c"}},
                          {Entity(WHILE_STMT, "1"), {"var", "var2", "c"}},
                          {Entity(PRINT_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2"}},
                          {Entity(PRINT_STMT, "4"), {"var2"}},
                          {Entity(PROC, "callee"), {"var2"}}};
    ue.run({proc1, proc2});
    matchUsesMap(expected, ue);
  }
  SECTION ("Calls chain max length = 2") {
    auto proc1 = makeProcNode(
        "procA", {makeWhileNode(1, {"c"}, {"10"},
                                {makeUnaryNode(2, PRINT_STMT, "var"),
                                 makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {
                                           makeUnaryNode(4, PRINT_STMT, "var2"),
                                           makeUnaryNode(5, CALL_STMT, "procC"),
                                       });
    auto proc3 = makeProcNode("procC", {makeUnaryNode(6, PRINT_STMT, "var3")});
    EntityMap expected = {
        {Entity(PROC, "procA"), {"var", "var2", "var3", "c"}},
        {Entity(PROC, "procB"), {"var3", "var2"}},
        {Entity(PROC, "procC"), {"var3"}},
        {Entity(WHILE_STMT, "1"), {"var", "var2", "var3", "c"}},
        {Entity(PRINT_STMT, "2"), {"var"}},
        {Entity(CALL_STMT, "3"), {"var2", "var3"}},
        {Entity(PRINT_STMT, "4"), {"var2"}},
        {Entity(CALL_STMT, "5"), {"var3"}},
        {Entity(PRINT_STMT, "6"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
  SECTION ("Calls chain max length = 2; nested while clause") {
    auto proc1 = makeProcNode(
        "procA", {makeWhileNode(1, {"c"}, {"10"},
                                {makeUnaryNode(2, PRINT_STMT, "var"),
                                 makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode(
        "procB", {makeWhileNode(4, {"x", "y"}, {},
                                {makeUnaryNode(5, PRINT_STMT, "var2"),
                                 makeUnaryNode(6, CALL_STMT, "procC")})});
    auto proc3 = makeProcNode("procC", {makeUnaryNode(7, PRINT_STMT, "var3")});
    EntityMap expected = {
        {Entity(PROC, "procA"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PROC, "procB"), {"var3", "var2", "x", "y"}},
        {Entity(PROC, "procC"), {"var3"}},
        {Entity(WHILE_STMT, "1"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PRINT_STMT, "2"), {"var"}},
        {Entity(CALL_STMT, "3"), {"var2", "var3", "x", "y"}},
        {Entity(WHILE_STMT, "4"), {"var2", "var3", "x", "y"}},
        {Entity(PRINT_STMT, "5"), {"var2"}},
        {Entity(CALL_STMT, "6"), {"var3"}},
        {Entity(PRINT_STMT, "7"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
  SECTION ("Calls chain max length = 2; deeply nested while clause") {
    auto proc1 = makeProcNode(
        "procA", {makeWhileNode(1, {"c"}, {"10"},
                                {makeUnaryNode(2, PRINT_STMT, "var"),
                                 makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {makeUnaryNode(4, PRINT_STMT, "var2"),
                                        makeUnaryNode(5, CALL_STMT, "procC")});
    auto proc3 = makeProcNode(
        "procC", {makeWhileNode(6, {"x", "y"}, {},
                                {makeUnaryNode(7, PRINT_STMT, "var3")})});
    EntityMap expected = {
        {Entity(PROC, "procA"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PROC, "procB"), {"var3", "var2", "x", "y"}},
        {Entity(PROC, "procC"), {"var3", "x", "y"}},
        {Entity(WHILE_STMT, "1"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PRINT_STMT, "2"), {"var"}},
        {Entity(CALL_STMT, "3"), {"var2", "var3", "x", "y"}},
        {Entity(PRINT_STMT, "4"), {"var2"}},
        {Entity(CALL_STMT, "5"), {"var3", "x", "y"}},
        {Entity(WHILE_STMT, "6"), {"var3", "x", "y"}},
        {Entity(PRINT_STMT, "7"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
}

TEST_CASE ("Uses Extractor Test : multiple procedure calls through if stmt") {
  UsesExtractor ue;
  SECTION ("calls chain max length = 1") {
    auto proc1 = makeProcNode(
        "caller",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, PRINT_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "callee")})});
    auto proc2 = makeProcNode("callee", {makeUnaryNode(4, PRINT_STMT, "var2")});
    EntityMap expected = {{Entity(PROC, "caller"), {"var", "var2", "c"}},
                          {Entity(IF_STMT, "1"), {"var", "var2", "c"}},
                          {Entity(PRINT_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2"}},
                          {Entity(PRINT_STMT, "4"), {"var2"}},
                          {Entity(PROC, "callee"), {"var2"}}};
    ue.run({proc1, proc2});
    matchUsesMap(expected, ue);
  }
  SECTION ("calls chain max length = 2") {
    auto proc1 = makeProcNode(
        "procA",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, PRINT_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {
                                           makeUnaryNode(4, PRINT_STMT, "var2"),
                                           makeUnaryNode(5, CALL_STMT, "procC"),
                                       });
    auto proc3 = makeProcNode("procC", {makeUnaryNode(6, PRINT_STMT, "var3")});
    EntityMap expected = {{Entity(PROC, "procA"), {"var", "var2", "var3", "c"}},
                          {Entity(PROC, "procB"), {"var3", "var2"}},
                          {Entity(PROC, "procC"), {"var3"}},
                          {Entity(IF_STMT, "1"), {"var", "var2", "var3", "c"}},
                          {Entity(PRINT_STMT, "2"), {"var"}},
                          {Entity(CALL_STMT, "3"), {"var2", "var3"}},
                          {Entity(PRINT_STMT, "4"), {"var2"}},
                          {Entity(CALL_STMT, "5"), {"var3"}},
                          {Entity(PRINT_STMT, "6"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
  SECTION ("Calls chain max length = 2; nested if clause") {
    auto proc1 = makeProcNode(
        "procA",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, PRINT_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode(
        "procB",
        {makeIfNode(4, {"x", "y"}, {}, {makeUnaryNode(5, PRINT_STMT, "var2")},
                    {makeUnaryNode(6, CALL_STMT, "procC")})});
    auto proc3 = makeProcNode("procC", {makeUnaryNode(7, PRINT_STMT, "var3")});
    EntityMap expected = {
        {Entity(PROC, "procA"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PROC, "procB"), {"var3", "var2", "x", "y"}},
        {Entity(PROC, "procC"), {"var3"}},
        {Entity(IF_STMT, "1"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PRINT_STMT, "2"), {"var"}},
        {Entity(CALL_STMT, "3"), {"var2", "var3", "x", "y"}},
        {Entity(IF_STMT, "4"), {"var2", "var3", "x", "y"}},
        {Entity(PRINT_STMT, "5"), {"var2"}},
        {Entity(CALL_STMT, "6"), {"var3"}},
        {Entity(PRINT_STMT, "7"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
  SECTION ("Calls chain max length = 2; deeply nested if clause") {
    auto proc1 = makeProcNode(
        "procA",
        {makeIfNode(1, {"c"}, {"10"}, {makeUnaryNode(2, PRINT_STMT, "var")},
                    {makeUnaryNode(3, CALL_STMT, "procB")})});
    auto proc2 = makeProcNode("procB", {makeUnaryNode(4, PRINT_STMT, "var2"),
                                        makeUnaryNode(5, CALL_STMT, "procC")});
    auto proc3 = makeProcNode(
        "procC",
        {makeIfNode(6, {"x", "y"}, {}, {makeUnaryNode(7, PRINT_STMT, "var3")},
                    {makeUnaryNode(8, READ_STMT, "var3")})});
    EntityMap expected = {
        {Entity(PROC, "procA"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PROC, "procB"), {"var3", "var2", "x", "y"}},
        {Entity(PROC, "procC"), {"var3", "x", "y"}},
        {Entity(IF_STMT, "1"), {"var", "var2", "var3", "c", "x", "y"}},
        {Entity(PRINT_STMT, "2"), {"var"}},
        {Entity(CALL_STMT, "3"), {"var2", "var3", "x", "y"}},
        {Entity(PRINT_STMT, "4"), {"var2"}},
        {Entity(CALL_STMT, "5"), {"var3", "x", "y"}},
        {Entity(IF_STMT, "6"), {"var3", "x", "y"}},
        {Entity(PRINT_STMT, "7"), {"var3"}}};
    ue.run({proc1, proc2, proc3});
    matchUsesMap(expected, ue);
  }
}

TEST_CASE ("Uses Extractor: Negative case - No uses relationships") {
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, READ_STMT, "predB")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, READ_STMT, "predA")});

  UsesExtractor ue;
  ue.run({proc1, proc2});
  // Testing a scenario with no uses relationships

  EntityMap expected = {};
  matchUsesMap(expected, ue);
}

TEST_CASE ("Uses calls between 3 procedures") {
  auto proc1 = makeProcNode("callee", {makeUnaryNode(1, CALL_STMT, "trial")});
  auto proc2 = makeProcNode("caller", {makeUnaryNode(2, CALL_STMT, "callee")});
  auto proc3 = makeProcNode("trial", {makeUnaryNode(3, PRINT_STMT, "varA")});
  EntityMap expected = {
      {Entity(PROC, "callee"), {"varA"}}, {Entity(PROC, "caller"), {"varA"}},
      {Entity(PROC, "trial"), {"varA"}},  {Entity(CALL_STMT, "1"), {"varA"}},
      {Entity(CALL_STMT, "2"), {"varA"}}, {Entity(PRINT_STMT, "3"), {"varA"}},
  };
  UsesExtractor ue;
  ue.run({proc1, proc2, proc3});
  matchUsesMap(expected, ue);
}

TEST_CASE ("Uses calls between 4 procedures") {
  auto proc1 = makeProcNode("caller", {makeUnaryNode(1, CALL_STMT, "callee")});
  auto proc2 = makeProcNode("callee", {makeUnaryNode(2, CALL_STMT, "test")});
  auto proc3 = makeProcNode("test", {makeUnaryNode(3, CALL_STMT, "trial")});
  auto proc4 = makeProcNode("trial", {makeUnaryNode(4, PRINT_STMT, "varA")});

  EntityMap expected = {
      {Entity(PROC, "callee"), {"varA"}}, {Entity(PROC, "caller"), {"varA"}},
      {Entity(PROC, "test"), {"varA"}},   {Entity(PROC, "trial"), {"varA"}},
      {Entity(CALL_STMT, "1"), {"varA"}}, {Entity(CALL_STMT, "2"), {"varA"}},
      {Entity(CALL_STMT, "3"), {"varA"}}, {Entity(PRINT_STMT, "4"), {"varA"}},
  };
  UsesExtractor ue;
  ue.run({proc1, proc2, proc3, proc4});
  matchUsesMap(expected, ue);
}