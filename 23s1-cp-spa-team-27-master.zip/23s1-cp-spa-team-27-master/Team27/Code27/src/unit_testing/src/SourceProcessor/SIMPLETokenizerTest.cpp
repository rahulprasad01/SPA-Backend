#include <iostream>
#include "SourceProcessor/SIMPLETokenizer.h"
#include "catch.hpp"

using namespace SP;
using namespace SPA;

void print_tokens(const vector<SIMPLEToken>& tokens) {
  for (const auto& tok : tokens) {
    std::cerr << "'" << tok.value << "', ";
  }
  std::cerr << std::endl;
}

void check_tokens(const vector<SIMPLEToken>& tokens,
                  const vector<std::string>& texts,
                  const vector<SIMPLETokenType>& types) {
  for (int i = 0; i < texts.size(); i++) {
    REQUIRE(tokens[i].type == types[i]);
    REQUIRE(tokens[i].value == texts[i]);
  }
}

TEST_CASE ("SIMPLEToken constructor") {
  SIMPLETokenType type = SIMPLETokenType::WHITESPACE;
  SIMPLEToken token{type, " "};
  REQUIRE(token.value == " ");
  REQUIRE(token.type == SIMPLETokenType::WHITESPACE);
}

TEST_CASE ("Tokenizer: Valid SIMPLE") {
  using S = SIMPLETokenType;
  SIMPLETokenizer sptokenizer;
  SECTION ("Procedure declaration") {
    vector<SIMPLEToken> tokens =
        sptokenizer.tokenize("procedure { read c92sdfhj; }");
    vector<std::string> texts = {"procedure", "{", "read",
                                 "c92sdfhj",  ";", "}"};
    vector<SIMPLETokenType> types = {S::WORD, S::DELIMITER, S::WORD,
                                     S::WORD, S::DELIMITER, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Conditionals") {
    vector<SIMPLEToken> tokens =
        sptokenizer.tokenize("while (x!= 23/y) {call help; }");
    vector<std::string> texts = {"while", "(", "x",    "!=",   "23", "/", "y",
                                 ")",     "{", "call", "help", ";",  "}"};
    vector<SIMPLETokenType> types = {
        S::WORD,     S::DELIMITER, S::WORD,      S::REL_OP,    S::NUMBER,
        S::ARITH_OP, S::WORD,      S::DELIMITER, S::DELIMITER, S::WORD,
        S::WORD,     S::DELIMITER, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Relations 1") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("(23 < x10)");
    vector<std::string> texts = {"(", "23", "<", "x10", ")"};
    vector<SIMPLETokenType> types = {S::DELIMITER, S::NUMBER, S::REL_OP,
                                     S::WORD, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Relations 2 (Negation)") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("!(x05 >= 11)");
    vector<std::string> texts = {"!", "(", "x05", ">=", "11", ")"};
    vector<SIMPLETokenType> types = {S::COND_OP, S::DELIMITER, S::WORD,
                                     S::REL_OP,  S::NUMBER,    S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Relops and Condops") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("!(a != b) && (c == d)");
    vector<std::string> texts = {"!",  "(", "a", "!=", "b", ")",
                                 "&&", "(", "c", "==", "d", ")"};
    vector<SIMPLETokenType> types = {
        S::COND_OP, S::DELIMITER, S::WORD, S::REL_OP, S::WORD, S::DELIMITER,
        S::COND_OP, S::DELIMITER, S::WORD, S::REL_OP, S::WORD, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Relops and Condops (No spaces)") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("!(a!=b)&&(c==d)");
    vector<std::string> texts = {"!",  "(", "a", "!=", "b", ")",
                                 "&&", "(", "c", "==", "d", ")"};
    vector<SIMPLETokenType> types = {
        S::COND_OP, S::DELIMITER, S::WORD, S::REL_OP, S::WORD, S::DELIMITER,
        S::COND_OP, S::DELIMITER, S::WORD, S::REL_OP, S::WORD, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("Long assign statement") {
    vector<SIMPLEToken> tokens =
        sptokenizer.tokenize("a1 = a + b / ((c % d));");
    vector<std::string> texts = {"a1", "=", "a", "+", "b", "/", "(",
                                 "(",  "c", "%", "d", ")", ")", ";"};
    vector<SIMPLETokenType> types = {
        S::WORD,     S::REL_OP,    S::WORD,      S::ARITH_OP, S::WORD,
        S::ARITH_OP, S::DELIMITER, S::DELIMITER, S::WORD,     S::ARITH_OP,
        S::WORD,     S::DELIMITER, S::DELIMITER, S::DELIMITER};
    check_tokens(tokens, texts, types);
  };
  SECTION ("Long assign statement interspersed missing spaces and numbers") {
    vector<SIMPLEToken> tokens =
        sptokenizer.tokenize("a4=(random -45) % (x * (y))/ procedure;");
    vector<std::string> texts = {"a4", "=", "(", "random", "-",         "45",
                                 ")",  "%", "(", "x",      "*",         "(",
                                 "y",  ")", ")", "/",      "procedure", ";"};
    vector<SIMPLETokenType> types = {
        S::WORD,     S::REL_OP,    S::DELIMITER, S::WORD,      S::ARITH_OP,
        S::NUMBER,   S::DELIMITER, S::ARITH_OP,  S::DELIMITER, S::WORD,
        S::ARITH_OP, S::DELIMITER, S::WORD,      S::DELIMITER, S::DELIMITER,
        S::ARITH_OP, S::WORD,      S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("(x > 0)") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("while (x > 0)");
    vector<std::string> texts = {"while", "(", "x", ">", "0", ")"};
    vector<SIMPLETokenType> types = {S::WORD,   S::DELIMITER, S::WORD,
                                     S::REL_OP, S::NUMBER,    S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
}

TEST_CASE ("Valid tokens in Invalid SIMPLE") {
  using S = SIMPLETokenType;
  SIMPLETokenizer sptokenizer;
  SECTION ("!==") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("!==");
    vector<std::string> texts = {"!=", "="};
    vector<SIMPLETokenType> types = {S::REL_OP, S::REL_OP};
    check_tokens(tokens, texts, types);
  }
  SECTION ("=!=") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("=!=");
    vector<std::string> texts = {"=", "!="};
    vector<SIMPLETokenType> types = {S::REL_OP, S::REL_OP};
    check_tokens(tokens, texts, types);
  }
  SECTION ("==!") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("==!");
    vector<std::string> texts = {"==", "!"};
    vector<SIMPLETokenType> types = {S::REL_OP, S::COND_OP};
    check_tokens(tokens, texts, types);
  }
  SECTION ("=!") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("=!");
    vector<std::string> texts = {"=", "!"};
    vector<SIMPLETokenType> types = {S::REL_OP, S::COND_OP};
    check_tokens(tokens, texts, types);
  }
  SECTION ("=!(") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("=!(");
    vector<std::string> texts = {"=", "!", "("};
    vector<SIMPLETokenType> types = {S::REL_OP, S::COND_OP, S::DELIMITER};
    check_tokens(tokens, texts, types);
  }
  SECTION ("1b") {
    vector<SIMPLEToken> tokens = sptokenizer.tokenize("1b");
    vector<std::string> texts = {"1", "b"};
    vector<SIMPLETokenType> types = {S::NUMBER, S::WORD};
    check_tokens(tokens, texts, types);
  }
}

TEST_CASE ("Invalid SIMPLE") {
  SIMPLETokenizer sptokenizer;
  REQUIRE_THROWS(sptokenizer.tokenize("001"));
  REQUIRE_THROWS(sptokenizer.tokenize(","));
  REQUIRE_THROWS(sptokenizer.tokenize(":"));
  REQUIRE_THROWS(sptokenizer.tokenize("_"));
  REQUIRE_THROWS(sptokenizer.tokenize("|"));
  REQUIRE_THROWS(sptokenizer.tokenize("&"));
}