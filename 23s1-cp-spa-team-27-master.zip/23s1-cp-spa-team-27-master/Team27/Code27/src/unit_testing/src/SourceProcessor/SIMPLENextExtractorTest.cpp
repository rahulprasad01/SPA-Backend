#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/NextExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

NextPair nextpair(int s1, int s2) {
  return std::make_pair(std::to_string(s1), std::to_string(s2));
}

// checks same pairs
void checkNextPairs(vector<NextPair>& expected, vector<NextPair>& actual) {
  REQUIRE(expected.size() == actual.size());
  sort(expected.begin(), expected.end());
  sort(actual.begin(), actual.end());
  for (int i = 0; i < expected.size(); i++) {
    REQUIRE(expected[i].first == actual[i].first);
    REQUIRE(expected[i].second == actual[i].second);
  }
}

TEST_CASE ("Next Extractor: While nested structure") {
  auto whileStmt =
      makeWhileNode(1, {"pred"}, {"1"},
                    {makeWhileNode(2, {"pred"}, {"2"},
                                   {makeUnaryNode(3, READ_STMT, "varA")})});
  auto proc = makeProcNode("process", {whileStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 3), nextpair(3, 2),
                               nextpair(2, 1)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: If nested structure") {
  auto whileStmt =
      makeIfNode(1, {"pred"}, {"1"},
                 {makeWhileNode(2, {"pred"}, {"2"},
                                {makeUnaryNode(3, READ_STMT, "varA")})},
                 {makeUnaryNode(4, CALL_STMT, "proc2")});
  auto proc =
      makeProcNode("process", {whileStmt, makeUnaryNode(5, READ_STMT, "varB")});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 3), nextpair(3, 2),
                               nextpair(1, 4), nextpair(4, 5), nextpair(2, 5)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Multiple if/else nested structure") {
  auto pred = makeVarNode("pred");
  auto ifStmt = makeIfNode(
      1, {"pred"}, {"1"},
      {makeWhileNode(
          2, {"pred"}, {"1"},
          {makeIfNode(3, {"another"}, {"1"},
                      {makeAssignNode(4, "lhs", {"rhs", "v2"}, {"1"},
                                      {"rhs", "*", "1", "/ ", "v2"})},
                      {makeUnaryNode(5, PRINT_STMT, "v2")})})},
      {makeIfNode(6, {"pred"}, {"1"}, {makeUnaryNode(7, READ_STMT, "rhs")},
                  {makeUnaryNode(8, CALL_STMT, "proc2")})});
  auto proc = makeProcNode("process", {ifStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 3), nextpair(3, 4),
                               nextpair(3, 5), nextpair(5, 2), nextpair(4, 2),
                               nextpair(1, 6), nextpair(6, 7), nextpair(6, 8)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Multiple procedures") {
  auto pA = makeProcNode("procA", {makeUnaryNode(1, CALL_STMT, "procB")});
  auto pB = makeProcNode("procB", {makeUnaryNode(2, READ_STMT, "procA")});
  NextExtractor pe;
  pe.run({pA, pB});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Simple Sequential Statements") {
  auto proc =
      makeProcNode("process", {makeAssignNode(1, "x", {"var1"}, {"3", "10"},
                                              {"3", "/", "var1", "+", "10"}),
                               makeAssignNode(2, "y", {"var2"}, {"3", "10"},
                                              {"3", "/", "var2", "+", "10"})});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Single If Statement") {
  auto ifStmt = makeIfNode(1, {"pred"}, {"1"},
                           {makeAssignNode(2, "x", {"var1"}, {"3", "10"},
                                           {"3", "/", "var1", "+", "10"})},
                           {makeUnaryNode(3, PRINT_STMT, "v2")});
  auto proc = makeProcNode("process", {ifStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(1, 3)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Single While Loop") {
  auto whileStmt =
      makeWhileNode(1, {"pred"}, {"1"},
                    {makeAssignNode(2, "x", {"var1"}, {"3", "10"},
                                    {"3", "/", "var1", "+", "10"})});
  auto proc = makeProcNode("process", {whileStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 1)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: No Next Relationships") {
  auto proc =
      makeProcNode("process", {makeAssignNode(1, "x", {"var1"}, {"3", "10"},
                                              {"3", "/", "var1", "+", "10"})});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  REQUIRE(actual.empty());
}

TEST_CASE ("Next Extractor: Complex Control Flow") {
  auto ifStmt = makeIfNode(
      1, {"pred"}, {"1"},
      {makeWhileNode(2, {"pred"}, {"2"},
                     {makeIfNode(3, {"another"}, {"1"},
                                 {makeAssignNode(4, "lhs", {"rhs", "v2"}, {"1"},
                                                 {"rhs", "*", "1", "/", "v2"})},
                                 {makeUnaryNode(5, PRINT_STMT, "v2")})})},
      {});
  auto proc = makeProcNode("process", {ifStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 3), nextpair(3, 4),
                               nextpair(3, 5), nextpair(5, 2), nextpair(4, 2)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Circular Next Relationships") {
  auto whileStmt =
      makeWhileNode(1, {"xy"}, {"1"},
                    {makeAssignNode(2, "x", {"var1"}, {"4", "11"},
                                    {"4", "/", "var2", "+", "11"})});
  auto proc = makeProcNode("process", {whileStmt});
  NextExtractor pe;
  pe.run({proc});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {nextpair(1, 2), nextpair(2, 1)};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: No Next relations across procedures") {
  auto proc1 =
      makeProcNode("proc1", {makeAssignNode(1, "x", {"var1"}, {"3", "10"},
                                            {"3", "/", "var1", "+", "10"})});
  auto proc2 =
      makeProcNode("proc2", {makeAssignNode(2, "y", {"var2"}, {"3", "10"},
                                            {"3", "/", "var2", "+", "10"})});
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(3, READ_STMT, "var3")});

  NextExtractor pe;
  pe.run({proc1, proc2, proc3});
  auto actual = pe.getNexts();
  vector<NextPair> expected = {};
  checkNextPairs(expected, actual);
}

TEST_CASE ("Next Extractor: Large Program") {
  // Procedure 1: Nested if-else and while loop
  auto ifStmt1 = makeIfNode(1, {}, {}, {makeUnaryNode(2, READ_STMT, "var1")},
                            {makeUnaryNode(3, CALL_STMT, "proc2")});
  auto whileStmt1 = makeWhileNode(4, {}, {}, {ifStmt1});
  auto proc1 = makeProcNode("proc1", {whileStmt1});

  // Procedure 2: Nested while loop
  auto whileStmt2 =
      makeWhileNode(5, {}, {}, {makeUnaryNode(6, PRINT_STMT, "var2")});
  auto proc2 = makeProcNode("proc2", {whileStmt2});

  // Procedure 3: Call to other procedures
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(7, CALL_STMT, "proc1"),
                                      makeUnaryNode(8, CALL_STMT, "proc2")});

  vector<shared_ptr<ProcAST>> procs = {proc1, proc2, proc3};

  NextExtractor pe;
  pe.run(procs);
  auto actual = pe.getNexts();

  vector<NextPair> expected = {

      nextpair(1, 2), nextpair(4, 1), nextpair(2, 4), nextpair(1, 3),
      nextpair(5, 6), nextpair(6, 5), nextpair(3, 4), nextpair(7, 8)};

  checkNextPairs(expected, actual);
}

TEST_CASE (
    "Next Extractor: No Next relations across procedures with Calls "
    "relations") {
  // Procedure 1: Calls Procedure 2 and Procedure 3
  auto proc1 = makeProcNode("proc1", {makeUnaryNode(1, CALL_STMT, "proc2"),
                                      makeUnaryNode(2, CALL_STMT, "proc3")});

  // Procedure 2: Calls Procedure 3
  auto proc2 = makeProcNode("proc2", {makeUnaryNode(3, CALL_STMT, "proc3")});

  // Procedure 3: Calls Procedure 4
  auto proc3 = makeProcNode("proc3", {makeUnaryNode(4, CALL_STMT, "proc4")});

  // Procedure 4: No calls
  auto proc4 = makeProcNode("proc4", {makeUnaryNode(5, READ_STMT, "var")});

  NextExtractor pe;
  pe.run({proc1, proc2, proc3, proc4});
  auto actual = pe.getNexts();

  vector<NextPair> expected = {nextpair(1, 2)};

  checkNextPairs(expected, actual);
}
