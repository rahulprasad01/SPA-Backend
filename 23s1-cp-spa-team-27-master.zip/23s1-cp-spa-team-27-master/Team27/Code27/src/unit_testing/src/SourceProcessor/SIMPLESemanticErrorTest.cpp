#include <memory>
#include <utility>
#include "SourceProcessor/AST.h"
#include "SourceProcessor/DesignExtractor/SemanticErrorExtractor.h"
#include "catch.hpp"

using std::make_shared;
using std::shared_ptr;
using namespace SP;

ProcPair procPair(int s1, int s2) {
  return std::make_pair(std::to_string(s1), std::to_string(s2));
}

shared_ptr<ProcAST> help() {
  auto whileStmt = makeWhileNode(
      1, {"pred"}, {},
      {makeWhileNode(2, {"pred"}, {}, {makeUnaryNode(3, READ_STMT, "varA")})});
  return makeProcNode("help", {whileStmt});
}

shared_ptr<ProcAST> process() {
  auto readStmt1 = makeUnaryNode(1, READ_STMT, "pred");
  auto printStmt2 = makeUnaryNode(2, PRINT_STMT, "varB");
  auto whileStmt3 =
      makeWhileNode(3, {"pred1"}, {},
                    {
                        makeUnaryNode(4, CALL_STMT, "help"),
                        makeWhileNode(5, {"pred2"}, {},
                                      {makeUnaryNode(6, PRINT_STMT, "varC")}),
                    });
  return makeProcNode("process", {readStmt1, printStmt2, whileStmt3});
}

shared_ptr<ProcAST> procX() {
  return makeProcNode("procX", {makeUnaryNode(1, CALL_STMT, "procY")});
}

shared_ptr<ProcAST> procY() {
  auto whileStmt =
      makeWhileNode(1, {"pred"}, {}, {makeUnaryNode(2, CALL_STMT, "procZ")});
  return makeProcNode("procY", {whileStmt});
}
shared_ptr<ProcAST> procZ() {
  return makeProcNode("procZ", {
                                   makeUnaryNode(1, READ_STMT, "varA"),
                                   makeUnaryNode(2, CALL_STMT, "procX"),
                               });
}

TEST_CASE ("Semantic Error: No error") {
  SemanticErrorExtractor see;
  SECTION ("solo") {
    vector<shared_ptr<ProcAST>> proclist0 = {help()};
    REQUIRE_NOTHROW(see.run(proclist0));
  }
  SECTION ("forward order") {
    vector<shared_ptr<ProcAST>> proclist = {process(), help()};
    REQUIRE_NOTHROW(see.run(proclist));
  }
  // order should not matter
  SECTION ("reverse order") {
    vector<shared_ptr<ProcAST>> proclist2 = {help(), process()};
    REQUIRE_NOTHROW(see.run(proclist2));
  }
}

TEST_CASE ("Semantic Error: Repeated proc names") {
  vector<shared_ptr<ProcAST>> proclist = {help(), help()};
  SemanticErrorExtractor see;
  REQUIRE_THROWS(see.run(proclist));
}

TEST_CASE ("Semantic Error: Called undeclared proc names") {
  vector<shared_ptr<ProcAST>> proclist = {process()};
  SemanticErrorExtractor see;
  REQUIRE_THROWS(see.run(proclist));
}

TEST_CASE ("Semantic Error: Cyclic calls") {
  vector<shared_ptr<ProcAST>> proclist = {procX(), procY(), procZ()};
  SemanticErrorExtractor see;
  REQUIRE_THROWS(see.run(proclist));
}