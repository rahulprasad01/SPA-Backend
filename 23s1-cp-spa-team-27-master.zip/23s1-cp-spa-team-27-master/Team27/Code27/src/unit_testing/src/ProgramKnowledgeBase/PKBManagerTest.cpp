#include "ProgramKnowledgeBase/EntityStorage.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "ProgramKnowledgeBase/PatternStorage.h"
#include "ProgramKnowledgeBase/RelationStorage.h"
#include "catch.hpp"

using std::shared_ptr;

using namespace PKB;

TEST_CASE ("PKB: Check instantiation") {
  PKBManager pkb;
  EntityStorage& entities = pkb.getEntityStorageHandle();
  PatternStorage& patterns = pkb.getPatternStorageHandle();
  RelationStorage& relations = pkb.getRelationStorageHandle();
}
