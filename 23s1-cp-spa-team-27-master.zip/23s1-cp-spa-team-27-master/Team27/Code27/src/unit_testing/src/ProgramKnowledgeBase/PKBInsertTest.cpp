#include "Common/Algorithms.h"
#include "ProgramKnowledgeBase/PKBInsert.h"
#include "ProgramKnowledgeBase/PKBManager.h"
#include "catch.hpp"

using namespace SPA;
using namespace PKB;

TEST_CASE ("PKBInsert: Insert into empty PKBManager") {
  PKBManager pkbManager;
  PKBInsert pkbInsert(pkbManager);
  Entity w1 = Entity(SPA::WHILE_STMT, "1");
  Entity a2 = Entity(SPA::ASSIGN_STMT, "2");
  Entity c3 = Entity(SPA::CALL_STMT, "3");
  Entity var = Entity(SPA::VAR, "v");
  Entity proc1 = Entity(SPA::PROC, "First");
  Entity proc2 = Entity(SPA::PROC, "Second");
  auto tokens = SPA::split("a + b * v % (d + a) ");
  REQUIRE(pkbInsert.insertEntity(a2));
  REQUIRE(pkbInsert.insertParent(w1, a2));
  REQUIRE(pkbInsert.insertFollows(a2, c3));
  REQUIRE(pkbInsert.insertUses(a2, var));
  REQUIRE(pkbInsert.insertModifies(a2, var));
  REQUIRE(pkbInsert.insertCalls(proc1, proc2));
  REQUIRE(pkbInsert.insertNext(w1, a2));
  REQUIRE(pkbInsert.insertProcStmt(proc1, w1));
  REQUIRE(pkbInsert.insertAssignPattern(a2, var, tokens));
  REQUIRE(pkbInsert.insertContainerPattern(w1, var));
}
