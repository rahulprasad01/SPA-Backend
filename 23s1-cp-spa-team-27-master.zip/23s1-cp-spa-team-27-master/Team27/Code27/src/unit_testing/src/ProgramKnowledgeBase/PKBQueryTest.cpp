#include "Common/Algorithms.h"
#include "ProgramKnowledgeBase/PKBQuery.h"
#include "catch.hpp"

using namespace SPA;
using namespace PKB;

TEST_CASE ("PKBQuery: Check empty PKBManager") {
  PKBManager pkbManager;
  PKBQuery pkbQuery(pkbManager);
  Entity w1 = Entity(SPA::WHILE_STMT, "1");
  Entity a2 = Entity(SPA::ASSIGN_STMT, "2");
  Entity v = Entity(SPA::VAR, "x");
  auto tokens = SPA::split("a + b + c ");
  unordered_set<EntityType> entityType = pkbQuery.getEntityTypeOfLabel("test");
  unordered_set<Entity, Entity::KeyHasher> entities =
      pkbQuery.getEntities(EntityType::ASSIGN_STMT);
  REQUIRE(entityType.size() == 0);
  REQUIRE(entities.size() == 0);
  REQUIRE_FALSE(pkbQuery.hasRelation(w1, a2, RelationType::PARENT));
  REQUIRE_FALSE(pkbQuery.hasAssignPattern(a2, v, tokens, true));
  REQUIRE_FALSE(pkbQuery.hasContainerPattern(w1, v));
}
