#include <vector>
#include "Common/Algorithms.h"
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"
#include "ProgramKnowledgeBase/PatternStorage.h"
#include "catch.hpp"

using std::vector;
using namespace PKB;

TEST_CASE ("Insert patterns") {
  PatternStorage patterns;
  std::string tokenString = "v + x * y + z * t ";
  vector<RawToken> tokens = SPA::split(tokenString);
  Entity stmt(SPA::ASSIGN_STMT, "2");
  Entity var(SPA::VAR, "va");
  REQUIRE(patterns.insertAssignPattern(stmt, var, tokens));
  REQUIRE_THROWS(patterns.insertAssignPattern(stmt, var, {}));
  REQUIRE_THROWS(
      patterns.insertAssignPattern(stmt, Entity(SPA::CONST, "5"), tokens));
  REQUIRE_THROWS(
      patterns.insertAssignPattern(Entity(SPA::CONST, "vs"), var, tokens));
  REQUIRE_THROWS(
      patterns.insertAssignPattern(Entity(SPA::VAR, "0"), var, tokens));
}

TEST_CASE ("Check patterns and subexpressions in assign stmts") {
  PatternStorage patterns;
  std::string tokenString = "v + x * y + z * t ";
  vector<RawToken> tokens = SPA::split(tokenString);
  Entity stmt(SPA::ASSIGN_STMT, "2");
  Entity var = Entity(SPA::VAR, "va");
  Entity otherVar = Entity(SPA::VAR, "vb");
  REQUIRE(patterns.insertAssignPattern(stmt, var, tokens));

  vector<vector<int>> subexprsIdx = {
      {0}, {2}, {4}, {6}, {8}, {2, 3, 4}, {6, 7, 8}, {0, 1, 2, 3, 4}};
  for (const auto& idxs : subexprsIdx) {
    vector<RawToken> expr(idxs.size());
    std::transform(idxs.begin(), idxs.end(), expr.begin(),
                   [&](int i) { return tokens[i]; });
    REQUIRE(patterns.hasAssignPattern(stmt, var, expr, true));
    REQUIRE_FALSE(patterns.hasAssignPattern(stmt, var, expr, false));
    REQUIRE_FALSE(patterns.hasAssignPattern(stmt, otherVar, expr, true));
  }
  REQUIRE(patterns.hasAssignPattern(stmt, var, tokens, false));
  REQUIRE(patterns.hasAssignPattern(stmt, var, tokens, true));
  REQUIRE(patterns.hasAssignPattern(stmt, SPA::WILDCARD, tokens, true));
  REQUIRE(patterns.hasAssignPattern(stmt, var, {}, true));
  REQUIRE_FALSE(patterns.hasAssignPattern(stmt, otherVar, {}, true));
  REQUIRE_FALSE(
      patterns.hasAssignPattern(stmt, var, SPA::split("v + x "), true));
  REQUIRE_FALSE(
      patterns.hasAssignPattern(stmt, var, SPA::split("x * y + z "), true));
  REQUIRE_FALSE(
      patterns.hasAssignPattern(stmt, var, SPA::split("x * y + z * t "), true));
}

TEST_CASE ("Check multiple assign stmts") {
  PatternStorage patterns;
  std::string tokenString1 = "v + x * y + z * t ";
  vector<RawToken> tokens1 = SPA::split(tokenString1);
  Entity stmt1(SPA::ASSIGN_STMT, "2");

  std::string tokenString2 = "x * y + z * t ";
  vector<RawToken> tokens2 = SPA::split(tokenString2);
  Entity stmt2(SPA::ASSIGN_STMT, "3");

  Entity var = Entity(SPA::VAR, "va");
  Pattern pattern1(var, tokens1);
  Pattern pattern2(var, tokens2);
  REQUIRE(patterns.insertAssignPattern(stmt1, var, tokens1));
  REQUIRE(patterns.insertAssignPattern(stmt2, var, tokens2));

  vector<vector<int>> subexprsIdx = {{2}, {4}, {6}, {8}, {2, 3, 4}, {6, 7, 8}};
  for (const auto& idxs : subexprsIdx) {
    vector<RawToken> expr(idxs.size());
    std::transform(idxs.begin(), idxs.end(), expr.begin(),
                   [&](int i) { return tokens1[i]; });
    REQUIRE(patterns.hasAssignPattern(stmt1, var, expr, true));
    REQUIRE(patterns.hasAssignPattern(stmt2, var, expr, true));
  }
  REQUIRE(patterns.hasAssignPattern(stmt2, var, tokens2, true));
  REQUIRE(patterns.hasAssignPattern(stmt2, var, tokens2, false));
  REQUIRE(patterns.hasAssignPattern(stmt1, var, {tokens1[0]}, true));
  REQUIRE_FALSE(patterns.hasAssignPattern(stmt2, var, {tokens1[0]}, true));
  REQUIRE_FALSE(patterns.hasAssignPattern(stmt1, var, tokens2, true));
  REQUIRE_FALSE(patterns.hasAssignPattern(stmt1, var, tokens2, false));
}

TEST_CASE ("Check long assign vars") {
  PatternStorage patterns;
  std::string tokenString1 = "v + x * yoo + z * t ";
  vector<RawToken> tokens1 = SPA::split(tokenString1);
  Entity stmt1(SPA::ASSIGN_STMT, "2");
  Entity var = Entity(SPA::VAR, "va");
  Pattern pattern1(var, tokens1);
  REQUIRE(patterns.insertAssignPattern(stmt1, var, tokens1));
  vector<RawToken> query = {"o"};
  REQUIRE_FALSE(patterns.hasAssignPattern(stmt1, var, query, true));
}

void insertContainerPattern(PatternStorage& patterns, int stmtNum,
                            EntityType type, vector<EntityRef> varNames) {
  Entity stmt(type, std::to_string(stmtNum));
  for (const auto& name : varNames) {
    REQUIRE(patterns.insertContainerPattern(stmt, Entity(SPA::VAR, name)));
  }
}

TEST_CASE ("Check if/while stmts") {
  PatternStorage patterns;
  REQUIRE_THROWS(patterns.insertContainerPattern(Entity(SPA::STMT, "2"),
                                                 Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.insertContainerPattern(Entity(SPA::CONST, "2"),
                                                 Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.insertContainerPattern(Entity(SPA::PROC, "p"),
                                                 Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.insertContainerPattern(Entity(SPA::IF_STMT, "1"),
                                                 Entity(SPA::CONST, "2")));
  REQUIRE_THROWS(patterns.insertContainerPattern(
      Entity(SPA::IF_STMT, "1"), Entity(EntityType::NULL_ENTITY, "2")));
  REQUIRE_THROWS(patterns.insertContainerPattern(
      Entity(SPA::WHILE_STMT, "1"), Entity(SPA::ASSIGN_STMT, "2")));

  insertContainerPattern(patterns, 1, IF_STMT, {"v", "x", "y", "v"});
  insertContainerPattern(patterns, 4, WHILE_STMT, {"z"});
  REQUIRE(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"),
                                       Entity(SPA::VAR, "v")));
  REQUIRE(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"),
                                       Entity(SPA::VAR, "x")));
  REQUIRE(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"),
                                       Entity(SPA::VAR, "y")));
  REQUIRE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "4"),
                                       Entity(SPA::VAR, "z")));

  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "4"),
                                             Entity(SPA::VAR, "y")));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "4"),
                                             Entity(SPA::VAR, "x")));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "4"),
                                             Entity(SPA::VAR, "v")));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"),
                                             Entity(SPA::VAR, "z")));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "4"),
                                             Entity(SPA::VAR, "z")));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "1"),
                                             Entity(SPA::VAR, "v")));

  REQUIRE_THROWS(patterns.hasContainerPattern(Entity(SPA::STMT, "2"),
                                              Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.hasContainerPattern(Entity(SPA::CONST, "2"),
                                              Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.hasContainerPattern(Entity(SPA::PROC, "p"),
                                              Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"),
                                              Entity(SPA::CONST, "2")));
  REQUIRE_THROWS(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "1"),
                                              Entity(SPA::ASSIGN_STMT, "2")));

  REQUIRE(patterns.hasContainerPattern(SPA::WILDCARD, Entity(SPA::VAR, "v")));
  REQUIRE(patterns.hasContainerPattern(SPA::WILDCARD, Entity(SPA::VAR, "z")));
  REQUIRE_FALSE(
      patterns.hasContainerPattern(SPA::WILDCARD, Entity(SPA::VAR, "a")));

  REQUIRE(
      patterns.hasContainerPattern(Entity(SPA::IF_STMT, "1"), SPA::WILDCARD));
  REQUIRE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "4"),
                                       SPA::WILDCARD));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "1"),
                                             SPA::WILDCARD));
  REQUIRE_FALSE(
      patterns.hasContainerPattern(Entity(SPA::IF_STMT, "4"), SPA::WILDCARD));
  REQUIRE_FALSE(patterns.hasContainerPattern(Entity(SPA::WHILE_STMT, "2"),
                                             SPA::WILDCARD));

  REQUIRE(patterns.hasContainerPattern(SPA::WILDCARD, SPA::WILDCARD));
}
