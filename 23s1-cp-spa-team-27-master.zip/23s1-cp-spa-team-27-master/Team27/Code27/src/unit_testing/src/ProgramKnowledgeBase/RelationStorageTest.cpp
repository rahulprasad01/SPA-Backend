#include <algorithm>
#include <catch.hpp>
#include <iostream>
#include <random>
#include <utility>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"
#include "ProgramKnowledgeBase/EntityStorage.h"
#include "ProgramKnowledgeBase/RelationStorage.h"
#include "catch.hpp"

using std::shared_ptr;
using std::vector;
using namespace SPA;
using namespace PKB;

TEST_CASE ("Insert Parent") {
  EntityStorage es;
  RelationStorage relations(es);
  REQUIRE(relations.insertParent(Entity(SPA::IF_STMT, "3"),
                                 Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::IF_STMT, "x3"),
                                        Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::IF_STMT, "3"),
                                        Entity(SPA::ASSIGN_STMT, "5v")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::IF_STMT, "3"),
                                        Entity(SPA::VAR, "vv")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::VAR, "v"),
                                        Entity(SPA::CALL_STMT, "2")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::IF_STMT, "3"),
                                        Entity(SPA::PROC, "p")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::PROC, "p"),
                                        Entity(SPA::CALL_STMT, "2")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::IF_STMT, "3"),
                                        Entity(SPA::CONST, "4")));
  REQUIRE_THROWS(relations.insertParent(Entity(SPA::CONST, "4"),
                                        Entity(SPA::CALL_STMT, "6")));
}

TEST_CASE ("Insert Follows") {
  EntityStorage es;
  RelationStorage relations(es);
  REQUIRE(relations.insertFollows(Entity(SPA::READ_STMT, "4"),
                                  Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::READ_STMT, "x4"),
                                         Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::READ_STMT, "4"),
                                         Entity(SPA::ASSIGN_STMT, "5v")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::READ_STMT, "3"),
                                         Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::VAR, "v"),
                                         Entity(SPA::CALL_STMT, "2")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::READ_STMT, "3"),
                                         Entity(SPA::PROC, "p")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::PROC, "p"),
                                         Entity(SPA::CALL_STMT, "2")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::READ_STMT, "3"),
                                         Entity(SPA::CONST, "4")));
  REQUIRE_THROWS(relations.insertFollows(Entity(SPA::CONST, "4"),
                                         Entity(SPA::CALL_STMT, "6")));
}

TEST_CASE ("Insert Uses") {
  EntityStorage es;
  RelationStorage relations(es);
  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::PRINT_STMT, "3"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  Entity otherVar = Entity(SPA::VAR, "v2");
  Entity otherProc = Entity(SPA::PROC, "p2");
  Entity c = Entity(SPA::CONST, "20");
  for (const auto& stmt : stmts) {
    REQUIRE(relations.insertUses(stmt, var));
    REQUIRE_THROWS(relations.insertUses(var, stmt));
    REQUIRE_THROWS(relations.insertUses(stmt, c));
  }
  REQUIRE(relations.insertUses(proc, var));
  REQUIRE_THROWS(relations.insertUses(var, proc));

  REQUIRE_THROWS(relations.insertUses(stmts[0], Entity(SPA::VAR, "0v")));
  REQUIRE_THROWS(relations.insertUses(Entity(SPA::ASSIGN_STMT, "v2"), var));
  REQUIRE_THROWS(relations.insertUses(var, otherVar));
  REQUIRE_THROWS(relations.insertUses(otherVar, var));
  REQUIRE_THROWS(relations.insertUses(stmts[0], stmts[0]));
  REQUIRE_THROWS(relations.insertUses(proc, otherProc));
  REQUIRE_THROWS(relations.insertUses(otherProc, proc));
  REQUIRE_THROWS(relations.insertUses(Entity(SPA::READ_STMT, "2"), var));
}

TEST_CASE ("Insert Modifies") {
  EntityStorage es;
  RelationStorage relations(es);
  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::READ_STMT, "2"),
      Entity(SPA::WHILE_STMT, "4"),  Entity(SPA::IF_STMT, "5"),
      Entity(SPA::CALL_STMT, "6"),
  };
  Entity var = Entity(SPA::VAR, "v");
  Entity proc = Entity(SPA::PROC, "p");
  Entity otherVar = Entity(SPA::VAR, "v2");
  Entity otherProc = Entity(SPA::PROC, "p2");
  Entity c = Entity(SPA::CONST, "20");
  for (const auto& stmt : stmts) {
    REQUIRE(relations.insertModifies(stmt, var));
    REQUIRE_THROWS(relations.insertModifies(var, stmt));
    REQUIRE_THROWS(relations.insertModifies(stmt, c));
  }
  REQUIRE(relations.insertModifies(proc, var));
  REQUIRE_THROWS(relations.insertModifies(var, proc));

  REQUIRE_THROWS(relations.insertModifies(stmts[0], Entity(SPA::VAR, "0v")));
  REQUIRE_THROWS(relations.insertModifies(Entity(SPA::ASSIGN_STMT, "v2"), var));
  REQUIRE_THROWS(relations.insertModifies(var, otherVar));
  REQUIRE_THROWS(relations.insertModifies(otherVar, var));
  REQUIRE_THROWS(relations.insertModifies(stmts[0], stmts[0]));
  REQUIRE_THROWS(relations.insertModifies(proc, otherProc));
  REQUIRE_THROWS(relations.insertModifies(otherProc, proc));
  REQUIRE_THROWS(relations.insertModifies(Entity(SPA::PRINT_STMT, "3"), var));
}

TEST_CASE ("Insert Calls") {
  EntityStorage es;
  RelationStorage relations(es);
  REQUIRE(relations.insertCalls(Entity(SPA::PROC, "first1First"),
                                Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "1st1first"),
                                       Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1First"),
                                       Entity(SPA::PROC, "212")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1First"),
                                       Entity(SPA::PROC, "Second-1-Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::VAR, "first1first"),
                                       Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1first"),
                                       Entity(SPA::VAR, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::CONST, "111"),
                                       Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1first"),
                                       Entity(SPA::CONST, "222")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::STMT, "111"),
                                       Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1first"),
                                       Entity(SPA::STMT, "222")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::ASSIGN_STMT, "111"),
                                       Entity(SPA::PROC, "Second1Second")));
  REQUIRE_THROWS(relations.insertCalls(Entity(SPA::PROC, "first1first"),
                                       Entity(SPA::ASSIGN_STMT, "222")));
}

TEST_CASE ("Insert Next") {
  EntityStorage es;
  RelationStorage relations(es);
  REQUIRE(relations.insertNext(Entity(SPA::IF_STMT, "3"),
                               Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertNext(Entity(SPA::IF_STMT, "x3"),
                                      Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertNext(Entity(SPA::IF_STMT, "3"),
                                      Entity(SPA::ASSIGN_STMT, "5v")));
  REQUIRE_THROWS(
      relations.insertNext(Entity(SPA::IF_STMT, "3"), Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(relations.insertNext(Entity(SPA::VAR, "v"),
                                      Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(
      relations.insertNext(Entity(SPA::IF_STMT, "3"), Entity(SPA::PROC, "p")));
  REQUIRE_THROWS(relations.insertNext(Entity(SPA::PROC, "p"),
                                      Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(
      relations.insertNext(Entity(SPA::IF_STMT, "3"), Entity(SPA::CONST, "5")));
  REQUIRE_THROWS(relations.insertNext(Entity(SPA::CONST, "3"),
                                      Entity(SPA::ASSIGN_STMT, "5")));
}

TEST_CASE ("Insert ProcStmt") {
  EntityStorage es;
  RelationStorage relations(es);
  REQUIRE(relations.insertProcStmt(Entity(SPA::PROC, "first1First"),
                                   Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::PROC, "1st1First"),
                                          Entity(SPA::VAR, "v")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::VAR, "first1First"),
                                          Entity(SPA::ASSIGN_STMT, "x5")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::CONST, "first1First"),
                                          Entity(SPA::CONST, "5")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::CONST, "111"),
                                          Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::PROC, "first1First"),
                                          Entity(SPA::PROC, "five")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::STMT, "111"),
                                          Entity(SPA::ASSIGN_STMT, "5")));
  REQUIRE_THROWS(relations.insertProcStmt(Entity(SPA::CALL_STMT, "1"),
                                          Entity(SPA::ASSIGN_STMT, "5")));
}

TEST_CASE ("Check hasRelation (without Affects)") {
  // std::cerr << "Check hasRelation" << std::endl;
  EntityStorage es;
  RelationStorage relations(es);
  vector<Entity> stmts = {
      Entity(SPA::ASSIGN_STMT, "1"), Entity(SPA::READ_STMT, "2"),
      Entity(SPA::IF_STMT, "3"),     Entity(SPA::CALL_STMT, "4"),
      Entity(SPA::ASSIGN_STMT, "5"), Entity(SPA::WHILE_STMT, "6"),
      Entity(SPA::ASSIGN_STMT, "7"), Entity(SPA::PRINT_STMT, "8"),
      Entity(SPA::PRINT_STMT, "9"),
  };
  Entity proc = Entity(SPA::PROC, "p");
  Entity constThree = Entity(SPA::CONST, "3");
  Entity varP = Entity(SPA::VAR, "p");

  SECTION ("Parent and Parent*") {
    vector<std::pair<int, int>> pairs = {
        {2, 3}, {2, 4}, {2, 5}, {2, 7}, {5, 6},
    };
    for (const auto& p : pairs) {
      REQUIRE(relations.insertParent(stmts[p.first], stmts[p.second]));
    }
    for (const auto& p : pairs) {
      REQUIRE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::PARENT));
      REQUIRE(relations.hasRelation(stmts[p.first], stmts[p.second],
                                    SPA::PARENT_T));
      REQUIRE_FALSE(
          relations.hasRelation(stmts[p.second], stmts[p.first], SPA::PARENT));
    }
    REQUIRE(relations.hasRelation(stmts[2], stmts[6], SPA::PARENT_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[6], stmts[2], SPA::PARENT_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[3], stmts[6], SPA::PARENT_T));

    REQUIRE(constThree.label == stmts[2].label);
    REQUIRE(relations.hasRelation(stmts[2], stmts[6], SPA::PARENT_T));
    REQUIRE_THROWS(relations.hasRelation(constThree, stmts[6], SPA::PARENT_T));

    REQUIRE(relations.hasRelation(stmts[2], SPA::WILDCARD, SPA::PARENT));
    REQUIRE(relations.hasRelation(stmts[2], SPA::WILDCARD, SPA::PARENT_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[7], SPA::WILDCARD, SPA::PARENT));
    REQUIRE_FALSE(
        relations.hasRelation(stmts[7], SPA::WILDCARD, SPA::PARENT_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, stmts[7], SPA::PARENT));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, stmts[7], SPA::PARENT_T));
    REQUIRE_FALSE(relations.hasRelation(SPA::WILDCARD, stmts[2], SPA::PARENT));
    REQUIRE_FALSE(
        relations.hasRelation(SPA::WILDCARD, stmts[2], SPA::PARENT_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::PARENT));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::PARENT_T));
  }

  SECTION ("Follows and Follows*") {
    vector<std::pair<int, int>> pairs = {{0, 1}, {1, 2}, {2, 8},
                                         {3, 4}, {4, 5}, {5, 7}};
    for (const auto& p : pairs) {
      REQUIRE(relations.insertFollows(stmts[p.first], stmts[p.second]));
    }
    for (const auto& p : pairs) {
      REQUIRE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::FOLLOWS));
      REQUIRE(relations.hasRelation(stmts[p.first], stmts[p.second],
                                    SPA::FOLLOWS_T));
      REQUIRE_FALSE(
          relations.hasRelation(stmts[p.second], stmts[p.first], SPA::FOLLOWS));
    }
    REQUIRE(relations.hasRelation(stmts[0], stmts[8], SPA::FOLLOWS_T));
    REQUIRE(relations.hasRelation(stmts[4], stmts[7], SPA::FOLLOWS_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[5], stmts[6], SPA::FOLLOWS_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[7], stmts[4], SPA::FOLLOWS_T));

    REQUIRE(constThree.label == stmts[2].label);
    REQUIRE(relations.hasRelation(stmts[0], stmts[2], SPA::FOLLOWS_T));
    REQUIRE_THROWS(relations.hasRelation(stmts[0], constThree, SPA::FOLLOWS_T));

    REQUIRE(relations.hasRelation(stmts[1], SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE(relations.hasRelation(stmts[1], SPA::WILDCARD, SPA::FOLLOWS_T));
    REQUIRE_FALSE(relations.hasRelation(stmts[7], SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE_FALSE(
        relations.hasRelation(stmts[7], SPA::WILDCARD, SPA::FOLLOWS_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, stmts[7], SPA::FOLLOWS));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, stmts[7], SPA::FOLLOWS_T));
    REQUIRE_FALSE(relations.hasRelation(SPA::WILDCARD, stmts[3], SPA::FOLLOWS));
    REQUIRE_FALSE(
        relations.hasRelation(SPA::WILDCARD, stmts[3], SPA::FOLLOWS_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::FOLLOWS));
    REQUIRE(
        relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::FOLLOWS_T));
  }

  SECTION ("Uses") {
    vector<Entity> vars = {
        Entity(SPA::VAR, "a"), Entity(SPA::VAR, "b"),  Entity(SPA::VAR, "c"),
        Entity(SPA::VAR, "d"), Entity(SPA::VAR, "aa"), Entity(SPA::VAR, "bb"),
    };
    vector<int> stmtNos = {2, 3, 4, 6, 7};
    for (int i = 0; i < stmtNos.size(); i++) {
      REQUIRE(relations.insertUses(stmts[stmtNos[i]], vars[i % vars.size()]));
      REQUIRE(relations.insertUses(proc, vars[i % vars.size()]));
    }

    for (int i = 0; i < stmtNos.size(); i++) {
      REQUIRE(relations.hasRelation(stmts[stmtNos[i]], vars[i % vars.size()],
                                    SPA::USES));
      REQUIRE(relations.hasRelation(proc, vars[i % vars.size()], SPA::USES));
      REQUIRE_THROWS(relations.hasRelation(vars[i % vars.size()],
                                           stmts[stmtNos[i]], SPA::USES));
    }
    REQUIRE_FALSE(relations.hasRelation(stmts[2], vars[2], SPA::USES));
    REQUIRE_FALSE(
        relations.hasRelation(proc, Entity(SPA::VAR, "cc"), SPA::USES));
    REQUIRE_THROWS(relations.hasRelation(stmts[2], stmts[3], SPA::USES));
    REQUIRE_THROWS(relations.hasRelation(vars[2], vars[3], SPA::USES));

    REQUIRE(varP.label == proc.label);
    REQUIRE(relations.hasRelation(proc, vars[3], SPA::USES));
    REQUIRE_THROWS(relations.hasRelation(varP, vars[3], SPA::USES));

    REQUIRE(relations.hasRelation(proc, SPA::WILDCARD, SPA::USES));
    REQUIRE(relations.hasRelation(stmts[2], SPA::WILDCARD, SPA::USES));
    REQUIRE(relations.hasRelation(stmts[4], SPA::WILDCARD, SPA::USES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::ASSIGN_STMT, "10"),
                                        SPA::WILDCARD, SPA::USES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::PROC, "otherProc"),
                                        SPA::WILDCARD, SPA::USES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::READ_STMT, "2"),
                                        SPA::WILDCARD, SPA::USES));

    REQUIRE_THROWS(relations.hasRelation(SPA::WILDCARD, vars[2], SPA::USES));
    REQUIRE_THROWS(relations.hasRelation(SPA::WILDCARD, Entity(SPA::VAR, "dd"),
                                         SPA::USES));

    REQUIRE_THROWS(
        relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::USES));
  }

  SECTION ("Modifies") {
    vector<Entity> vars = {
        Entity(SPA::VAR, "a"), Entity(SPA::VAR, "b"),  Entity(SPA::VAR, "c"),
        Entity(SPA::VAR, "d"), Entity(SPA::VAR, "aa"), Entity(SPA::VAR, "bb"),
    };
    vector<int> stmtNos = {0, 1, 3, 5};
    for (int i = 0; i < stmtNos.size(); i++) {
      REQUIRE(
          relations.insertModifies(stmts[stmtNos[i]], vars[i % vars.size()]));
      REQUIRE(relations.insertModifies(proc, vars[i % vars.size()]));
    }
    for (int i = 0; i < stmtNos.size(); i++) {
      REQUIRE(relations.hasRelation(stmts[stmtNos[i]], vars[i % vars.size()],
                                    SPA::MODIFIES));
      REQUIRE(
          relations.hasRelation(proc, vars[i % vars.size()], SPA::MODIFIES));
      REQUIRE_THROWS(relations.hasRelation(vars[i % vars.size()],
                                           stmts[stmtNos[i]], SPA::MODIFIES));
    }
    REQUIRE_FALSE(relations.hasRelation(stmts[2], vars[2], SPA::MODIFIES));
    REQUIRE_FALSE(
        relations.hasRelation(proc, Entity(SPA::VAR, "cc"), SPA::MODIFIES));
    REQUIRE_THROWS(relations.hasRelation(stmts[2], stmts[3], SPA::MODIFIES));
    REQUIRE_THROWS(relations.hasRelation(vars[2], vars[3], SPA::MODIFIES));

    REQUIRE(varP.label == proc.label);
    REQUIRE(relations.hasRelation(proc, vars[3], SPA::MODIFIES));
    REQUIRE_THROWS(relations.hasRelation(varP, vars[3], SPA::MODIFIES));

    REQUIRE(relations.hasRelation(proc, SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE(relations.hasRelation(stmts[1], SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE(relations.hasRelation(stmts[3], SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::ASSIGN_STMT, "10"),
                                        SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::PROC, "otherProc"),
                                        SPA::WILDCARD, SPA::MODIFIES));
    REQUIRE_FALSE(relations.hasRelation(Entity(SPA::PRINT_STMT, "8"),
                                        SPA::WILDCARD, SPA::MODIFIES));

    REQUIRE_THROWS(
        relations.hasRelation(SPA::WILDCARD, vars[2], SPA::MODIFIES));
    REQUIRE_THROWS(relations.hasRelation(SPA::WILDCARD, Entity(SPA::VAR, "dd"),
                                         SPA::MODIFIES));

    REQUIRE_THROWS(
        relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::MODIFIES));
  }

  SECTION ("Calls and Calls*") {
    vector<Entity> procs = {
        Entity(SPA::PROC, "Zero"), Entity(SPA::PROC, "A"),
        Entity(SPA::PROC, "B"),    Entity(SPA::PROC, "C"),
        Entity(SPA::PROC, "D"),    Entity(SPA::PROC, "E"),
        Entity(SPA::PROC, "F"),    Entity(SPA::PROC, "G"),
        Entity(SPA::PROC, "H"),    Entity(SPA::PROC, "I"),
        Entity(SPA::PROC, "J"),    Entity(SPA::PROC, "K"),
        Entity(SPA::PROC, "L"),    Entity(SPA::PROC, "M"),
        Entity(SPA::PROC, "N"),    Entity(SPA::PROC, "O"),
        Entity(SPA::PROC, "P"),
    };
    vector<std::pair<int, int>> pairs = {
        {0, 1},  {1, 2},   {2, 3},   {2, 4},   {3, 5},   {4, 6},   {5, 6},
        {7, 6},  {8, 5},   {6, 9},   {6, 10},  {6, 11},  {6, 16},  {9, 13},
        {9, 14}, {13, 14}, {13, 15}, {10, 11}, {10, 12}, {11, 12}, {11, 12},
    };
    int numProcs = procs.size();

    // Randomise insertion order
    std::shuffle(pairs.begin(), pairs.end(), std::random_device());

    for (const auto& p : pairs) {
      REQUIRE(relations.insertCalls(procs[p.first], procs[p.second]));
    }
    for (const auto& p : pairs) {
      REQUIRE(
          relations.hasRelation(procs[p.first], procs[p.second], SPA::CALLS));
      REQUIRE(
          relations.hasRelation(procs[p.first], procs[p.second], SPA::CALLS_T));
      REQUIRE_FALSE(
          relations.hasRelation(procs[p.second], procs[p.first], SPA::CALLS));
      REQUIRE_FALSE(
          relations.hasRelation(procs[p.second], procs[p.first], SPA::CALLS_T));
    }

    REQUIRE_FALSE(relations.hasRelation(procs[0], procs[2], SPA::CALLS));
    REQUIRE_FALSE(relations.hasRelation(procs[0], procs[15], SPA::CALLS));
    REQUIRE(relations.hasRelation(procs[0], procs[2], SPA::CALLS_T));
    REQUIRE(relations.hasRelation(procs[0], procs[15], SPA::CALLS_T));

    vector<std::pair<int, unordered_set<int>>> procCallsT = {
        {0, {1, 2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {1, {2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {2, {3, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {3, {5, 6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {4, {6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {5, {6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {6, {9, 10, 11, 12, 13, 14, 15, 16}},
        {7, {6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {8, {5, 6, 9, 10, 11, 12, 13, 14, 15, 16}},
        {9, {13, 14, 15}},
        {10, {11, 12}},
        {11, {12}},
        {12, {}},
        {13, {14, 15}},
        {14, {}},
        {15, {}},
        {16, {}},
    };
    for (const auto& t : procCallsT) {
      for (int i = 0; i < numProcs; i++) {
        REQUIRE(t.second.count(i) ==
                relations.hasRelation(procs[t.first], procs[i], SPA::CALLS_T));
      }
    }

    REQUIRE(relations.hasRelation(procs[9], SPA::WILDCARD, SPA::CALLS));
    REQUIRE(relations.hasRelation(procs[9], SPA::WILDCARD, SPA::CALLS_T));
    REQUIRE_FALSE(relations.hasRelation(procs[12], SPA::WILDCARD, SPA::CALLS));
    REQUIRE_FALSE(
        relations.hasRelation(procs[12], SPA::WILDCARD, SPA::CALLS_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, procs[5], SPA::CALLS));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, procs[5], SPA::CALLS_T));
    REQUIRE_FALSE(relations.hasRelation(SPA::WILDCARD, procs[7], SPA::CALLS));
    REQUIRE_FALSE(relations.hasRelation(SPA::WILDCARD, procs[7], SPA::CALLS_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::CALLS));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::CALLS_T));
  }

  SECTION ("Next and Next*") {
    vector<Entity> nextStmts = {
        Entity(SPA::STMT, "0"),         Entity(SPA::READ_STMT, "1"),
        Entity(SPA::CALL_STMT, "2"),    Entity(SPA::IF_STMT, "3"),
        Entity(SPA::WHILE_STMT, "4"),   Entity(SPA::IF_STMT, "5"),
        Entity(SPA::ASSIGN_STMT, "6"),  Entity(SPA::WHILE_STMT, "7"),
        Entity(SPA::ASSIGN_STMT, "8"),  Entity(SPA::PRINT_STMT, "9"),
        Entity(SPA::PRINT_STMT, "10"),  Entity(SPA::IF_STMT, "11"),
        Entity(SPA::WHILE_STMT, "12"),  Entity(SPA::WHILE_STMT, "13"),
        Entity(SPA::ASSIGN_STMT, "14"), Entity(SPA::ASSIGN_STMT, "15"),
        Entity(SPA::PRINT_STMT, "16"),  Entity(SPA::WHILE_STMT, "17"),
        Entity(SPA::WHILE_STMT, "18"),  Entity(SPA::ASSIGN_STMT, "19"),
        Entity(SPA::CALL_STMT, "20"),
    };
    vector<std::pair<int, int>> pairs = {
        {1, 2},   {2, 3},   {3, 4},   {3, 11},  {4, 5},   {4, 10},  {5, 6},
        {5, 7},   {6, 4},   {7, 8},   {7, 9},   {8, 7},   {9, 4},   {10, 20},
        {11, 12}, {11, 17}, {12, 13}, {12, 16}, {13, 14}, {13, 15}, {14, 13},
        {15, 12}, {16, 20}, {17, 18}, {17, 20}, {18, 17}, {18, 19}, {19, 18},
    };
    int numStmts = nextStmts.size() - 1;

    // Randomise insertion order
    std::shuffle(pairs.begin(), pairs.end(), std::random_device());

    for (const auto& p : pairs) {
      REQUIRE(relations.insertNext(nextStmts[p.first], nextStmts[p.second]));
    }
    for (const auto& p : pairs) {
      REQUIRE(relations.hasRelation(nextStmts[p.first], nextStmts[p.second],
                                    SPA::NEXT));
      REQUIRE(relations.hasRelation(nextStmts[p.first], nextStmts[p.second],
                                    SPA::NEXT_T));
    }

    REQUIRE_FALSE(relations.hasRelation(nextStmts[2], nextStmts[4], SPA::NEXT));
    REQUIRE_FALSE(
        relations.hasRelation(nextStmts[1], nextStmts[20], SPA::NEXT));
    REQUIRE(relations.hasRelation(nextStmts[2], nextStmts[4], SPA::NEXT_T));
    REQUIRE(relations.hasRelation(nextStmts[1], nextStmts[20], SPA::NEXT_T));

    vector<std::pair<int, unordered_set<int>>> stmtsNextT = {
        {1,
         {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}},
        {2, {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}},
        {3, {4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}},
        {4, {4, 5, 6, 7, 8, 9, 10, 20}},
        {5, {4, 5, 6, 7, 8, 9, 10, 20}},
        {6, {4, 5, 6, 7, 8, 9, 10, 20}},
        {7, {4, 5, 6, 7, 8, 9, 10, 20}},
        {8, {4, 5, 6, 7, 8, 9, 10, 20}},
        {9, {4, 5, 6, 7, 8, 9, 10, 20}},
        {10, {20}},
        {11, {12, 13, 14, 15, 16, 17, 18, 19, 20}},
        {12, {12, 13, 14, 15, 16, 20}},
        {13, {12, 13, 14, 15, 16, 20}},
        {14, {12, 13, 14, 15, 16, 20}},
        {15, {12, 13, 14, 15, 16, 20}},
        {16, {20}},
        {17, {17, 18, 19, 20}},
        {18, {17, 18, 19, 20}},
        {19, {17, 18, 19, 20}},
        {20, {}},
    };
    for (const auto& t : stmtsNextT) {
      for (int i = 1; i <= numStmts; i++) {
        REQUIRE(t.second.count(i) == relations.hasRelation(nextStmts[t.first],
                                                           nextStmts[i],
                                                           SPA::NEXT_T));
      }
    }

    REQUIRE(relations.hasRelation(nextStmts[15], SPA::WILDCARD, SPA::NEXT));
    REQUIRE(relations.hasRelation(nextStmts[15], SPA::WILDCARD, SPA::NEXT_T));
    REQUIRE_FALSE(
        relations.hasRelation(nextStmts[20], SPA::WILDCARD, SPA::NEXT));
    REQUIRE_FALSE(
        relations.hasRelation(nextStmts[20], SPA::WILDCARD, SPA::NEXT_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, nextStmts[9], SPA::NEXT));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, nextStmts[9], SPA::NEXT_T));
    REQUIRE_FALSE(
        relations.hasRelation(SPA::WILDCARD, nextStmts[1], SPA::NEXT));
    REQUIRE_FALSE(
        relations.hasRelation(SPA::WILDCARD, nextStmts[1], SPA::NEXT_T));

    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::NEXT));
    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::NEXT_T));
  }
}

TEST_CASE ("Check Affects Relation") {
  EntityStorage entities;
  RelationStorage relations(entities);

  SECTION ("Simple Affects") {
    Entity proc = Entity(SPA::PROC, "First");
    vector<Entity> stmts = {
        Entity(SPA::STMT, "0"),        Entity(SPA::ASSIGN_STMT, "1"),
        Entity(SPA::IF_STMT, "2"),     Entity(SPA::ASSIGN_STMT, "3"),
        Entity(SPA::ASSIGN_STMT, "4"), Entity(SPA::ASSIGN_STMT, "5"),
        Entity(SPA::IF_STMT, "6"),     Entity(SPA::ASSIGN_STMT, "7"),
        Entity(SPA::READ_STMT, "8"),   Entity(SPA::ASSIGN_STMT, "9"),
    };
    vector<std::pair<int, int>> nextPairs = {
        {1, 2}, {2, 3}, {2, 4}, {3, 6}, {4, 5},
        {5, 6}, {6, 7}, {6, 8}, {7, 9}, {8, 9},
    };
    vector<int> usesStmts = {2, 3, 4, 5, 6, 7, 9};
    vector<int> modifiesStmts = {1, 2, 4, 5, 6, 8, 9};
    Entity var = Entity(SPA::VAR, "v");
    REQUIRE(entities.insertEntity(proc));
    REQUIRE(entities.insertEntity(var));
    for (const auto& s : stmts) {
      REQUIRE(entities.insertEntity(s));
      REQUIRE(relations.insertProcStmt(proc, s));
    }
    for (const auto& p : nextPairs) {
      REQUIRE(relations.insertNext(stmts[p.first], stmts[p.second]));
    }
    for (const auto& u : usesStmts) {
      REQUIRE(relations.insertUses(stmts[u], var));
    }
    for (const auto& m : modifiesStmts) {
      REQUIRE(relations.insertModifies(stmts[m], var));
    }
    REQUIRE(relations.hasRelation(stmts[4], stmts[5], SPA::AFFECTS));
    REQUIRE(relations.hasRelation(stmts[1], stmts[9], SPA::AFFECTS));
    REQUIRE_FALSE(relations.hasRelation(stmts[4], stmts[7], SPA::AFFECTS));
  }

  SECTION ("Affects Example in Design Abstractions (Code 6)") {
    Entity proc = Entity(SPA::PROC, "Second");
    vector<Entity> stmts = {
        Entity(SPA::STMT, "0"),         Entity(SPA::ASSIGN_STMT, "1"),
        Entity(SPA::ASSIGN_STMT, "2"),  Entity(SPA::WHILE_STMT, "3"),
        Entity(SPA::ASSIGN_STMT, "4"),  Entity(SPA::CALL_STMT, "5"),
        Entity(SPA::ASSIGN_STMT, "6"),  Entity(SPA::IF_STMT, "7"),
        Entity(SPA::ASSIGN_STMT, "8"),  Entity(SPA::ASSIGN_STMT, "9"),
        Entity(SPA::ASSIGN_STMT, "10"), Entity(SPA::ASSIGN_STMT, "11"),
        Entity(SPA::ASSIGN_STMT, "12"),
    };
    int numStmts = stmts.size() - 1;
    vector<std::pair<int, int>> nextPairs = {
        {1, 2}, {2, 3}, {3, 4},  {3, 7},  {4, 5},   {5, 6},   {6, 3},
        {7, 8}, {7, 9}, {8, 10}, {9, 10}, {10, 11}, {11, 12},
    };
    vector<std::pair<Entity, vector<int>>> usedVars = {
        {Entity(SPA::VAR, "v"), {3, 5}},
        {Entity(SPA::VAR, "x"), {3, 4, 7, 8, 10, 12}},
        {Entity(SPA::VAR, "y"), {3, 4, 12}},
        {Entity(SPA::VAR, "z"), {3, 5, 10, 11, 12}},
        {Entity(SPA::VAR, "i"), {3, 6, 10}},
    };
    vector<std::pair<Entity, vector<int>>> modifiedVars = {
        {Entity(SPA::VAR, "v"), {3, 5}},
        {Entity(SPA::VAR, "x"), {1, 3, 4, 7, 8, 12}},
        {Entity(SPA::VAR, "y"), {11}},
        {Entity(SPA::VAR, "z"), {3, 5, 7, 9, 10}},
        {Entity(SPA::VAR, "i"), {2, 3, 6}},
    };
    for (const auto& s : stmts) {
      REQUIRE(entities.insertEntity(s));
      REQUIRE(relations.insertProcStmt(proc, s));
    }
    for (const auto& p : nextPairs) {
      REQUIRE(relations.insertNext(stmts[p.first], stmts[p.second]));
    }
    for (const auto& u : usedVars) {
      REQUIRE(entities.insertEntity(u.first));
      for (const auto& i : u.second) {
        REQUIRE(relations.insertUses(stmts[i], u.first));
      }
    }
    for (const auto& m : modifiedVars) {
      REQUIRE(entities.insertEntity(m.first));
      for (const auto& i : m.second) {
        REQUIRE(relations.insertModifies(stmts[i], m.first));
      }
    }
    vector<std::pair<int, int>> trueAffectsPairs = {
        {2, 6},  {4, 8},  {4, 10}, {6, 6},  {1, 4},   {1, 8},
        {1, 10}, {1, 12}, {2, 10}, {9, 10}, {11, 12}, {8, 10},
    };
    vector<std::pair<int, int>> falseAffectsPairs = {
        {9, 11}, {9, 12}, {2, 3}, {9, 6}, {3, 6},
    };
    for (const auto& p : trueAffectsPairs) {
      REQUIRE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::AFFECTS));
    }
    for (const auto& p : falseAffectsPairs) {
      REQUIRE_FALSE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::AFFECTS));
    }
    unordered_set<int> trueAffectsLHS = {1, 2, 4, 6, 8, 9, 10, 11};
    unordered_set<int> trueAffectsRHS = {4, 6, 8, 10, 11, 12};
    for (int i = 1; i <= numStmts; i++) {
      REQUIRE(trueAffectsLHS.count(i) ==
              relations.hasRelation(stmts[i], SPA::WILDCARD, SPA::AFFECTS));
      REQUIRE(trueAffectsRHS.count(i) ==
              relations.hasRelation(SPA::WILDCARD, stmts[i], SPA::AFFECTS));
    }
    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::AFFECTS));
  }

  SECTION ("Affects Example in Design Abstractions (Code 9)") {
    Entity procP = Entity(SPA::PROC, "p");
    Entity procQ = Entity(SPA::PROC, "q");
    vector<Entity> stmts = {
        Entity(SPA::STMT, "0"),         Entity(SPA::ASSIGN_STMT, "1"),
        Entity(SPA::ASSIGN_STMT, "2"),  Entity(SPA::ASSIGN_STMT, "3"),
        Entity(SPA::CALL_STMT, "4"),    Entity(SPA::ASSIGN_STMT, "5"),
        Entity(SPA::ASSIGN_STMT, "6"),  Entity(SPA::ASSIGN_STMT, "7"),
        Entity(SPA::IF_STMT, "8"),      Entity(SPA::ASSIGN_STMT, "9"),
        Entity(SPA::ASSIGN_STMT, "10"), Entity(SPA::ASSIGN_STMT, "11"),
    };
    int numStmts = stmts.size() - 1;
    vector<int> procPstmts = {1, 2, 3, 4, 5};
    vector<int> procQstmts = {6, 7, 8, 9, 10, 11};
    vector<std::pair<int, int>> nextPairs = {
        {1, 2}, {2, 3}, {3, 4},  {4, 5},  {6, 7},
        {7, 8}, {8, 9}, {8, 10}, {9, 11}, {10, 11},
    };
    vector<std::pair<Entity, vector<int>>> usedVars = {
        {Entity(SPA::VAR, "x"), {4, 5, 8, 9, 10}},
        {Entity(SPA::VAR, "y"), {3, 5}},
        {Entity(SPA::VAR, "z"), {4, 5, 8, 10}},
        {Entity(SPA::VAR, "t"), {11}},
    };
    vector<std::pair<Entity, vector<int>>> modifiedVars = {
        {Entity(SPA::VAR, "x"), {1, 4, 6, 11}},
        {Entity(SPA::VAR, "y"), {2, 4, 8, 10}},
        {Entity(SPA::VAR, "z"), {3, 5}},
        {Entity(SPA::VAR, "t"), {4, 7, 8, 9}},
    };
    for (const auto& s : stmts) {
      REQUIRE(entities.insertEntity(s));
    }
    for (const auto& i : procPstmts) {
      REQUIRE(relations.insertProcStmt(procP, stmts[i]));
    }
    for (const auto& i : procQstmts) {
      REQUIRE(relations.insertProcStmt(procQ, stmts[i]));
    }
    for (const auto& p : nextPairs) {
      REQUIRE(relations.insertNext(stmts[p.first], stmts[p.second]));
    }
    for (const auto& u : usedVars) {
      REQUIRE(entities.insertEntity(u.first));
      for (const auto& i : u.second) {
        REQUIRE(relations.insertUses(stmts[i], u.first));
      }
    }
    for (const auto& m : modifiedVars) {
      REQUIRE(entities.insertEntity(m.first));
      for (const auto& i : m.second) {
        REQUIRE(relations.insertModifies(stmts[i], m.first));
      }
    }
    vector<std::pair<int, int>> trueAffectsPairs = {{3, 5}, {7, 11}};
    vector<std::pair<int, int>> falseAffectsPairs = {{1, 5}, {2, 5}, {3, 10}};
    for (const auto& p : trueAffectsPairs) {
      REQUIRE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::AFFECTS));
    }
    for (const auto& p : falseAffectsPairs) {
      REQUIRE_FALSE(
          relations.hasRelation(stmts[p.first], stmts[p.second], SPA::AFFECTS));
    }
    unordered_set<int> trueAffectsLHS = {2, 3, 6, 7, 9};
    unordered_set<int> trueAffectsRHS = {3, 5, 9, 10, 11};
    for (int i = 1; i <= numStmts; i++) {
      REQUIRE(trueAffectsLHS.count(i) ==
              relations.hasRelation(stmts[i], SPA::WILDCARD, SPA::AFFECTS));
      REQUIRE(trueAffectsRHS.count(i) ==
              relations.hasRelation(SPA::WILDCARD, stmts[i], SPA::AFFECTS));
    }
    REQUIRE(relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::AFFECTS));
  }

  SECTION ("Affects Example in Design Abstractions (Code 11)") {
    Entity procP = Entity(SPA::PROC, "p");
    vector<Entity> stmts = {
        Entity(SPA::STMT, "0"), Entity(SPA::ASSIGN_STMT, "1"),
        Entity(SPA::READ_STMT, "2"), Entity(SPA::ASSIGN_STMT, "3")};
    vector<std::pair<int, int>> nextPairs = {{1, 2}, {2, 3}};
    vector<std::pair<Entity, vector<int>>> usedVars = {
        {Entity(SPA::VAR, "x"), {3}},
        {Entity(SPA::VAR, "a"), {1}},
    };
    vector<std::pair<Entity, vector<int>>> modifiedVars = {
        {Entity(SPA::VAR, "x"), {1, 2}},
        {Entity(SPA::VAR, "v"), {3}},
    };
    for (const auto& s : stmts) {
      REQUIRE(entities.insertEntity(s));
      REQUIRE(relations.insertProcStmt(procP, s));
    }
    for (const auto& p : nextPairs) {
      REQUIRE(relations.insertNext(stmts[p.first], stmts[p.second]));
    }
    for (const auto& u : usedVars) {
      REQUIRE(entities.insertEntity(u.first));
      for (const auto& i : u.second) {
        REQUIRE(relations.insertUses(stmts[i], u.first));
      }
    }
    for (const auto& m : modifiedVars) {
      REQUIRE(entities.insertEntity(m.first));
      for (const auto& i : m.second) {
        REQUIRE(relations.insertModifies(stmts[i], m.first));
      }
    }
    REQUIRE_FALSE(relations.hasRelation(stmts[1], stmts[3], SPA::AFFECTS));
    REQUIRE_FALSE(relations.hasRelation(stmts[2], stmts[3], SPA::AFFECTS));
    REQUIRE_FALSE(relations.hasRelation(stmts[1], SPA::WILDCARD, SPA::AFFECTS));
    REQUIRE_FALSE(relations.hasRelation(SPA::WILDCARD, stmts[3], SPA::AFFECTS));
    REQUIRE_FALSE(
        relations.hasRelation(SPA::WILDCARD, SPA::WILDCARD, SPA::AFFECTS));
  }
}
