#include <iostream>
#include <vector>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"
#include "ProgramKnowledgeBase/EntityStorage.h"
#include "catch.hpp"

using std::unordered_set;
using std::vector;

using namespace SPA;
using namespace PKB;

TEST_CASE ("Entity Insertion and Validation") {
  EntityStorage entities;

  SECTION ("Numerical Labels") {
    vector<EntityType> toCheck = {
        SPA::CONST,   SPA::STMT,       SPA::ASSIGN_STMT, SPA::CALL_STMT,
        SPA::IF_STMT, SPA::WHILE_STMT, SPA::PRINT_STMT,  SPA::READ_STMT};

    for (const auto& t : toCheck) {
      REQUIRE(entities.insertEntity(Entity{t, "5"}));
      REQUIRE(entities.insertEntity(Entity{t, "5012"}));
      REQUIRE(entities.insertEntity(Entity{t, "0"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "01"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "01234"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "00001234"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "1va"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "va"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "-5"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "-5012"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "5.012"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "5012."}));
    }
  }

  SECTION ("Name Labels") {
    vector<EntityType> toCheck = {SPA::VAR, SPA::PROC};

    for (const auto& t : toCheck) {
      REQUIRE(entities.insertEntity(Entity{t, "test"}));
      REQUIRE(entities.insertEntity(Entity{t, "testString"}));
      REQUIRE(entities.insertEntity(Entity{t, "v"}));
      REQUIRE(entities.insertEntity(Entity{t, "v012"}));
      REQUIRE(entities.insertEntity(Entity{t, "V012"}));
      REQUIRE(entities.insertEntity(Entity{t, "V0v1v2v"}));
      REQUIRE(entities.insertEntity(Entity{t, "ONE2thrEe4"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "1va"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "1"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "12"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "test-string"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "test_string"}));
      REQUIRE_THROWS(entities.insertEntity(Entity{t, "test string"}));
    }
  }
}

TEST_CASE ("New Entity Extraction") {
  EntityStorage entities;
  vector<Entity> stmts = {
      Entity{SPA::PRINT_STMT, "1"},  Entity{SPA::CALL_STMT, "2"},
      Entity{SPA::WHILE_STMT, "3"},  Entity{SPA::IF_STMT, "4"},
      Entity{SPA::ASSIGN_STMT, "5"}, Entity{SPA::READ_STMT, "6"},
      Entity{SPA::PRINT_STMT, "7"},  Entity{SPA::CALL_STMT, "8"},
      Entity{SPA::WHILE_STMT, "9"},  Entity{SPA::IF_STMT, "10"},
  };
  vector<Entity> consts = {
      Entity{SPA::CONST, "1"}, Entity{SPA::CONST, "2"},
      Entity{SPA::CONST, "3"}, Entity{SPA::CONST, "4"},
      Entity{SPA::CONST, "5"}, Entity{SPA::CONST, "6"},
      Entity{SPA::CONST, "7"}, Entity{SPA::CONST, "8"},
      Entity{SPA::CONST, "9"}, Entity{SPA::CONST, "10"},
  };
  vector<Entity> vars = {
      Entity{SPA::VAR, "v"},
      Entity{SPA::VAR, "x"},
      Entity{SPA::VAR, "y"},
  };
  for (const Entity& s : stmts) {
    REQUIRE(entities.insertEntity(s));
  }
  for (const Entity& c : consts) {
    REQUIRE(entities.insertEntity(c));
  }
  for (const Entity& v : vars) {
    REQUIRE(entities.insertEntity(v));
  }

  auto varEntities = entities.getEntities(SPA::VAR);
  REQUIRE(varEntities.size() == 3);
  for (const Entity& varEntity : varEntities) {
    REQUIRE(std::find(vars.begin(), vars.end(), varEntity) != vars.end());
  }
  auto stmtEntities = entities.getEntities(SPA::STMT);
  REQUIRE(stmtEntities.size() == 10);
  for (const Entity& stmtEntity : stmtEntities) {
    REQUIRE(std::find(stmts.begin(), stmts.end(), stmtEntity) != stmts.end());
  }
  auto printEntities = entities.getEntities(SPA::PRINT_STMT);
  REQUIRE(printEntities.size() == 2);
  for (const Entity& printEntity : printEntities) {
    REQUIRE(std::find(stmts.begin(), stmts.end(), printEntity) != stmts.end());
  }

  auto typesWithLabelSix = entities.getEntityTypeOfLabel("6");
  REQUIRE(typesWithLabelSix.size() == 2);
  REQUIRE(typesWithLabelSix.count(SPA::READ_STMT));
  REQUIRE(typesWithLabelSix.count(SPA::CONST));
}

TEST_CASE ("OLD Entity Extraction (To be Deprecated)") {
  EntityStorage entities;
  vector<EntityType> stmtsT = {READ_STMT,  PRINT_STMT, CALL_STMT,
                               WHILE_STMT, IF_STMT,    ASSIGN_STMT};
  for (int i = 1; i <= 10; i++) {
    REQUIRE(entities.insertEntity(
        Entity{stmtsT[i % stmtsT.size()], SPA::format("{}", i)}));
    REQUIRE(entities.insertEntity(Entity{SPA::CONST, SPA::format("{}", i)}));
  }
  vector<EntityRef> varRefs = {"v", "x", "y"};
  for (const auto& ref : varRefs) {
    REQUIRE(entities.insertEntity(Entity{SPA::VAR, ref}));
  }
}
