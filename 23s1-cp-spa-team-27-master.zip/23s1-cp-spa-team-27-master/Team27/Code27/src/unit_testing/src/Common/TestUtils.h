#pragma once
#include <filesystem>
#include <unordered_set>
#include "catch.hpp"

// 6 levels of nesting:
// Team27\Code27\out\build\x64-Debug\src
#define NESTING 6
namespace fs = std::filesystem;

namespace TEST {

template <typename T>
inline bool allInVector(const std::vector<T>& actual,
                        const std::vector<T>& expected) {
  for (const auto& e : actual) {
    if (std::find(expected.begin(), expected.end(), e) != expected.end()) {
      continue;
    } else {
      return false;
    }
  }
  return true;
}

}  // namespace TEST
