#include <algorithm>
#include <iostream>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "Common/Algorithms.h"
#include "Common/SPADefinitions.h"
#include "catch.hpp"

using std::set;
using std::unordered_map;
using std::unordered_set;
using std::vector;

using namespace SPA;

// TODO: Test cases for toposort

TEST_CASE ("Cycle detection") {
  SECTION ("basic") {
    vector<unordered_set<size_t>> map = {{1}, {2}, {0}};
    REQUIRE(hasCycle(map));
  }
  SECTION ("1, 2, 4, 1") {
    vector<unordered_set<size_t>> map = {
        {1}, {2, 3}, {4, 5}, {6, 7}, {1, 2}, {7}, {6}, {},
    };
    REQUIRE(hasCycle(map));
  }
  SECTION ("smallest cycle") {
    vector<unordered_set<size_t>> map = {{1}, {0}};
    REQUIRE(hasCycle(map));
  }
  SECTION ("no cycle") {
    vector<unordered_set<size_t>> map = {
        {1}, {2, 3}, {4, 5}, {6, 7}, {5}, {6}, {7}, {},
    };
    REQUIRE_FALSE(hasCycle(map));
  }
  SECTION ("bigger map") {
    vector<unordered_set<size_t>> map = {{1, 3, 6}, {2, 3}, {3, 6}, {5},
                                         {3},       {},     {5}};
    REQUIRE_FALSE(hasCycle(map));
  }
  SECTION ("cycle 0, 1, 2, 3") {
    vector<unordered_set<size_t>> map = {{1, 6}, {2, 3}, {3, 6}, {5, 0},
                                         {3},    {},     {5}};
    REQUIRE(hasCycle(map));
  }
}

TEST_CASE ("Split and Concatenate RawTokens") {
  vector<RawToken> expectedTokens = {"t", "+", "(", "x", "/", "(", "z",
                                     "+", "y", ")", "%", "t", ")"};
  std::string expectedString = " t + ( x / ( z + y ) % t ) ";
  std::string outputString = concat(expectedTokens, " ");
  vector<RawToken> outputTokens = split(expectedString);
  REQUIRE(outputString == expectedString);
  REQUIRE(outputTokens == expectedTokens);
}

TEST_CASE ("Infix to Postfix") {
  SECTION ("Basic Conversion") {
    std::string infix = "x1 + x2 / y ";
    std::string postfix = " x1 x2 y / + ";
    std::string output = concat(infixToPostfix(split(infix)), " ");
    REQUIRE(output == postfix);
  }

  SECTION ("Longer Conversion") {
    std::string infix = "v + x % y + z * t ";
    std::string postfix = " v x y % + z t * + ";
    std::string output = concat(infixToPostfix(split(infix)), " ");
    REQUIRE(output == postfix);
  }

  SECTION ("Converting Parantheses") {
    std::string infix = "v + x * ( y + z * t ) ";
    std::string postfix = " v x y z t * + * + ";
    std::string output = concat(infixToPostfix(split(infix)), " ");
    REQUIRE(output == postfix);
  }

  SECTION ("Converting Nested Parentheses") {
    std::string infix = "t + ( x / ( z + y ) % t ) ";
    std::string postfix = " t x z y + / t % + ";
    std::string output = concat(infixToPostfix(split(infix)), " ");
    REQUIRE(output == postfix);
  }
}

// Put spaces in between each token in order to use `SPA::split`
TEST_CASE ("Expression validator") {
  SECTION ("expr nums") {
    auto vec = SPA::split("10 + 7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("term nums") {
    auto vec = SPA::split("10 * 7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("factor nums") {
    auto vec = SPA::split("10");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("factor bracs") {
    auto vec = SPA::split("( y )");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("expr vars") {
    auto vec = SPA::split("n1 - 7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("term vars") {
    auto vec = SPA::split("10 % n7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("factor vars") {
    auto vec = SPA::split("myvar");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("expr expr") {
    auto vec = SPA::split("22 - 10 + n7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("expr term") {
    auto vec = SPA::split("22 + 10 % n7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("term term") {
    auto vec = SPA::split("d22 * 10 % n7");
    REQUIRE(SPA::checkExpr(vec));
  }
  SECTION ("expr, expr, (term)") {
    auto vec = SPA::split("10 + 7 - ( v * c )");
    REQUIRE(SPA::checkExpr(vec));
  }
}

TEST_CASE ("Join two tables") {
  SECTION ("Simple join of one element on one table") {
    vector<vector<int>> a, b;
    a.push_back({11, 22, 33});
    vector<int> a_index{1, 2, 3}, b_index;
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3});
    REQUIRE(ret.first == vector<vector<int>>({{11, 22, 33}}));
  }
  SECTION (
      "Simple join of one element on one table and second table with columns") {
    vector<vector<int>> a, b;
    a.push_back({11, 22, 33});
    vector<int> a_index{1, 2, 3}, b_index{3, 4, 5};
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3, 4, 5});
    REQUIRE(ret.first == vector<vector<int>>());
  }
  SECTION ("Simple join of one element on each table") {
    vector<vector<int>> a, b;
    a.push_back({11, 22, 33});
    b.push_back({22, 33, 44});
    vector<int> a_index{1, 2, 3}, b_index{2, 3, 4};
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3, 4});
    REQUIRE(ret.first == vector<vector<int>>{{11, 22, 33, 44}});
  }
  SECTION ("Join 2 elements x 3 elements") {
    vector<vector<int>> a, b;
    a.push_back({111, 22, 33});
    a.push_back({112, 22, 33});
    a.push_back({113, 22, 33});
    b.push_back({22, 33, 441});
    b.push_back({22, 33, 442});
    vector<int> a_index{1, 2, 3}, b_index{2, 3, 4};
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3, 4});
    REQUIRE(set(ret.first.begin(), ret.first.end()) ==
            set<vector<int>>{{111, 22, 33, 441},
                             {111, 22, 33, 442},
                             {112, 22, 33, 441},
                             {112, 22, 33, 442},
                             {113, 22, 33, 441},
                             {113, 22, 33, 442}});
  }
  SECTION ("Join 2 elements x 3 elements with unmatched elements") {
    vector<vector<int>> a, b;
    a.push_back({111, 22, 33});
    a.push_back({112, 22, 33});
    a.push_back({113, 22, 33});
    b.push_back({22, 33, 441});
    b.push_back({22, 33, 442});
    b.push_back({222, 33, 442});
    vector<int> a_index{1, 2, 3}, b_index{2, 3, 4};
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3, 4});
    REQUIRE(set(ret.first.begin(), ret.first.end()) ==
            set<vector<int>>{{111, 22, 33, 441},
                             {111, 22, 33, 442},
                             {112, 22, 33, 441},
                             {112, 22, 33, 442},
                             {113, 22, 33, 441},
                             {113, 22, 33, 442}});
  }
  SECTION ("Join 2 elements x 3 elements without common elements") {
    vector<vector<int>> a, b;
    a.push_back({111, 22, 33});
    a.push_back({112, 22, 33});
    a.push_back({113, 22, 33});
    b.push_back({22, 33, 441});
    b.push_back({22, 33, 442});
    vector<int> a_index{1, 2, 3}, b_index{4, 5, 6};
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3, 4, 5, 6});
    REQUIRE(set(ret.first.begin(), ret.first.end()) ==
            set<vector<int>>{{111, 22, 33, 22, 33, 441},
                             {111, 22, 33, 22, 33, 442},
                             {112, 22, 33, 22, 33, 441},
                             {112, 22, 33, 22, 33, 442},
                             {113, 22, 33, 22, 33, 441},
                             {113, 22, 33, 22, 33, 442}});
  }
  SECTION ("Join 2 equal tables") {
    vector<vector<int>> a{{111, 22, 33}, {112, 22, 33}, {113, 22, 33}}, b = a;
    vector<int> a_index{1, 2, 3}, b_index = a_index;
    auto ret = joinTables(a, a_index, b, b_index);
    REQUIRE(ret.second == vector<int>{1, 2, 3});
    REQUIRE(set(ret.first.begin(), ret.first.end()) ==
            set<vector<int>>{{111, 22, 33}, {112, 22, 33}, {113, 22, 33}});
  }
}

TEST_CASE ("Projection from table") {
  vector<vector<int>> a{{111, 221, 331}, {112, 222, 332}};
  vector<int> a_index{1, 2, 3};
  vector<int> proj_index{2, 2, 3, 1};
  REQUIRE(projectFromTable(a, a_index, proj_index) ==
          vector<vector<int>>{{221, 221, 331, 111}, {222, 222, 332, 112}});
  vector<int> proj_index2{2, 2, 3};
  REQUIRE(projectFromTable(a, a_index, proj_index2) ==
          vector<vector<int>>{{221, 221, 331}, {222, 222, 332}});
}