#include <vector>
#include "Common/Entity.h"
#include "Common/SPADefinitions.h"
#include "catch.hpp"

using std::vector;

using namespace SPA;

TEST_CASE ("Entity Validation - Pass") {
  vector<Entity> entities{{EntityType::PROC, "TestProcName"},
                          {EntityType::VAR, "VarName1"},
                          {EntityType::IF_STMT, "4"},
                          {EntityType::STMT, "4"}};

  for (const auto& ent : entities) {
    REQUIRE_NOTHROW(ent.validate());
  }
}

TEST_CASE ("Entity Validation - Fail") {
  vector<Entity> entities{{EntityType::PROC, "2TestProcName"},
                          {EntityType::VAR, "33"},
                          {EntityType::IF_STMT, "4v"},
                          {EntityType::STMT, "-1"},
                          {EntityType::STMT, "text"}};

  for (const auto& ent : entities) {
    REQUIRE_THROWS(ent.validate());
  }
}