#include <chrono>
#include <thread>
#include "Common/Timer.h"
#include "catch.hpp"

using namespace SPA;

TEST_CASE ("Timed Full System Test: sprint1_demo_uses_source.txt") {
  using namespace std::chrono_literals;
  INIT_BENCHMARK();
  BENCHMARK_LABEL("Testing sleep duration 200ms",
                  std::this_thread::sleep_for(200ms));
}
