#include "Common/Format.h"
#include "catch.hpp"

using namespace SPA;

TEST_CASE ("String Formatting") {
  REQUIRE(SPA::format("Hello {}", "World") == "Hello World");
  REQUIRE(SPA::format("Hello {} {}", "World", 2) == "Hello World 2");
  REQUIRE(SPA::format("Hello {} {}", std::string("World")) == "Hello World {}");
  REQUIRE(SPA::format("Hello {}{}", "Worl", 'd', "2") == "Hello World");
}
