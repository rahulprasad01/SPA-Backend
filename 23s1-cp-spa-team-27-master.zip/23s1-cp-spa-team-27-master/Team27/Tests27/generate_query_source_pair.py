import random, argparse, subprocess

def main():
    parser = argparse.ArgumentParser(prog="Query-Source gen script", description="Randomly generates a SIMPLE source program and a queries to go with it")
    parser.add_argument("num_queries", type=int, help="Number of queries to generate")
    parser.add_argument("num_decl", type=int, help="Number of declarations in each query")
    parser.add_argument("num_select", type=int, help="Number of selected elements (synynoms or attributes) for each query")
    parser.add_argument("num_clauses", type=int, help="Number of clauses for each query")
    parser.add_argument("-v", "--num_var", type=int, help="Number of variables in program")
    parser.add_argument("-p", "--num_proc", type=int, help="Number of procedures in program")
    parser.add_argument("p_output", type=str, help="Prefix for output files")
    args = parser.parse_args()
    num_var = args.num_var if args.num_var else random.randint(10, 20)
    num_proc = args.num_proc if args.num_proc else random.randint(4, 10)
    num_queries = args.num_queries
    num_decl = args.num_decl
    num_select = args.num_select
    num_clauses = args.num_clauses
    prefix_output = args.p_output
    source_command = ['python', 'random_source_generator.py', 
                      '-v', f'{num_var}', 
                      '-p', f'{num_proc}',
                      '-o', f'{prefix_output}_source.txt']
    query_command = ['python', 'random_query_generator.py',
                     f'{num_queries}', f'{num_decl}',
                     f'{num_select}', f'{num_clauses}',
                     '-o', f'{prefix_output}_queries.txt']
    subprocess.run(source_command)
    subprocess.run(query_command)
    print('')
    print('-'*50)
    print(f'Source generated with {num_var} variables and {num_proc} procedures.')
    print(f'{num_queries} queries generated with {num_decl} declarations, {num_select} selected and {num_clauses} clauses.')
    print(f'Prefix: {prefix_output}')

if __name__ == "__main__":
    main()
