import sys
import os
import argparse

import xml.etree.ElementTree as ET
import shutil

def main():
    CURRENT_PATH: str = os.getcwd()
    AUTOTESTER_PATH: str = os.sep.join(["..", "Code27", "out", "build", "x64-Release", "src", "autotester", "autotester.exe"]) if os.name != 'posix' else os.sep.join(["..", "Code27", "build", "src", "autotester", "autotester"])
    TESTS_INPUT_FOLDER: str = "."
    TESTS_OUTPUT_FOLDER: str = os.sep.join(["..", "Code27", "tests"])

    # APPEND NEW TEST FILES HERE
    TESTFILE_PREFIXES = [
        "Sample",
        "basicSPA_suchthat", 
        "basicSPA_noclauses", 
        "basicSPA_patterns", 
        "basicSPA_suchthatpattern", 
        "basicSPA_syntaxerrors", 
        "basicSPA_semanticerrors", 
        "sprint1_demo_parent", 
        "sprint1_demo_uses", 
        "sprint1_demo_entities", 
        "sprint1_demo_follows", 
        "sprint1_demo_modifies", 
        "sprint1_demo_entities", 
        "sprint1_demo_follows", 
        "sprint1_demo_modifies", 
        "sprint1_demo_parent", 
        "sprint1_demo_uses", 
        "ms2_callsonly", 
        "ms2_nextonly", 
        "ms2_affectsonly", 
        "ms2_usesmodifies_thruprocs",
        "ms2_attributeselect",
        "ms2_multiclause",
        "ms2_multipleselections",
        "ms2_patternwhileif",
        "ms2_withclause", 
        "ms3_notclause", ]
    
    parser = argparse.ArgumentParser(prog="SPA Autotester run script", description="Runs all system tests for SPA")
    parser.add_argument("-e", "--exec", help="Explicitly specify autotester filepath.")
    parser.add_argument("-t", "--testdir", help="Explicitly specify test input directory filepath.")
    parser.add_argument("-o", "--output", help="Explicitly specify test output directory filepath.")
    parser.add_argument('file_prefixes', metavar='FILE_PREFIXES', type=str, nargs='*',
                        help='prefix of all testfiles to run')
    args = parser.parse_args()

    if args.exec:
        AUTOTESTER_PATH = os.path.relpath(args.exec)
    if not os.path.exists(AUTOTESTER_PATH):
        print('autotester.exe not found at', AUTOTESTER_PATH)
        return

    if args.testdir:
        TESTS_INPUT_FOLDER = os.path.relpath(args.testdir)
    if not os.path.exists(TESTS_INPUT_FOLDER):
        print('test directory not found at', TESTS_INPUT_FOLDER)
        return

    if args.output:
        TESTS_OUTPUT_FOLDER = os.path.relpath(args.output)
    if not os.path.exists(TESTS_OUTPUT_FOLDER):
        print('test output directory not found at', TESTS_OUTPUT_FOLDER)
        return

    if args.file_prefixes:
        TESTFILE_PREFIXES = args.file_prefixes

    # Perform reset on TESTS_FOLDER
    for filename in os.listdir(TESTS_OUTPUT_FOLDER):
        if filename.endswith('.xml'):
            file_path = os.path.join(TESTS_OUTPUT_FOLDER, filename)
            # Check if it's a file before attempting to delete
            if os.path.isfile(file_path):
                os.remove(file_path)

    failed_folder: str = os.path.join(TESTS_OUTPUT_FOLDER, 'failed')
    for filename in os.listdir(failed_folder):
        if filename.endswith('.xml'):
            file_path = os.path.join(failed_folder, filename)
            # Check if it's a file before attempting to delete
            if os.path.isfile(file_path):
                os.remove(file_path)

    # Source and Query files must have their suffixes below respectively
    # (e.g. Sample_source.txt)
    SOURCE_SUFFIX: str = "_source.txt"
    QUERY_SUFFIX: str = "_queries.txt"
    OUTPUT_SUFFIX: str = "_output.xml"

    TEST_SUITES = []
    for prefix in TESTFILE_PREFIXES:
        source = os.sep.join([TESTS_INPUT_FOLDER, prefix]) + SOURCE_SUFFIX
        query = os.sep.join([TESTS_INPUT_FOLDER, prefix]) + QUERY_SUFFIX
        output = os.sep.join([TESTS_OUTPUT_FOLDER, prefix]) + OUTPUT_SUFFIX
        TEST_SUITES.append((source, query, output))

    for source, query, output in TEST_SUITES:
        if not os.path.exists(source):
            raise ValueError(f'no source file {source} found')
        if not os.path.exists(query):
            raise ValueError(f'no query file {query} found')
        os.system(f"{AUTOTESTER_PATH} {source} {query} {output}")

    # Check XML output for failing test cases
    source_folder: str = TESTS_OUTPUT_FOLDER

    for filename in os.listdir(source_folder):
        if filename.endswith('.xml'):
            xml_file_path = os.path.join(source_folder, filename)

            # Parse the XML file
            tree = ET.parse(xml_file_path)
            root = tree.getroot()

            # Search for <failed> elements
            failed_elements = root.findall(".//failed")
            exception_elements = root.findall(".//exception")
            timeout_elements = root.findall(".//timeout")

            if failed_elements or exception_elements or timeout_elements:
                # If <failed> elements are found, create a "failed" folder and move the file
                failed_folder: str = os.path.join(source_folder, 'failed')
                if not os.path.exists(failed_folder):
                    os.makedirs(failed_folder)

                ANALYSIS_IN_FAILED: str = os.path.join(failed_folder, "analysis.xsl")
                if not os.path.exists(ANALYSIS_IN_FAILED):
                    shutil.copy(os.path.join(TESTS_OUTPUT_FOLDER, "analysis.xsl"), ANALYSIS_IN_FAILED) 
                
                # Move the XML file to the "failed" folder
                shutil.move(xml_file_path, os.path.join(failed_folder, filename))
                sys.exit(1)

if __name__ == "__main__":
    main()
