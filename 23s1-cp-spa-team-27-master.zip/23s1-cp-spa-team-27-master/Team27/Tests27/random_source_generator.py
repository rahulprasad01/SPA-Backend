import random, os, argparse, datetime

def main():
    parser = argparse.ArgumentParser(prog="Random source generator script", description="Randomly generates a SIMPLE source program")
    parser.add_argument("-v", "--num_var", type=int, help="Number of variables in program")
    parser.add_argument("-p", "--num_proc", type=int, help="Number of procedures in program")
    parser.add_argument("-l", "--num_lines", type=int, default=500, help="Number of lines in program")
    parser.add_argument("-o", "--output", type=str, help="Output file name")
    args = parser.parse_args()
    num_var = args.num_var if args.num_var else random.randint(10, 20)
    num_proc = args.num_proc if args.num_proc else random.randint(4, 10)
    num_lines = args.num_lines

    output_file = f'rndm_{num_proc}p_{num_var}v_{num_lines}l_source.txt'
    output = args.output
    if output:
        if not output.endswith('.txt'):
            output += '.txt'
        output_file = output

    source = generate_source(num_proc, num_var, num_lines)
    with open(output_file, 'w') as file:
        file.write(source)
    print('SIMPLE source generated.')

def generate_source(num_proc, num_var, num_lines):
    num_lines_per_proc = divide_lines(num_lines, num_proc)
    procs = [generate_proc(lines, num_var, proc_num, num_proc-1) for proc_num, lines in enumerate(num_lines_per_proc)]
    return '\n'.join(procs)

def generate_proc(num_lines, num_var, proc_num, max_proc_num):
    stmt_list = generate_stmt_list(num_lines, num_var, proc_num, max_proc_num)
    return f"procedure p{proc_num} {{{stmt_list}}}"

def generate_stmt_list(num_lines, num_var, proc_num, max_proc_num, indent=1, indent_size=2) -> str:
    stmt_list = []
    lines_left = num_lines
    while lines_left > 0:
        stmt_choices = ['read','print','assign','call','while','if']
        stmt_weights = [2, 2, 8, 1, 2, 2]
        if proc_num == max_proc_num:
            stmt_weights[3] = 0 # Can't make call stmt if last proc
        if lines_left == 1:
            stmt_weights[4] = 0 # Can't make while stmt if only 1 line
        if lines_left <= 2:
            stmt_weights[5] = 0 # Can't make if stmt if <= 2 lines

        stmt_type = random.choices(stmt_choices, weights=stmt_weights, k=1)[0]
        lines_left += -1
        if stmt_type == 'read':
            stmt_list.append(generate_read_stmt(num_var))
        elif stmt_type == 'print':
            stmt_list.append(generate_print_stmt(num_var))
        elif stmt_type == 'assign':
            stmt_list.append(generate_assign_stmt(num_var))
        elif stmt_type == 'call':
            stmt_list.append(generate_call_stmt(proc_num, max_proc_num))
        elif stmt_type == 'while':
            lines_taken = random.randint(1, round(lines_left * 0.8))
            lines_left = lines_left - lines_taken
            stmt_list.append(generate_while_stmt(lines_taken, num_var, proc_num, max_proc_num, indent, indent_size))
        elif stmt_type == 'if':
            lines_taken = random.randint(2, round(lines_left * 0.8))
            lines_left = lines_left - lines_taken
            if_lines = random.randint(1, lines_taken-1)
            else_lines = lines_taken - if_lines
            stmt_list.append(generate_if_stmt(if_lines, else_lines, num_var, proc_num, max_proc_num, indent, indent_size))
    indent_gap = ' '*indent*indent_size
    return indent_gap + f"\n{indent_gap}".join(stmt_list)
        
def generate_read_stmt(num_var):
    return f'read {generate_variable(num_var)};'

def generate_print_stmt(num_var):
    return f'print {generate_variable(num_var)};'

def generate_assign_stmt(num_var):
    return f'{generate_variable(num_var)} = {generate_expression(num_var)};'

def generate_call_stmt(proc_num, max_proc_num):
    return f'call p{random.randint(proc_num+1, max_proc_num)};'

def generate_while_stmt(num_lines, num_var, proc_num, max_proc_num, indent, indent_size):
    cond_expr = f'({generate_variable(num_var)} {generate_cond_op()} {generate_expression(num_var, 1, 3)})'
    while_stmt_list = generate_stmt_list(num_lines, num_var, proc_num, max_proc_num, indent=indent+1)
    indent_gap = ' '*indent*indent_size
    return f'while {cond_expr} {{\n{while_stmt_list}}}'

def generate_if_stmt(num_lines_if, num_lines_else, num_var, proc_num, max_proc_num, indent, indent_size):
    cond_expr = f'({generate_variable(num_var)} {generate_cond_op()} {generate_expression(num_var, 1, 3)})'
    if_stmt_list = generate_stmt_list(num_lines_if, num_var, proc_num, max_proc_num, indent=indent+1)
    else_stmt_list = generate_stmt_list(num_lines_else, num_var, proc_num, max_proc_num, indent=indent+1)
    indent_gap = ' '*indent*indent_size
    return f'if {cond_expr} then {{\n{if_stmt_list}}} else {{\n{else_stmt_list}}}'

def generate_expression(num_var, min_var=2, max_var=5):
    expression = generate_factor(num_var)
    addon_terms = random.randint(min_var-1, max_var-1)
    for _ in range(addon_terms):
        expression += f' {generate_binary_op()} {generate_factor(num_var)}'
    return expression

def generate_variable(num_var):
    return f'v{random.randint(1,num_var)}'

def generate_factor(num_var):
    if random.random() < 0.8:
        return f'v{random.randint(1,num_var)}'
    else:
        return f'{random.randint(0, 500)}'

def generate_binary_op():
    ops = ['+', '-', '*', '/', '%']
    return random.choice(ops)

def generate_cond_op():
    ops = ['>', '>=', '<', '<=', '==', '!=']
    return random.choice(ops)

def divide_lines(num_lines, num_proc):
    if num_proc == 1:
        return [num_lines]
    division_points = sorted(random.sample(range(1, num_lines), num_proc-1))
    division = ([division_points[0]] 
                + [division_points[i] - division_points[i - 1] for i in range(1, num_proc-1)] 
                + [num_lines - division_points[-1]])
    return division

if __name__ == "__main__":
    main()
