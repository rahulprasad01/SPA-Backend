import random, os, argparse, datetime

NOT_CHANCE = 0.5
VAR_CHANCE = 0.6
SUCH_THAT_CHANCE = 0.7
STAR_CHANCE = 0.8

def main():
    parser = argparse.ArgumentParser(prog="Random query generator script", description="Randomly generates queries suitable for all SIMPLE source programs")
    parser.add_argument("num_queries", type=int, help="Number of queries to generate")
    parser.add_argument("num_decl", type=int, help="Number of declarations in each query")
    parser.add_argument("num_select", type=int, help="Number of selected elements (synynoms or attributes) for each query")
    parser.add_argument("num_clauses", type=int, help="Number of clauses for each query")
    parser.add_argument("-o", "--output", type=str, help="Output file name")
    args = parser.parse_args()
    num_queries = args.num_queries
    num_decl = args.num_decl
    num_select = args.num_select
    num_clauses = args.num_clauses

    output_file = f'rndm_{num_queries}q_{num_decl}d_{num_select}s_{num_clauses}c_queries.txt'
    output = args.output
    if output:
        if not output.endswith('.txt'):
            output += '.txt'
        output_file = output

    queries = generate_queries(num_queries, num_decl, num_select, num_clauses)
    with open(output_file, 'w') as file:
        for i, query in enumerate(queries):
            print(f'Generating Query {i+1}:')
            print(f'{query}')
            file.write(f'{i+1} - Random Query with {num_decl} declarations, {num_select} selected, {num_clauses} clauses\n')
            file.write(f'{query}\n')
            file.write('\n')
            file.write('5000\n')

def generate_declarations(decl_map:dict, num_decl:int):
    syn_types = ['stmt', 'read', 'print', 'call', 'while', 'if', 
                 'assign', 'variable', 'constant', 'procedure']
    for i in range(num_decl):
        new_syn = f'a{i}'
        new_syn_type = random.choice(syn_types)
        if new_syn_type not in decl_map:
            decl_map[new_syn_type] = []
        decl_map[new_syn_type].append(new_syn)
    decl_str = ''
    for syn_type, syns in decl_map.items():
        decl_str += f"{syn_type} {','.join(syns)}; "
    return decl_str

def generate_result_cl(decl_map:dict, num_select:int):
    elems = []
    for _ in range(num_select):
        if random.random() < 0.5:
            elems.append(get_random_synonym(decl_map))
        else:
            elems.append(generate_attr_ref(decl_map))
    return f"<{','.join(elems)}>"

def get_random_synonym(decl_map:dict):
    return random.choice(random.choice(list(decl_map.values())))

def generate_attr_ref(decl_map:dict):
    attr_names = {'stmt': ['stmt#'], 'read': ['stmt#', 'varName'], 'print':['stmt#', 'varName'], 
                  'call':['stmt#', 'procName'], 'while':['stmt#'], 'if':['stmt#'], 'assign':['stmt#'], 
                  'procedure':['procName'], 'variable':['varName'], 'constant':['value']}
    syn_type = random.choice(list(decl_map.keys()))
    syn = random.choice(decl_map[syn_type])
    attr_name = random.choice(attr_names[syn_type])
    return f'{syn}.{attr_name}'

def get_attr_type(attr_ref:str):
    if attr_ref.endswith('stmt#') or attr_ref.endswith('value'):
        return int
    else:
        return str
    
def generate_uses_modifies_cl(decl_map:dict, rel_ref:str):
    if rel_ref == 'Uses':
        poss_first_syn_types = list(filter(lambda x:x in decl_map, ['procedure', 'stmt', 'call', 'if', 'while', 'assign', 'print']))
    else: # Modifies
        poss_first_syn_types = list(filter(lambda x:x in decl_map, ['procedure', 'stmt', 'call', 'if', 'while', 'assign', 'read']))
    first_syn_type = random.choice(poss_first_syn_types)
    first_syn = random.choice(decl_map[first_syn_type])
    second_arg = random.choice(decl_map['variable']) if 'variable' in decl_map and random.random() < SUCH_THAT_CHANCE else '_'
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    return f'such that {not_cl}{rel_ref} ({first_syn}, {second_arg})'

def generate_calls_cl(decl_map:dict, rel_ref:str):
    star = '*' if random.random() < STAR_CHANCE else ''
    if 'procedure' not in decl_map:
        return f'such that Calls{star} (_, _)'
    first_arg = random.choice(decl_map['procedure']) if random.random() < SUCH_THAT_CHANCE else '_'
    second_arg = random.choice(decl_map['procedure']) if random.random() < SUCH_THAT_CHANCE else '_'
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    return f'such that {not_cl}Calls{star} ({first_arg}, {second_arg})'

def generate_affects_cl(decl_map:dict, rel_ref:str):
    first_arg = random.choice(decl_map['assign']) if random.random() < SUCH_THAT_CHANCE else '_'
    second_arg = random.choice(decl_map['assign']) if random.random() < SUCH_THAT_CHANCE else '_'
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    return f'such that {not_cl}Affects ({first_arg}, {second_arg})'

def generate_follows_parent_next_cl(decl_map:dict, rel_ref:str):
    if rel_ref == 'Parent':
        poss_first_syn_types = list(filter(lambda x:x in decl_map, ['stmt', 'while', 'if']))
    else:
        poss_first_syn_types = list(filter(lambda x:x in decl_map, ['stmt', 'read', 'print', 'call', 'while', 'if', 'assign']))
    first_syn_type = random.choice(poss_first_syn_types)
    first_arg = random.choice(decl_map[first_syn_type]) if random.random() < SUCH_THAT_CHANCE else '_'
    poss_second_syn_types = list(filter(lambda x:x in decl_map, ['stmt', 'read', 'print', 'call', 'while', 'if', 'assign']))
    second_syn_type = random.choice(poss_second_syn_types)
    second_arg = random.choice(decl_map[second_syn_type]) if random.random() < SUCH_THAT_CHANCE else '_'
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    star = '*' if random.random() < STAR_CHANCE else ''
    return f'such that {not_cl}{rel_ref}{star} ({first_arg}, {second_arg})'

def generate_such_that_cl(decl_map:dict):
    rel_refs = ['Follows', 'Parent', 'Uses', 'Modifies', 'Calls', 'Next', 'Affects']
    rel_ref = random.choice(rel_refs)
    if rel_ref in ['Uses', 'Modifies']:
        return generate_uses_modifies_cl(decl_map, rel_ref)
    elif rel_ref == 'Calls':
        return generate_calls_cl(decl_map, rel_ref)
    elif rel_ref == 'Affects':
        return generate_affects_cl(decl_map, rel_ref)
    else:
        return generate_follows_parent_next_cl(decl_map, rel_ref)

def generate_pattern_cl(decl_map:dict):
    possible_pattern_syn_types = list(filter(lambda x:x in decl_map, ['assign','while', 'if']))
    pattern_syn_type = random.choice(possible_pattern_syn_types)
    pattern_syn = random.choice(decl_map[pattern_syn_type])
    entRef = '_'
    if 'variable' in decl_map and random.random() < VAR_CHANCE:
        entRef = random.choice(decl_map['variable'])
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    if pattern_syn_type == 'if':
        return f'pattern {not_cl}{pattern_syn} ({entRef}, _, _)'
    else:
        return f'pattern {not_cl}{pattern_syn} ({entRef}, _)'

def generate_with_cl(decl_map:dict):
    attr_refs = [generate_attr_ref(decl_map) for i in range(3)]
    attr_ref_types = list(map(get_attr_type, attr_refs))
    majority_type = max(set(attr_ref_types), key = attr_ref_types.count)
    selected_refs = list(filter(lambda x:get_attr_type(x) is majority_type, attr_refs))
    not_cl = 'not ' if random.random() < NOT_CHANCE else ''
    return f'with {not_cl}{selected_refs[0]} = {selected_refs[1]}'

def generate_clauses(decl_map:dict, num_clauses:int):
    clauses = []
    for _ in range(num_clauses):
        i = random.randint(1,3)
        if i == 1:
            clauses.append(generate_such_that_cl(decl_map))
        elif i == 2:
            clauses.append(generate_pattern_cl(decl_map))
        else:
            clauses.append(generate_with_cl(decl_map))
    return ' '.join(clauses)

def generate_query(num_decl:int, num_select:int, num_clauses:int):
    decl_map = {'assign': ['a']}
    declarations = generate_declarations(decl_map, num_decl)
    result_cl = generate_result_cl(decl_map, num_select)
    clauses = generate_clauses(decl_map, num_clauses)
    return f'{declarations}\nSelect {result_cl} {clauses}'

def generate_queries(num_queries:int, num_decl:int, num_select:int, num_clauses:int):
    queries = []
    for _ in range(num_queries):
        query = generate_query(num_decl, num_select, num_clauses)
        queries.append(query)
    return queries

if __name__ == "__main__":
    main()
